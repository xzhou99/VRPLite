﻿//  Copyright 2008-2010 Kenneth Williams, Tao Xing, Xuesong Zhou @ University of Utah
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.


using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Routing_Engine;

namespace winServerSVN
{
    public partial class AccelerationForm : Form
    {
        Queue<CAcceleration> m_data;
        static CAcceleration m_currData, m_prevData;
        float m_currMax;
        float[] m_aryMax;
        int[] m_score;
        int m_count;
        public static double m_Gravity = 9.8;
        
        public AccelerationForm()
        {
            InitializeComponent();
            this.SetStyle(  ControlStyles.AllPaintingInWmPaint |  ControlStyles.UserPaint |  ControlStyles.DoubleBuffer, true);
            m_data = new Queue<CAcceleration>();
            m_currData = new CAcceleration();
            m_prevData = new CAcceleration();
            m_currMax = 0;
            m_aryMax = new float[4];
            m_score = new int[5]; m_score[0] = 100;
            Thread data = new Thread(UpdateDataThread);
            data.Start();
            //LoadAcceData_TXT(@"D:\Research\Accelerometer\data\April21_2009\", "xyzsharpAccel");
        }


        public void UpdateDataThread()
        {
            while (true)
            {
                Thread.Sleep(1000);
                if (m_data.Count > 0)
                {
                    m_prevData = m_currData;
                    m_currData = m_data.Dequeue();
                }
                //else
                //{
                //    m_currData.AcceDriving = (m_currData.AcceDriving + m_prevData.AcceDriving) / 2;
                //    m_currData.AcceRight = (m_currData.AcceRight + m_prevData.AcceRight) / 2;
                //}
                Invalidate();
            }
        }

        public void Cleanup()
        {
            m_data = new Queue<CAcceleration>();
            m_currData = new CAcceleration();
            m_prevData = new CAcceleration();
            m_currMax = 0;
            m_aryMax = new float[4];
            m_score = new int[5];
        }

        public void ReceiveAcceData(string AcceData)
        {
            int index, sub_index;
            string sub_str;
            double acce_driving, acce_turning;
            m_data.Clear();
            index = AcceData.IndexOf("ACCL");
            AcceData = AcceData.Substring(index + 4).Trim();
            index = AcceData.IndexOf("$");
            if (index != -1)
            {
                m_count = int.Parse(AcceData.Substring(0, index));
                AcceData = AcceData.Substring(index + 1).Trim();
            }
            index = AcceData.IndexOf("\0");
            if (index != -1)
            {
                AcceData = AcceData.Substring(0, index).Trim();
            }
            while(AcceData != "")//for (int i = 0; i < 45; i++)
            {
                index = AcceData.IndexOf(";");
                sub_str = AcceData.Substring(0, index);
                sub_str = sub_str.Trim();
                sub_index = sub_str.IndexOf(",");
                acce_driving = double.Parse(sub_str.Substring(0, sub_index));
                acce_turning = double.Parse(sub_str.Substring(sub_index + 1)) * -1;
                m_data.Enqueue(new CAcceleration(acce_driving, acce_turning, m_Gravity));
                if (index + 1 < AcceData.Length)
                {
                    AcceData = AcceData.Substring(index + 1);
                }
                else
                {
                    AcceData = "";
                }

            }
        }


        protected override void OnPaint(PaintEventArgs paintEvnt)
        {
            // Get the graphics object
            Graphics gfx = paintEvnt.Graphics;
            Image img = new Bitmap(ClientRectangle.Width, ClientRectangle.Height);
            // Create a new pen that we shall use for drawing the line
            Pen blackPen = new Pen(Brushes.Black), bluePen = new Pen(Brushes.RoyalBlue);
            blackPen.Width = 3.0F; bluePen.Width = 5.0F;
            Font drawFont = new Font("Arial", 12);
            Font ScoreFont = new Font("Arial", 18);
            float ratio = (float) (m_Gravity / 200);
            float ImageWidth = (float)ClientRectangle.Width - 200;
            float ImageHeight = (float)ClientRectangle.Height;
            // draw static coordinate system

            gfx.FillEllipse(Brushes.Red, ImageWidth / 2 - 300, ImageHeight / 2 - 300, 600, 600);
            gfx.FillEllipse(Brushes.Yellow, ImageWidth / 2 - 200, ImageHeight / 2 - 200, 400, 400);
            gfx.FillEllipse(Brushes.Lime, ImageWidth / 2 - 100, ImageHeight / 2 - 100, 200, 200);
            gfx.DrawLine(blackPen, 0, ImageHeight / 2, ImageWidth, ImageHeight / 2);
            gfx.DrawLine(blackPen, ImageWidth / 2, 0, ImageWidth / 2, ImageHeight);
            gfx.DrawString("Forward", drawFont, Brushes.White, ImageWidth / 2 - 30, 10);
            gfx.DrawString("Backward", drawFont, Brushes.White, ImageWidth / 2 - 30, ImageHeight - 30);
            gfx.DrawString("Left Turn", drawFont, Brushes.White, 10, ImageHeight / 2 - 30);
            gfx.DrawString("Right Turn", drawFont, Brushes.White, ImageWidth - 90, ImageHeight / 2 - 30);
            
            float[] temp = new float[4];
            // draw acceleration points
            if (m_currData != null)
            {
                float PointX = (float)(m_currData.AcceRight / ratio + ImageWidth / 2);
                float PointY = (float)(ImageHeight / 2 - m_currData.AcceDriving / ratio);
                if (m_currData.AcceDriving >= 0)
                {
                    temp[0] = (float)m_currData.AcceDriving;
                    temp[1] = 0;
                }
                else
                {
                    temp[1] = (float)m_currData.AcceDriving * -1;
                    temp[0] = 0;
                }
                if (m_currData.AcceRight >= 0)
                {
                    temp[3] = (float)m_currData.AcceRight;
                    temp[2] = 0;
                }
                else
                {
                    temp[2] = (float)m_currData.AcceRight * -1;
                    temp[3] = 0;                
                }

                int r = 10;
                // draw a bound for trace
                if ((float)m_currData.AcceDirection > m_currMax)
                {
                    m_currMax = (float)m_currData.AcceDirection;
                }
                for (int i = 0; i < m_aryMax.Length; i++)
                {
                    if (temp[i] > m_aryMax[i])
                    {
                        m_aryMax[i] = temp[i];
                    }
                }
                if (m_aryMax[0] > 1)
                    gfx.FillRectangle(Brushes.Black, ImageWidth / 2 - 15, ImageHeight / 2 - m_aryMax[0] / ratio - r, 30, 10);
                if (m_aryMax[1] > 1)
                    gfx.FillRectangle(Brushes.Black, ImageWidth / 2 - 15, ImageHeight / 2 + m_aryMax[1] / ratio, 30, 10);
                if (m_aryMax[2] > 1)
                    gfx.FillRectangle(Brushes.Black, ImageWidth / 2 - m_aryMax[2] / ratio - r, ImageHeight / 2 - 15, 10, 30);
                if (m_aryMax[3] > 1)
                    gfx.FillRectangle(Brushes.Black, ImageWidth / 2 + m_aryMax[3] / ratio, ImageHeight / 2 - 15, 10, 30);

                //gfx.DrawEllipse(bluePen, ImageWidth / 2 - m_currMax / ratio, ImageHeight / 2 - m_currMax / ratio, m_currMax * 2 / ratio, m_currMax * 2 / ratio);
                if (m_currData.AcceDirection > m_Gravity / 2 && m_currData.AcceDirection <= m_Gravity)
                {
                    m_score[0]--;
                }
                if (m_currData.AcceDirection > m_Gravity)
                {
                    m_score[0] -= 2;
                }
                if (m_currData.AcceDriving > m_Gravity / 2 && m_prevData.AcceDriving < m_Gravity / 2)
                {
                    m_score[1]++;
                }
                if (m_currData.AcceDriving < m_Gravity / -2 && m_prevData.AcceDriving > m_Gravity / -2)
                {
                    m_score[2]++;
                }
                if (m_currData.AcceRight < m_Gravity / -2 && m_prevData.AcceRight > m_Gravity / -2)
                {
                    m_score[3]++;
                }
                if (m_currData.AcceRight > m_Gravity / 2 && m_prevData.AcceRight < m_Gravity / 2)
                {
                    m_score[4]++;
                }
                gfx.FillEllipse(Brushes.Blue, PointX - r, PointY - r, 20, 20);
                gfx.DrawString("Safety Score: " + m_score[0], ScoreFont, Brushes.Black, ImageWidth - 30, 30);
                gfx.DrawString("Rapid Starts: " + m_score[1], ScoreFont, Brushes.Black, ImageWidth - 30, 450);
                gfx.DrawString("Rapid Breaks: " + m_score[2], ScoreFont, Brushes.Black, ImageWidth - 30, 500);
                gfx.DrawString("Sharp turns: " + (m_score[3] +  + m_score[4]), ScoreFont, Brushes.Black, ImageWidth - 30, 550);

            }

            gfx.DrawImage(img, ClientRectangle);
            img.Dispose();

        }

        public bool LoadAcceData_TXT(string filepath, string filename)
        {
            string path;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            path = filepath + filename + ".txt";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine, subStr;
            int index;
            double x = 0, y = 0, z = 0;
            //
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf("x");
                if (index == 0)
                {
                    index = szSrcLine.IndexOf("y");
                    subStr = szSrcLine.Substring(2, index - 2);
                    subStr = subStr.Trim();
                    x = double.Parse(subStr);
                    szSrcLine = szSrcLine.Substring(index);
                    index = szSrcLine.IndexOf("z");
                    subStr = szSrcLine.Substring(2, index - 2);
                    subStr = subStr.Trim();
                    y = double.Parse(subStr);
                    szSrcLine = szSrcLine.Substring(index);
                    subStr = szSrcLine.Substring(2);
                    subStr = subStr.Trim();
                    z = double.Parse(subStr);
                }
                m_currData = new CAcceleration(x, y, z);
                m_data.Enqueue(m_currData);
            }
            return true;
        }



    }

    public class CAcceleration
    {
        public double AcceDriving, AcceGravity, AcceRight;
        public double AcceDirection;

        public CAcceleration()
        {
            AcceDriving = 0;
            AcceGravity = 0;
            AcceRight = 0;
            AcceDirection = 0;
        }
        public CAcceleration(double _AcceDriving, double _AcceRight, double _AcceGravity)
        {
            AcceDriving = _AcceDriving;
            AcceGravity = _AcceGravity;
            AcceRight = _AcceRight;
            AcceDirection = Math.Sqrt(_AcceDriving * _AcceDriving + _AcceRight * _AcceRight);
        }
    }
}
