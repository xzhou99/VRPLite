﻿//  Copyright 2008-2010 Xuesong Zhou @ University of Utah
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
//using MySql.Data; // To use this you must add a Refrence to "MySql.Data.dll"
//using MySql.Data.MySqlClient; // To use this you must add a Refrence to "MySql.Data.dll"

namespace MySQL
{
    public class connectDB
    {

        string SQLHost = "localhost"; // The location of the SQL Server.
        string SQLDB = "vii_data"; // The database of tables you want to connect to.
        string SQLAdmin = "root"; // The username of the administrator account that will access the SQL Server.
        string SQLPass = "path"; // The password of the administrator account that will access the SQL Server.

        //MySqlConnection MySqlConn;
        //MySqlCommand MySqlCmd;

        public string LocalTimeIndex="LocalTimeIndex";
        public string AreaID = "AreaID";
        public string LinkID = "LinkID";
        public string TravelTime = "TravelTime";
        public string TravelTimeIndex = "TravelTimeIndex";
        public string LocalDayOfWeek = "LocalDayOfWeek";
        public string LocalWeek = "LocalWeek";
        public string LocalYear = "LocalYear";
        public string ProviderID = "ProviderID";
        public string SourceID = "SourceID";

        //public connectDB()
        //{

        //     MySqlConn= new MySqlConnection(ConnStr()); // Declare a new Instance of MySqlConnection
        //     MySqlCmd = new MySqlCommand(); // Declare a new Instance of MySqlCommand (This is the Class for Querys)


        //}
        //private string ConnStr()
        //{
        //    StringBuilder SB = new StringBuilder(); // Declare a new Instance of StringBuilder so we can create the Connection String.
        //    SB.Append("Network Address="+SQLHost+";");
        //    SB.Append("Database='"+SQLDB+"';");
        //    SB.Append("User Name='"+SQLAdmin+"';");
        //    SB.Append("Password='"+SQLPass+"'");
        //    return SB.ToString(); // Return the whole Connection String as 1 string, not 4 single strings.
        //}

        //public void ExecuteQuery(string Query) // Usage "ExecuteQuery("INSERT INTO `MyTable` (`Col1` `Col2`) VALUES ('Col1Value', 'Col2Value')");
        //{
        //    MySqlCmd.CommandText = Query; // Set the MySqlCmd's Query to what the user has input.
        //    MySqlCmd.Connection = MySqlConn; // Set the MySqlCmd's Connection to the SQL Connection.
        //    MySqlConn.Open(); // Open the MySql Connection.
        //    MySqlCmd.ExecuteNonQuery(); // Execute the Query.
        //    MySqlConn.Close(); // Close the MySql Connection.
        //}

        //public Hashtable getQueryFromOnLineData(string query) // Usage "ExecuteReturnQuery("SELECT `MyCol1` FROM `MyTable` WHERE (MyValue = WhatIWant)");
        //{
        //    query = "select * from OnLineData"; // Set the Returned string to blank so that if the Query errors, the program wont error.
        //    MySqlCmd.CommandText = query; // Set the MySqlCmd's Query to what the user has input.
        //    MySqlCmd.Connection = MySqlConn; // Set the MySqlCmd's Connection to the SQL Connection.
        //    MySqlConn.Open(); // Open the MySql Connection.
            
        //    Hashtable traff = new Hashtable();
        //    MySqlDataReader reader;
        //    int timecount = 0;
        //    try
        //    {
        //        reader = MySqlCmd.ExecuteReader();
                
        //        while (reader.Read())
        //        {
        //            CQuery cqq = new CQuery();//create a CQuery object to store data
        //            try
        //            {
        //                cqq.LocalTimeIndex = reader["LocalTimeIndex"].ToString();
        //                cqq.AreaID = Int32.Parse(reader["AreaID"].ToString());
        //                cqq.LinkID = Int32.Parse(reader["LinkID"].ToString());
        //                cqq.TravelTime = Double.Parse(reader["TravelTime"].ToString());
        //                cqq.TravelTimeIndex = Double.Parse(reader["TravelTimeIndex"].ToString());
        //                cqq.LocalDayOfWeek = Int32.Parse(reader["LocalDayOfWeek"].ToString());
        //                cqq.LocalWeek = Int32.Parse(reader["LocalWeek"].ToString());
        //                cqq.LocalYear = Int32.Parse(reader["LocalYear"].ToString());
        //                cqq.ProviderID = Int32.Parse(reader["ProviderID"].ToString());
        //                cqq.SourceID = Int32.Parse(reader["SourceID"].ToString());
        //            }
        //            catch (Exception e)
        //            {
        //                //Console.WriteLine(e.Message);
        //            }
        //            traff.Add(timecount++, cqq);
        //            //cqq.show();
        //        } // Try to retrieve the value asked for by the Qeury
        //        reader.Close();
        //    }
        //    catch (NullReferenceException NRE) { Console.WriteLine(NRE.Message); } // If there is a error do nothing and continue on.
            
        //    Hashtable ntraff = new Hashtable();
        //    System.Collections.IDictionaryEnumerator idic = traff.GetEnumerator();
        //    int i = timecount;
        //    while(idic.MoveNext()&& i >=0)
        //    {
        //        CQuery cq = new CQuery();//create a CQuery object to store data
        //        cq = (CQuery)idic.Value;
        //        cq.link = getQueryFromLinks("select * from Links where LinkID=" + cq.LinkID);
        //        ntraff.Add(--i, cq);
        //        //cq.show();
        //    }
        //    traff.Clear();
        //    MySqlConn.Close(); // Close the MySql Connection.
        //    return ntraff; // Return the value asked for by the Qeury

        //}
        //public LinkProperties getQueryFromLinks(string query) // Usage "ExecuteReturnQuery("SELECT `MyCol1` FROM `MyTable` WHERE (MyValue = WhatIWant)");
        //{
            
        //    LinkProperties lp = new LinkProperties();
        //    MySqlConnection MySqlConn=new MySqlConnection(ConnStr());
        //    MySqlCommand sqlCmd=new MySqlCommand();
        //    sqlCmd.Connection = MySqlConn; // Set the MySqlCmd's Connection to the SQL Connection.
        //    MySqlConn.Open(); // Open the MySql Connection.
        //    sqlCmd.CommandText = query; // Set the MySqlCmd's Query to what the user has input.
        //    MySqlDataReader reader;
        //    try
        //    {
        //        reader = sqlCmd.ExecuteReader();

        //        while (reader.Read())
        //        {
        //            try
        //            {                       
                        
        //                lp.LinkID = Int32.Parse(reader["LinkID"].ToString());
        //                lp.FromNodeID = Int32.Parse(reader["FromNodeID"].ToString());
        //                lp.ToNodeID = Int32.Parse(reader["ToNodeID"].ToString());                        
        //                lp.frmNode = getQueryFromNodes("select * from Nodes where NodeID="+lp.FromNodeID);
        //                lp.toNode = getQueryFromNodes("select * from Nodes where NodeID=" + lp.ToNodeID);
        //            }
        //            catch (Exception e)
        //            {
        //                Console.WriteLine(e.Message);
        //            }
        //        } // Try to retrieve the value asked for by the Qeury
        //        reader.Close();
        //    }
        //    catch (NullReferenceException NRE) { Console.WriteLine(NRE.Message); }
        //    MySqlConn.Close();
        //    return lp; // Return the value asked for by the Qeury

        //}
        //public NodeProperties getQueryFromNodes(string query) // Usage "ExecuteReturnQuery("SELECT `MyCol1` FROM `MyTable` WHERE (MyValue = WhatIWant)");
        //{
        //    NodeProperties np = new NodeProperties();
        //    MySqlConnection MySqlConn = new MySqlConnection(ConnStr());
        //    MySqlCommand sqlCmd = new MySqlCommand();
        //    sqlCmd.Connection = MySqlConn; // Set the MySqlCmd's Connection to the SQL Connection.
        //    MySqlConn.Open(); // Open the MySql Connection.
        //    sqlCmd.CommandText = query; // Set the MySqlCmd's Query to what the user has input.
        //    MySqlDataReader reader;
        //    try
        //    {
        //        reader = sqlCmd.ExecuteReader();

        //        while (reader.Read())
        //        {
        //            try
        //            {

        //                np.NodeID = Int32.Parse(reader["NodeID"].ToString());
        //                np.UTMEasting = Double.Parse(reader["UTMEasting"].ToString());
        //                np.UTMNorthing = Double.Parse(reader["UTMNorthing"].ToString());
        //                np.UTMZone = Double.Parse(reader["UTMZone"].ToString());
        //                np.LAT = Double.Parse(reader["LAT"].ToString());
        //                np.LNG = Double.Parse(reader["LNG"].ToString());
        //            }
        //            catch (Exception e)
        //            {
        //                Console.WriteLine(e.Message);
        //            }
        //        } // Try to retrieve the value asked for by the Qeury
        //        reader.Close();
        //    }
        //    catch (NullReferenceException NRE) { Console.WriteLine(NRE.Message); }
        //    MySqlConn.Close();
        //    return np; // Return the value asked for by the Qeury

        //}
        public CQuery getDataFrmDataBase(int numberofcols)
        {

            string squery = "";
            CQuery cq=new CQuery();
            return cq;

        }
    }
    public class CQuery
    {
        public string LocalTimeIndex;
        public int AreaID;
        public int LinkID;
        public double TravelTime;
        public double TravelTimeIndex;
        public int LocalDayOfWeek;
        public int LocalWeek;
        public int LocalYear;
        public int ProviderID;
        public int SourceID;
        public LinkProperties link;
        


        public CQuery()
        {
            link = new LinkProperties();
        }
        public void show(){

            Console.WriteLine(" {0} : {1} : {2} : {3} : {4}",this.LocalTimeIndex,this.AreaID,this.LinkID,this.TravelTime,this.TravelTimeIndex);
        }
    }
    public class LinkProperties
    {
        /*Link properties*/
        public string LinkName;
        public int LinkID;
        public int FromNodeID;
        public int ToNodeID;
        public int MapLevel;
        public int ModeFlag;
        public int LinkLength;
        public int NumberOfLanes;
        public int SpeedLimit;
        public NodeProperties frmNode;
        public NodeProperties toNode;

        public LinkProperties()
        {
            frmNode = new NodeProperties();
            toNode = new NodeProperties();
        }
    }
    public class NodeProperties
    {
        /*Node properties*/
        public int NodeID;
        public int AreadID;
        public string NodeName;
        public double LNG;
        public double LAT;
        public double UTMEasting;
        public double UTMNorthing;
        public double UTMZone;
        public int MapLevel;


        public NodeProperties()
        {
        }
    }
}
