//  Copyright 2008-2010 Tao Xing, Xuesong Zhou @ University of Utah
//  tao.xing@utah.edu
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Data;
using System.Configuration;
using System.Text;

using System.Drawing;
using System.Drawing.Imaging;

using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;

using System.Xml;
using System.Net;

using UTMconv;


namespace Routing_Engine
{
    public partial class CNetwork
    {
        // network analysis

        public Bitmap demo_1(int NetworkWidth)
        {

            ////Use UTM to draw network
            //UTMconv.LatLongValue nval = new LatLongValue();
            //nval = UTMconv.LatLongValue.LatLongToUTM(up, left);
            //up = nval.utmNy;
            //left = nval.utmEx;
            //nval = UTMconv.LatLongValue.LatLongToUTM(low, right);
            //low = nval.utmNy;
            //right = nval.utmEx;

            //up = 4141807;
            //left = 569383;
            //low = 4128849;
            //right = 604395;
            

            ////draw small area range = 10 mile = 16000 meter
            //double range = 2600;
            //UTMconv.LatLongValue center = new LatLongValue();
            //center = UTMconv.LatLongValue.LatLongToUTM(37.4062328, -122.0696926);
            //up = center.utmNy + range;
            //low = center.utmNy - range;
            //left = center.utmEx - range;
            //right = center.utmEx + range;

            int NetworkHeight = (int)(((double)(NetworkWidth)) * (up - low) / (right - left));//keep the H/W ratio of network
            Pen[] pen_link = new Pen[]{ 
                new Pen(Color.Gray, 2), new Pen(Color.Red, 3), new Pen(Color.Yellow, 3), new Pen(Color.DeepSkyBlue, 3), 
                new Pen(Color.Green, 3), new Pen(Color.Orange, 0.5f), new Pen(Color.Black, 2), new Pen(Color.Black, 5)};

            Bitmap Bmp = new Bitmap(NetworkWidth, NetworkHeight);
            Graphics Gfx = Graphics.FromImage(Bmp);
            float[] a = new float[4];
            int count = 0;

            int[] link_type_count = new int[11];
            for (int l = 0; l < m_LinkSize; l++)
            {
                link_type_count[aryCLink[l].Link_Type]++;
            }

            //// draw with UTM
            //for (int l = 0; l < m_LinkSize; l++)
            //{
            //    //if (aryCLink[l].Link_Type <= 2)
            //    {
            //        Gfx.DrawLine(pen_link[0], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
            //            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
            //            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
            //            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
            //        count++;
            //    }
            //}
            //for (int l = 0; l < m_LinkSize; l++)
            //{
            //    if (aryCLink[l].TMC != null && TMCwithRealData.ContainsKey(aryCLink[l].TMC))
            //    {
            //        Gfx.DrawLine(pen_link[7], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
            //            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
            //            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
            //            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
            //    }
            //}

            // draw with LatLong
            for (int l = 0; l < m_LinkSize; l++)
            {
                if (aryCLink[l].Link_Type <= 2)
                {
                    Gfx.DrawLine(pen_link[7], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_Long - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_Lat) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_Long - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_Lat) / (up - low)));
                    //count++;
                }
            }
            count = 0;
            //for (int l = 0; l < m_LinkSize; l++)
            //{
            //    if (aryCLink[l].Link_Type <= 5)
            //    {
            //        Gfx.DrawLine(pen_link[0], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_Long - left) / (right - left)),
            //            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_Lat) / (up - low)),
            //            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_Long - left) / (right - left)),
            //            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_Lat) / (up - low)));
            //        count++;
            //    }
            //}
            //count = 0;
            Dictionary<int, int> zone = new Dictionary<int, int>();
            for (int n = 0; n < m_NodeSize; n++)
            {
                if (aryCNode[n].Node_AreaID > 0)
                {
                    if (!zone.ContainsKey(aryCNode[n].Node_AreaID))
                        zone.Add(aryCNode[n].Node_AreaID, 0);
                    Gfx.DrawEllipse(pen_link[7], (float)(NetworkWidth * (aryCNode[n].Node_Long - left) / (right - left)),
                            (float)(NetworkHeight * (up - aryCNode[n].Node_Lat) / (up - low)), 5, 5);
                    count++;
                }
            }

            Gfx.Dispose();
            return (Bmp);

        }

        public Bitmap DrawSensor(int NetworkWidth, int[] LoopSensorLocation, int[] AVISensorLocation)
        {

            ////Use UTM to draw network
            //UTMconv.LatLongValue nval = new LatLongValue();
            //nval = UTMconv.LatLongValue.LatLongToUTM(up, left);
            //up = nval.utmNy;
            //left = nval.utmEx;
            //nval = UTMconv.LatLongValue.LatLongToUTM(low, right);
            //low = nval.utmNy;
            //right = nval.utmEx;

            //up = 4141807;
            //left = 569383;
            //low = 4128849;
            //right = 604395;


            ////draw small area range = 10 mile = 16000 meter
            //double range = 2600;
            //UTMconv.LatLongValue center = new LatLongValue();
            //center = UTMconv.LatLongValue.LatLongToUTM(37.4062328, -122.0696926);
            //up = center.utmNy + range;
            //low = center.utmNy - range;
            //left = center.utmEx - range;
            //right = center.utmEx + range;

            int NetworkHeight = (int)(((double)(NetworkWidth)) * (up - low) / (right - left));//keep the H/W ratio of network
            Pen[] pen_link = new Pen[]{ 
                new Pen(Color.Gray, 2), new Pen(Color.Red, 3), new Pen(Color.Yellow, 3), new Pen(Color.DeepSkyBlue, 3), 
                new Pen(Color.Green, 3), new Pen(Color.Orange, 0.5f), new Pen(Color.Black, 2), new Pen(Color.Black, 5)};

            Bitmap Bmp = new Bitmap(NetworkWidth, NetworkHeight);
            Graphics Gfx = Graphics.FromImage(Bmp);
            float[] a = new float[4];
            int count = 0;

            // draw with LatLong
            // draw background
            for (int l = 0; l < m_LinkSize; l++)
            {
                //if (aryCLink[l].Link_Type <= 2)
                {
                    Gfx.DrawLine(pen_link[0], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_Long - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_Lat) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_Long - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_Lat) / (up - low)));
                    //count++;
                }
            }
            // draw Highway
            count = 0;
            for (int l = 0; l < m_LinkSize; l++)
            {
                //if (aryCLink[l].Link_Type <= 5 && aryCLink[l].LaneSize > 3)
                {
                    Gfx.DrawLine(pen_link[7], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_Long - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_Lat) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_Long - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_Lat) / (up - low)));
                    count++;
                }
            }
            // draw node
            count = 0;
            Dictionary<int, int> zone = new Dictionary<int, int>();
            // Create font and brush.
            Font drawFont = new Font("Arial", 23);
            SolidBrush drawBrush = new SolidBrush(Color.DeepSkyBlue);
            for (int n = 0; n < m_NodeSize; n++)
            {
                //if (aryCNode[n].Node_AreaID > 0)
                {
                    if (!zone.ContainsKey(aryCNode[n].Node_AreaID))
                        zone.Add(aryCNode[n].Node_AreaID, 0);
                    Gfx.DrawEllipse(pen_link[7], (float)(NetworkWidth * (aryCNode[n].Node_Long - left) / (right - left) - 3),
                            (float)(NetworkHeight * (up - aryCNode[n].Node_Lat) / (up - low) - 3), 6, 6);
                    //Gfx.DrawString(aryCNode[n].Node_ID.ToString(), drawFont, drawBrush, (float)(NetworkWidth * (aryCNode[n].Node_Long - left) / (right - left)),
                    //        (float)(NetworkHeight * (up - aryCNode[n].Node_Lat) / (up - low))); 
                    count++;
                }
            }
            // draw sensor
            SolidBrush Brush = new SolidBrush(Color.Black);
            if (LoopSensorLocation != null)
                for (int s = 0; s < LoopSensorLocation.Length; s++)
                {
                    Gfx.DrawEllipse(pen_link[7], (float)(NetworkWidth * ((aryCNode[m_NodeIDtoIndex[aryCLink[LoopSensorLocation[s]].FromID]].Node_Long * 2 + aryCNode[m_NodeIDtoIndex[aryCLink[LoopSensorLocation[s]].ToID]].Node_Long) / 3 - left) / (right - left) - 18),
                            (float)(NetworkHeight * (up - (aryCNode[m_NodeIDtoIndex[aryCLink[LoopSensorLocation[s]].FromID]].Node_Lat * 2 + aryCNode[m_NodeIDtoIndex[aryCLink[LoopSensorLocation[s]].ToID]].Node_Lat) / 3) / (up - low) - 18), 35, 35);
                }
            if (AVISensorLocation != null)
                for (int s = 0; s < AVISensorLocation.Length; s++)
                {
                    Gfx.FillRectangle(Brush, (float)(NetworkWidth * (aryCNode[AVISensorLocation[s]].Node_Long - left) / (right - left) - 15),
                            (float)(NetworkHeight * (up - aryCNode[AVISensorLocation[s]].Node_Lat) / (up - low) - 15), 30, 30);
                }

            Gfx.Dispose();
            return (Bmp);

        }

        public Bitmap DrawRoute(int NetworkWidth, CRoute route)
        {

            //Use UTM to draw network
            UTMconv.LatLongValue nval = new LatLongValue();
            nval = UTMconv.LatLongValue.LatLongToUTM(up, left);
            up = nval.utmNy;
            left = nval.utmEx;
            nval = UTMconv.LatLongValue.LatLongToUTM(low, right);
            low = nval.utmNy;
            right = nval.utmEx;

            //up = 4141807;
            //left = 569383;
            //low = 4128849;
            //right = 604395;


            //draw small area range = 10 mile = 16000 meter
            double range = 10000;
            UTMconv.LatLongValue center = new LatLongValue();
            double lat = (aryCNode[route.PathAry[0]].Node_Lat + aryCNode[route.PathAry[route.PathAry.Length - 1]].Node_Lat) / 2;
            double lng = (aryCNode[route.PathAry[0]].Node_Long + aryCNode[route.PathAry[route.PathAry.Length - 1]].Node_Long) / 2;
            center = UTMconv.LatLongValue.LatLongToUTM(lat, lng);
            up = center.utmNy + range/3;
            low = center.utmNy - range/3;
            left = center.utmEx - range;
            right = center.utmEx + range;

            int NetworkHeight = (int)(((double)(NetworkWidth)) * (up - low) / (right - left));//keep the H/W ratio of network
            Pen[] pen_link = new Pen[]{ 
                new Pen(Color.Gray, 2), new Pen(Color.Red, 3), new Pen(Color.Yellow, 3), new Pen(Color.DeepSkyBlue, 3), 
                new Pen(Color.Green, 3), new Pen(Color.Orange, 0.5f), new Pen(Color.Black, 4), new Pen(Color.Black, 10)};
            Pen pen_dash = new Pen(Color.Black, 5);
            float[] dashValues = { 2, 2};
            pen_dash.DashPattern = dashValues;

            Bitmap Bmp = new Bitmap(NetworkWidth, NetworkHeight);
            Graphics Gfx = Graphics.FromImage(Bmp);
            float[] a = new float[4];
            // draw background
            for (int l = 0; l < m_LinkSize; l++)
            {                
                Gfx.DrawLine(pen_link[0], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
            }
            // draw route
            for (int link = 0; link < route.LinkSeq.Length; link++)
            {
                int l = route.LinkSeq[link];
                Gfx.DrawLine(pen_dash, a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
            }

            // draw TMC links
            for (int link = 0; link < route.LinkSeq.Length; link++)
            {
                if (aryCLink[route.LinkSeq[link]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[link]].TMC))
                {
                    int l = route.LinkSeq[link];
                    Gfx.DrawLine(pen_link[7], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
                }
            }

            Gfx.Dispose();
            return (Bmp);

        }

        public Bitmap DrawRoute(int NetworkWidth, CRoute[] K_route)
        {

            //Use UTM to draw network
            UTMconv.LatLongValue nval = new LatLongValue();
            nval = UTMconv.LatLongValue.LatLongToUTM(up, left);
            up = nval.utmNy;
            left = nval.utmEx;
            nval = UTMconv.LatLongValue.LatLongToUTM(low, right);
            low = nval.utmNy;
            right = nval.utmEx;

            //up = 4141807;
            //left = 569383;
            //low = 4128849;
            //right = 604395;


            ////draw small area range = 10 mile = 16000 meter
            //double range = 10000;
            //UTMconv.LatLongValue center = new LatLongValue();
            //double lat = (aryCNode[K_route[0].PathAry[0]].Node_Lat + aryCNode[K_route[0].PathAry[K_route[0].PathAry.Length - 1]].Node_Lat) / 2;
            //double lng = (aryCNode[K_route[0].PathAry[0]].Node_Long + aryCNode[K_route[0].PathAry[K_route[0].PathAry.Length - 1]].Node_Long) / 2;
            //center = UTMconv.LatLongValue.LatLongToUTM(lat, lng);
            //up = center.utmNy + range / 3;
            //low = center.utmNy - range / 3;
            //left = center.utmEx - range;
            //right = center.utmEx + range;

            int NetworkHeight = (int)(((double)(NetworkWidth)) * (up - low) / (right - left));//keep the H/W ratio of network
            Pen[] pen_link = new Pen[]{ 
                new Pen(Color.Gray, 2), new Pen(Color.Red, 3), new Pen(Color.Yellow, 3), new Pen(Color.DeepSkyBlue, 3), 
                new Pen(Color.Green, 3), new Pen(Color.Orange, 0.5f), new Pen(Color.Black, 4), new Pen(Color.Black, 10)};
            Pen[] pen_route = new Pen[]{ 
                new Pen(Color.Gray, 10), new Pen(Color.Red, 10), new Pen(Color.Yellow, 10), new Pen(Color.DeepSkyBlue, 10), 
                new Pen(Color.Green, 10), new Pen(Color.Orange, 10), new Pen(Color.Black, 10), new Pen(Color.Pink, 10), new Pen(Color.Purple, 10)};
            Pen pen_dash = new Pen(Color.Black, 5);
            float[] dashValues = { 2, 2 };
            pen_dash.DashPattern = dashValues;

            Bitmap Bmp = new Bitmap(NetworkWidth, NetworkHeight);
            Graphics Gfx = Graphics.FromImage(Bmp);
            float[] a = new float[4];
            // draw background
            for (int l = 0; l < m_LinkSize; l++)
            {
                Gfx.DrawLine(pen_link[0], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
            }
            // draw route
            for (int r = 0; r < K_route.Length; r++)
            {
                if (K_route[r] != null)
                {
                    for (int link = 0; link < K_route[r].LinkSeq.Length; link++)
                    {
                        int l = K_route[r].LinkSeq[link];
                        Gfx.DrawLine(pen_route[r], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
                            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
                            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
                            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
                    }

                    //// draw TMC links
                    //for (int link = 0; link < K_route[r].LinkSeq.Length; link++)
                    //{
                    //    if (aryCLink[K_route[r].LinkSeq[link]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[link]].TMC))
                    //    {
                    //        int l = K_route[r].LinkSeq[link];
                    //        Gfx.DrawLine(pen_link[7], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
                    //            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
                    //            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
                    //            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
                    //    }
                    //}
                }
            }

            Gfx.Dispose();
            return (Bmp);

        }

        public Bitmap Draw(int map_level, int NetworkWidth, CgpsTrace[] gps, int[] link_seq)
        {


            //int NetworkWidth = 1000, NetworkHeight = 1000;

            //Use UTM to draw network
            double up_utm, low_utm, left_utm, right_utm;
            UTMconv.LatLongValue nval = new LatLongValue();
            nval = UTMconv.LatLongValue.LatLongToUTM(up, left);
            up_utm = nval.utmNy;
            left_utm = nval.utmEx;
            nval = UTMconv.LatLongValue.LatLongToUTM(low, right);
            low_utm = nval.utmNy;
            right_utm = nval.utmEx;

            //draw small area range = 10 mile = 16000 meter
            double range = 2600;
            int point = 0; // gps.Length - 1;
            up_utm = gps[point].north + range / 5;
            low_utm = gps[point].north - range;
            left_utm = gps[point].east - range;
            right_utm = gps[point].east + range / 5;


            int NetworkHeight = (int)(((double)(NetworkWidth)) * (up_utm - low_utm) / (right_utm - left_utm));//keep the H/W ratio of network


            Pen skyBluePen = new Pen(Brushes.DeepSkyBlue);
            skyBluePen.Width = 8.0F;
            // Set the LineJoin property.
            //skyBluePen.LineJoin = System.Drawing.Drawing2D.LineJoin.Bevel;
            Pen[] pen_link = new Pen[]{ 
                new Pen(Color.DarkGray, 0.5f), new Pen(Color.DarkRed, 0.5f),
                new Pen(Color.Green, 3), new Pen(Color.DeepSkyBlue, 2), 
                new Pen(Color.Gray, 1), new Pen(Color.Orange, 0.5f), 
                new Pen(Color.Red, 4), new Pen(Color.Gray, 0.5f)};
            double[] offset = new double[4];
            int l;

            Bitmap Bmp = new Bitmap(NetworkWidth, NetworkHeight);
            Graphics Gfx = Graphics.FromImage(Bmp);
            float[] a = new float[4];
            int count = 0;
            for (l = 0; l < m_LinkSize; l++) //l < network.m_LinkSize
            {
                //if (aryCLink[l].Link_Length > 0.7)
                //{
                //    Gfx.DrawLine(pen_link[6], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                //        a[1] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up_utm - low_utm)),
                //        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                //        a[3] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up_utm - low_utm)));
                //    count++;
                //}
                //else
                {
                    Gfx.DrawLine(pen_link[7], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                        a[1] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up_utm - low_utm)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                        a[3] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up_utm - low_utm)));
                }
            }
            
            //draw map-matched links
            if (link_seq != null)
            {
                Pen pen_mmlink = new Pen(Color.Red, 4);
                Pen pen_node = new Pen(Color.Red, 8);
                for (l = 0; l < link_seq.Length; l++) 
                {
                    Gfx.DrawLine(pen_mmlink, a[0] = (float)(NetworkWidth * (aryCNode[LinkList[link_seq[l], 0]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                        a[1] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[link_seq[l], 0]].Node_UTM_Northing) / (up_utm - low_utm)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[link_seq[l], 1]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                        a[3] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[link_seq[l], 1]].Node_UTM_Northing) / (up_utm - low_utm)));
                    Gfx.DrawEllipse(pen_node, (float)(NetworkWidth * (aryCNode[LinkList[link_seq[l], 0]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                           (float)(NetworkHeight * (up_utm - aryCNode[LinkList[link_seq[l], 0]].Node_UTM_Northing) / (up_utm - low_utm)), 1, 1);
                    Gfx.DrawEllipse(pen_node, (float)(NetworkWidth * (aryCNode[LinkList[link_seq[l], 1]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                        (float)(NetworkHeight * (up_utm - aryCNode[LinkList[link_seq[l], 1]].Node_UTM_Northing) / (up_utm - low_utm)), 1, 1);
                }
                Pen pen_mmlink_first = new Pen(Color.Yellow, 4);
                Gfx.DrawLine(pen_mmlink_first, a[0] = (float)(NetworkWidth * (aryCNode[LinkList[link_seq[0], 0]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                        a[1] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[link_seq[0], 0]].Node_UTM_Northing) / (up_utm - low_utm)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[link_seq[0], 1]].Node_UTM_Easting - left_utm) / (right_utm - left_utm)),
                        a[3] = (float)(NetworkHeight * (up_utm - aryCNode[LinkList[link_seq[0], 1]].Node_UTM_Northing) / (up_utm - low_utm)));   
            }

            //draw gps points
            if (gps != null)
            {
                Pen pen_gps = new Pen(Color.Black, 4);
                for (int g = 0; g < gps.Length; g++)
                {
                    Gfx.DrawEllipse(pen_gps, (float)(NetworkWidth * (gps[g].east - left_utm) / (right_utm - left_utm)),
                        (float)(NetworkHeight * (up_utm - gps[g].north) / (up_utm - low_utm)), 1, 1);
                }
                Pen pen_gps_first = new Pen(Color.Black, 6);
                Gfx.DrawEllipse(pen_gps_first, (float)(NetworkWidth * (gps[0].east - left_utm) / (right_utm - left_utm)),
                        (float)(NetworkHeight * (up_utm - gps[0].north) / (up_utm - low_utm)), 1, 1);

            }

            /*
            for (l = 0; l < m_LinkSize; l++) //l < network.m_LinkSize
            {
                if (aryCLink[l].Link_Name == "I-280")
                {
                    Gfx.DrawLine(pen_link[6], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
                }
            }*/

            ////Draw network with speed information
            //int k = 0;
            //for (l = 0; l < m_LinkSize; l++)
            //{
            //    if (aryCLink[l].Link_MapLevel == map_level && aryCLink[l].Link_TMC != null)
            //    {
            //        if (TMCIDtoIndex.ContainsKey(aryCLink[l].Link_TMC))
            //        {
            //            k++;
            //            if (Live_Speed[t, TMCIDtoIndex[aryCLink[l].Link_TMC]] >= 50)
            //            {
            //                Gfx.DrawLine(pen_link[4], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
            //                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
            //                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
            //                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));

            //            }
            //            else if (Live_Speed[t, TMCIDtoIndex[aryCLink[l].Link_TMC]] <= 30)
            //            {
            //                Gfx.DrawLine(pen_link[2], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
            //                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
            //                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
            //                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));

            //            }
            //            else
            //            {
            //                Gfx.DrawLine(pen_link[6], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
            //                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
            //                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
            //                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));

            //            }
            //        }
            //    }
            //}



            /*//import link offset
            for (l = 0; l < m_LinkSize; l++)
            {
                if (aryCLink[l].Link_MapLevel == map_level && aryCLink[l].Link_TMC != null)
                {
                    if (TMCIDtoIndex.ContainsKey(aryCLink[l].Link_TMC))
                    {
                        if (Live_Speed[t, TMCIDtoIndex[aryCLink[l].Link_TMC]] >= 45)
                        {
                            offset[1] = m * Math.Cos(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[3] = offset[1];
                            offset[0] = m * Math.Sin(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[2] = offset[0];

                            if (aryCNode[LinkList[l, 0]].Node_UTM_Easting > aryCNode[LinkList[l, 1]].Node_UTM_Easting)
                            {
                                Gfx.DrawLine(pen_link[4], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting + offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing + offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting + offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing + offset[3]) / (up - low)));
                            }
                            else
                            {
                                Gfx.DrawLine(pen_link[4], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing - offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing - offset[3]) / (up - low)));
                            }
                        }
                        else if (Live_Speed[t, TMCIDtoIndex[aryCLink[l].Link_TMC]] <= 25)
                        {
                            offset[1] = m * Math.Cos(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[3] = offset[1];
                            offset[0] = m * Math.Sin(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[2] = offset[0];
                            if (aryCNode[LinkList[l, 0]].Node_UTM_Easting > aryCNode[LinkList[l, 1]].Node_UTM_Easting)
                            {
                                Gfx.DrawLine(pen_link[2], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting + offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing + offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting + offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing + offset[3]) / (up - low)));
                            }
                            else
                            {
                                Gfx.DrawLine(pen_link[2], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing - offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing - offset[3]) / (up - low)));
                            }
                        }
                        else
                        {
                            offset[1] = m * Math.Cos(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[3] = offset[1];
                            offset[0] = m * Math.Sin(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[2] = offset[0];
                            if (aryCNode[LinkList[l, 0]].Node_UTM_Easting > aryCNode[LinkList[l, 1]].Node_UTM_Easting)
                            {
                                Gfx.DrawLine(pen_link[6], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting + offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing + offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting + offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing + offset[3]) / (up - low)));
                            }
                            else
                            {
                                Gfx.DrawLine(pen_link[6], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing - offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing - offset[3]) / (up - low)));
                            }
                        }
                    }

                }
            }
            */


            ////Draw nodes
            //Pen Dot = new Pen(Brushes.DeepSkyBlue, 1);
            //// Create font and brush.
            //Font drawFont = new Font("Arial", 8);
            //SolidBrush drawBrush = new SolidBrush(Color.DeepSkyBlue);
            //float[] b = new float[2];
            ////for (l = 0; l < m_NodeSize; l++) //show node ID
            ////{
            ////    Gfx.DrawString(Convert.ToString(aryCNode[l].Node_ID), drawFont, drawBrush, b[0] = (float)(NetworkWidth * (aryCNode[l].Node_UTM_Easting - left) / (right - left) - 2),
            ////        b[1] = (float)(NetworkHeight * (up - aryCNode[l].Node_UTM_Northing) / (up - low) - 2));
            ////}
            //for (l = 0; l < m_NodeSize; l++)
            //{
            //    Gfx.DrawEllipse(Dot, b[0] = (float)(NetworkWidth * (aryCNode[l].Node_UTM_Easting - left) / (right - left) - 2),
            //        b[1] = (float)(NetworkHeight * (up - aryCNode[l].Node_UTM_Northing) / (up - low) - 2), 1, 1);
            //}



            //shortest path
            // Graw shortest path




            //int origin_index = 20785, destination_index = 13579;//origin = 9237, destination = 1733;//origin = 2306, destination = 2251;
            //// int origin_index = m_NodeIDtoIndex[origin], destination_index = m_NodeIDtoIndex[destination];
            //Random rd = new Random();
            ////int origin_index = rd.Next(0, m_NodeSize - 1), destination_index = rd.Next(0, m_NodeSize - 1);
            //int origin = m_NodeIndextoID[origin_index], destination = m_NodeIndextoID[destination_index];
            //int node_index = origin_index;

            //int[] PathAry;
            //double Path_FFTT;
            //double Path_Distance;
            //Pen RedPen = new Pen(Color.Red);
            //RedPen.Width = 5;
            //SafetyPath(origin, destination, out PathAry, out Path_FFTT, out Path_Distance);
            //for (l = 0; l < PathAry.Length - 1; l++) //
            //{
            //    Gfx.DrawLine(RedPen, a[0] = (float)(NetworkWidth * (aryCNode[PathAry[l]].Node_UTM_Easting - left) / (right - left)),
            //        a[1] = (float)(NetworkHeight * (up - aryCNode[PathAry[l]].Node_UTM_Northing) / (up - low)),
            //        a[2] = (float)(NetworkWidth * (aryCNode[PathAry[l + 1]].Node_UTM_Easting - left) / (right - left)),
            //        a[3] = (float)(NetworkHeight * (up - aryCNode[PathAry[l + 1]].Node_UTM_Northing) / (up - low)));
            //}

            /*/single shortest path//////////////////////////////////////////////////////////////////////////
            int[] PathAry;
            int[] LinkSeq;
            double Path_TT;
            double Path_Distance;
            double Safety;
            double Cost;
            Pen RedPen = new Pen(Color.Red, 4);
            Pen Bus = new Pen(Color.Yellow, 7);
            Pen connector = new Pen(Color.Green, 6);


            ShortestPath_MultiMode(3, origin, destination, 500, out PathAry, out LinkSeq, out Path_TT, out Path_Distance, out Safety, out Cost);
            ShortestPath_MultiMode(0, origin, destination, 500, out PathAry, out LinkSeq, out Path_TT, out Path_Distance, out Safety, out Cost);
            ShortestPath_MultiMode(3, origin, destination, 500, out PathAry, out LinkSeq, out Path_TT, out Path_Distance, out Safety, out Cost);

            
            // Create font and brush.
            Font drawFont = new Font("Arial", 8);
            SolidBrush drawBrush = new SolidBrush(Color.DeepSkyBlue);
            float[] b = new float[2];

            for (l = 0; l < PathAry.Length - 1; l++) //with link name
            {
                if (aryCLink[LinkSeq[l]].Link_Type == 9)
                {
                    Gfx.DrawLine(Bus, a[0] = (float)(NetworkWidth * (aryCNode[PathAry[l]].Node_UTM_Easting - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[PathAry[l]].Node_UTM_Northing) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[PathAry[l + 1]].Node_UTM_Easting - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[PathAry[l + 1]].Node_UTM_Northing) / (up - low)));
                }
                else if (aryCLink[LinkSeq[l]].Link_Type == 10)
                {
                    Gfx.DrawLine(connector, a[0] = (float)(NetworkWidth * (aryCNode[PathAry[l]].Node_UTM_Easting - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[PathAry[l]].Node_UTM_Northing) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[PathAry[l + 1]].Node_UTM_Easting - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[PathAry[l + 1]].Node_UTM_Northing) / (up - low)));
                }
                else
                {
                    Gfx.DrawLine(RedPen, a[0] = (float)(NetworkWidth * (aryCNode[PathAry[l]].Node_UTM_Easting - left) / (right - left)),
                        a[1] = (float)(NetworkHeight * (up - aryCNode[PathAry[l]].Node_UTM_Northing) / (up - low)),
                        a[2] = (float)(NetworkWidth * (aryCNode[PathAry[l + 1]].Node_UTM_Easting - left) / (right - left)),
                        a[3] = (float)(NetworkHeight * (up - aryCNode[PathAry[l + 1]].Node_UTM_Northing) / (up - low)));
                }

                //Gfx.DrawString(aryCLink[LinkSeq[l]].Link_Name, drawFont, drawBrush, b[0] = (float)(NetworkWidth * (aryCNode[PathAry[l]].Node_UTM_Easting - left) / (right - left) - 2),
                //    b[1] = (float)(NetworkHeight * (up - aryCNode[PathAry[l]].Node_UTM_Northing) / (up - low) - 2));
            }
            
            ////////////////////////////////////////////////////////////////////////////////////////////////*/


            /*/KSP//////////////////////////////////////////////////////////////////////////////////////////////
            Pen[] KSP_Pen = new Pen[] { 
                new Pen(Color.Red, 5), new Pen(Color.Yellow, 5), new Pen(Color.White, 5),
                new Pen(Color.Brown, 5), new Pen(Color.HotPink, 5), new Pen(Color.LightGreen, 5),
                new Pen(Color.Chocolate, 5), new Pen(Color.Orange, 5), new Pen(Color.LightYellow, 5)};

            int[][] KPathAry, LinkSeq, KP_short;
            double[] Path_FFTT;
            double[] Path_Distance, SF, Cost;
            int k;
            //K_ShortestPath(origin, destination, out KPathAry, out LinkSeq, out Path_FFTT, out Path_Distance, out SF);
            //K_ShortestPath(origin, destination, true, 0, 0, 5, 9, out KPathAry, out LinkSeq, out Path_FFTT, out Path_Distance, out SF, out Cost);
            // PathClustering(KPathAry, out KP_short);

            for (k = 0; k < 6; k++)
                if (KPathAry[k] != null)
                    for (l = 0; l < KPathAry[k].Length - 1; l++) //
                    {
                        Gfx.DrawLine(KSP_Pen[k], a[0] = (float)(NetworkWidth * (aryCNode[KPathAry[k][l]].Node_UTM_Easting - left) / (right - left)),
                            a[1] = (float)(NetworkHeight * (up - aryCNode[KPathAry[k][l]].Node_UTM_Northing) / (up - low)),
                            a[2] = (float)(NetworkWidth * (aryCNode[KPathAry[k][l + 1]].Node_UTM_Easting - left) / (right - left)),
                            a[3] = (float)(NetworkHeight * (up - aryCNode[KPathAry[k][l + 1]].Node_UTM_Northing) / (up - low)));

                    }
            Contour_Generate(0, @"D:\DATA\Confidential\Navteq\New_York\", LinkSeq, Path_Distance, 0, m_TimeIntervalSize, 576, 255);
            int[] PathAryTransit;
            int[] LinkSeqTransit;
            double Path_TTTransit;
            double Path_DistanceTransit;
            double SafetyTransit;
            double CostTransit;
            //ShortestPath_MultiMode(3, origin, destination, 500, out PathAryTransit, out LinkSeqTransit, out Path_TTTransit, out Path_DistanceTransit, out SafetyTransit, out CostTransit);
            for (l = 0; l < PathAryTransit.Length - 1; l++) //
            {
                Gfx.DrawLine(KSP_Pen[7], a[0] = (float)(NetworkWidth * (aryCNode[PathAryTransit[l]].Node_UTM_Easting - left) / (right - left)),
                    a[1] = (float)(NetworkHeight * (up - aryCNode[PathAryTransit[l]].Node_UTM_Northing) / (up - low)),
                    a[2] = (float)(NetworkWidth * (aryCNode[PathAryTransit[l + 1]].Node_UTM_Easting - left) / (right - left)),
                    a[3] = (float)(NetworkHeight * (up - aryCNode[PathAryTransit[l + 1]].Node_UTM_Northing) / (up - low)));

            }
            LinkSeq = new int[1][];
            LinkSeq[0] = new int[LinkSeqTransit.Length];
            LinkSeqTransit.CopyTo(LinkSeq[0], 0);
            Path_Distance = new double[1] { Path_DistanceTransit };
            Contour_Generate(0, @"D:\DATA\Confidential\Navteq\New_York\", LinkSeq, Path_Distance, 0, m_TimeIntervalSize, 576, 255);
            ////shorter version
            //for (k = 0; k < 5; k++)
            //    if (KP_short[k] != null)
            //        for (l = 0; l < KP_short[k].Length - 1; l++) //
            //        {
            //            Gfx.DrawLine(KSP_Pen[k], a[0] = (float)(NetworkWidth * (aryCNode[KP_short[k][l]].Node_UTM_Easting - left) / (right - left)),
            //                a[1] = (float)(NetworkHeight * (up - aryCNode[KP_short[k][l]].Node_UTM_Northing) / (up - low)),
            //                a[2] = (float)(NetworkWidth * (aryCNode[KP_short[k][l + 1]].Node_UTM_Easting - left) / (right - left)),
            //                a[3] = (float)(NetworkHeight * (up - aryCNode[KP_short[k][l + 1]].Node_UTM_Northing) / (up - low)));

            //        }

            // Write OD node id
            // Create font and brush.
            Font drawFont = new Font("Arial", 8);
            SolidBrush drawBrush = new SolidBrush(Color.DeepSkyBlue);
            float[] b = new float[2];
            Gfx.DrawString(origin.ToString(), drawFont, drawBrush, b[0] = (float)(NetworkWidth * (aryCNode[origin_index].Node_UTM_Easting - left) / (right - left) - 2),
                b[1] = (float)(NetworkHeight * (up - aryCNode[origin_index].Node_UTM_Northing) / (up - low) - 2));
            Gfx.DrawString(destination.ToString(), drawFont, drawBrush, b[0] = (float)(NetworkWidth * (aryCNode[destination_index].Node_UTM_Easting - left) / (right - left) - 2),
                b[1] = (float)(NetworkHeight * (up - aryCNode[destination_index].Node_UTM_Northing) / (up - low) - 2));

            //node index to ID
            for (k = 0; k < 5; k++)
                if (KPathAry[k] != null)
                    for (l = 0; l < KPathAry[k].Length; l++) //
                    {
                        KPathAry[k][l] = m_NodeIndextoID[KPathAry[k][l]];
                    }
            /////////////////////////////////////////////////////////////////////////////////////*/



            Gfx.Dispose();
            return (Bmp);



        }

        public Bitmap Draw(int map_level, int departure_time_interval, int NetworkWidth) //Draw function for time-dependent SP
        {
            int l;

            //int NetworkWidth = 1000, NetworkHeight = 1000;

            //Use UTM to draw network
            UTMconv.LatLongValue nval = new LatLongValue();
            nval = UTMconv.LatLongValue.LatLongToUTM(up, left);
            up = nval.utmNy;
            left = nval.utmEx;
            nval = UTMconv.LatLongValue.LatLongToUTM(low, right);
            low = nval.utmNy;
            right = nval.utmEx;


            int NetworkHeight = (int)(((double)(NetworkWidth)) * (up - low) / (right - left));//keep the H/W ratio of network


            Pen skyBluePen = new Pen(Brushes.DeepSkyBlue);
            skyBluePen.Width = 8.0F;
            // Set the LineJoin property.
            //skyBluePen.LineJoin = System.Drawing.Drawing2D.LineJoin.Bevel;
            Pen[] pen_link = new Pen[]{ 
                new Pen(Color.DarkGray, 0.5f), new Pen(Color.DarkRed, 0.5f),
                new Pen(Color.Red, 6), new Pen(Color.DeepSkyBlue, 0.5f), new Pen(Color.Green, 6), new Pen(Color.Orange, 0.5f), new Pen(Color.Yellow, 6), new Pen(Color.Gray, 0.5f)};
            double[] offset = new double[4];
            double m = 200;
            int t = departure_time_interval;


            Bitmap Bmp = new Bitmap(NetworkWidth, NetworkHeight);
            Graphics Gfx = Graphics.FromImage(Bmp);
            float[] a = new float[4];
            //for (l = 0; l < m_LinkSize; l++) //l < network.m_LinkSize
            //{
            //    if (aryCLink[l].Link_MapLevel == map_level)
            //    {
            //        Gfx.DrawLine(pen_link[aryCLink[l].Link_Type], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - left) / (right - left)),
            //            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing) / (up - low)),
            //            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - left) / (right - left)),
            //            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (up - low)));
            //    }
            //}

            int k = 0, k2 = 0;
            for (l = 0; l < m_LinkSize; l++)
            {
                if (aryCLink[l].MapLevel == map_level && aryCLink[l].TMC != null)
                {
                    k++;
                    //if (aryCLink[l].Link_Type == 2)
                    //{
                    //    offset[1] = m * Math.Cos(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                    //    offset[3] = offset[1];
                    //    offset[0] = m * Math.Sin(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                    //    offset[2] = offset[0];

                    //    if (aryCNode[LinkList[l, 0]].Node_UTM_Easting > aryCNode[LinkList[l, 1]].Node_UTM_Easting)
                    //    {
                    //        Gfx.DrawLine(pen_link[4], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting + offset[0] - left) / (right - left)),
                    //            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing + offset[1]) / (up - low)),
                    //            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting + offset[2] - left) / (right - left)),
                    //            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing + offset[3]) / (up - low)));
                    //    }
                    //    else
                    //    {
                    //        Gfx.DrawLine(pen_link[4], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - offset[0] - left) / (right - left)),
                    //            a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing - offset[1]) / (up - low)),
                    //            a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - offset[2] - left) / (right - left)),
                    //            a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing - offset[3]) / (up - low)));
                    //    }
                    //}

                    //else //if (TMCIDtoIndex.ContainsKey(aryCLink[l].Link_TMC))
                    {
                        k2++;
                        if (aryCLink[l].TravelTime / LinkCost_TimeD[l, t] >= 0.70)
                        {
                            offset[1] = m * Math.Cos(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[3] = offset[1];
                            offset[0] = m * Math.Sin(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[2] = offset[0];

                            if (aryCNode[LinkList[l, 0]].Node_UTM_Easting > aryCNode[LinkList[l, 1]].Node_UTM_Easting)
                            {
                                Gfx.DrawLine(pen_link[4], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting + offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing + offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting + offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing + offset[3]) / (up - low)));
                            }
                            else
                            {
                                Gfx.DrawLine(pen_link[4], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing - offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing - offset[3]) / (up - low)));
                            }
                        }
                        else if (aryCLink[l].TravelTime / LinkCost_TimeD[l, t] <= 0.5)
                        {
                            offset[1] = m * Math.Cos(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[3] = offset[1];
                            offset[0] = m * Math.Sin(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[2] = offset[0];
                            if (aryCNode[LinkList[l, 0]].Node_UTM_Easting > aryCNode[LinkList[l, 1]].Node_UTM_Easting)
                            {
                                Gfx.DrawLine(pen_link[2], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting + offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing + offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting + offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing + offset[3]) / (up - low)));
                            }
                            else
                            {
                                Gfx.DrawLine(pen_link[2], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing - offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing - offset[3]) / (up - low)));
                            }
                        }
                        else
                        {
                            offset[1] = m * Math.Cos(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[3] = offset[1];
                            offset[0] = m * Math.Sin(Math.Atan((aryCNode[LinkList[l, 0]].Node_UTM_Northing - aryCNode[LinkList[l, 1]].Node_UTM_Northing) / (aryCNode[LinkList[l, 0]].Node_UTM_Easting - aryCNode[LinkList[l, 1]].Node_UTM_Easting)));
                            offset[2] = offset[0];
                            if (aryCNode[LinkList[l, 0]].Node_UTM_Easting > aryCNode[LinkList[l, 1]].Node_UTM_Easting)
                            {
                                Gfx.DrawLine(pen_link[6], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting + offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing + offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting + offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing + offset[3]) / (up - low)));
                            }
                            else
                            {
                                Gfx.DrawLine(pen_link[6], a[0] = (float)(NetworkWidth * (aryCNode[LinkList[l, 0]].Node_UTM_Easting - offset[0] - left) / (right - left)),
                                    a[1] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 0]].Node_UTM_Northing - offset[1]) / (up - low)),
                                    a[2] = (float)(NetworkWidth * (aryCNode[LinkList[l, 1]].Node_UTM_Easting - offset[2] - left) / (right - left)),
                                    a[3] = (float)(NetworkHeight * (up - aryCNode[LinkList[l, 1]].Node_UTM_Northing - offset[3]) / (up - low)));
                            }
                        }
                    }

                }
            }

            //shortest path
            // Graw shortest path


            //int origin = 1, destination = 1480;//origin = 9237, destination = 1733;//origin = 2306, destination = 2251;
            //int origin_index = m_NodeIDtoIndex[origin], destination_index = m_NodeIDtoIndex[destination];
            //int node_index = origin_index;

            /////////////////////////////////////////////////////TEST Time-dependent SP//////////////////////
            //int[] PredAry;
            //int[] PathAry;
            //int[] LinkSeq;
            //double Path_TT, Path_Distance;
            ////int departure_time_interval = 30;
            //Pen RedPen = new Pen(Color.Red, 10);
            ////Load_TimeD_TT_Values();
            //ShortestPath_Origin_TimeD(origin, departure_time_interval, out PredAry);
            //GetPathAry(1, origin_index, destination_index, PredAry, out PathAry);
            //GetRoute(PathAry, departure_time_interval, out LinkSeq, out Path_TT, out Path_Distance);

            //for (l = 0; l < PathAry.Length - 1; l++) //
            //{
            //    Gfx.DrawLine(RedPen, a[0] = (float)(NetworkWidth * (aryCNode[PathAry[l]].Node_UTM_Easting - left) / (right - left)),
            //        a[1] = (float)(NetworkHeight * (up - aryCNode[PathAry[l]].Node_UTM_Northing) / (up - low)),
            //        a[2] = (float)(NetworkWidth * (aryCNode[PathAry[l + 1]].Node_UTM_Easting - left) / (right - left)),
            //        a[3] = (float)(NetworkHeight * (up - aryCNode[PathAry[l + 1]].Node_UTM_Northing) / (up - low)));
            //}

            Gfx.Dispose();
            return (Bmp);



        }


        // chart generation 

        public void ReliabilityChart()
        {
            // read in sensor data csv ///////////////////////////////////////////////
            string szSrcLine, subStr;
            int index, subLength;
            int line = 0;
            string filepath = @"C:\DATA\San Diego\I8WB-Network\";
            string path = filepath;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            double distance_correction_factor = 0.2579;

            // get sensor data day size
            int DaySize = 0, DayTI = 288;
            path = filepath + "SensorDataDay001.csv";
            while (File.Exists(path))
            {
                DaySize++;
                path = filepath + "SensorDataDay" + (DaySize + 1).ToString("D3") + ".csv";
            }
            ///////////////////////////////////////////////////////////////////////
            double[,] SensorSpeed = new double[m_SensorSize, DaySize * DayTI];
            int[] sensor_count = new int[m_SensorSize];

            // read sensor data
            int sensor_ID = 0, sensor_flow = 0, sensor_index;
            double sensor_spd = 0;
            for (int f = 1; f <= DaySize; f++ )
            {
                path = filepath + "SensorDataDay" + f.ToString("D3") + ".csv";            
                nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
                nwsrInput = new StreamReader(nwfsInput);
                szSrcLine = nwsrInput.ReadLine(); // read label line
                while ((szSrcLine = nwsrInput.ReadLine()) != null && szSrcLine.Trim() != null)
                {
                    szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf(",");
                    if (index != -1)
                    {
                        for (int i = 1; i < 5; i++)
                        {
                            szSrcLine = szSrcLine.Trim();
                            index = szSrcLine.IndexOf(",");
                            if (index == -1)
                            {
                                subStr = null;
                            }
                            else
                            {
                                subStr = szSrcLine.Substring(0, index);
                            }
                            switch (i)
                            {
                                // case 1: date
                                case 2:
                                    sensor_ID = int.Parse(subStr);
                                    break;
                                case 3:
                                    sensor_flow = int.Parse(subStr);
                                    break;
                            }
                            subLength = szSrcLine.Length;
                            szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                        }
                        sensor_spd = double.Parse(szSrcLine);
                        // add to array
                        if (m_SensorIDtoIndex.ContainsKey(sensor_ID))
                        {
                            sensor_index = m_SensorIDtoIndex[sensor_ID];
                            SensorSpeed[sensor_index, sensor_count[sensor_index]] = sensor_spd;
                            sensor_count[sensor_index]++;
                        }

                    }
                }
                nwsrInput.Close();
                nwfsInput.Close();
            }

            // generate UB, LB arrays
            double[,] SensorSpeedUB = new double[m_SensorSize, DayTI];
            double[,] SensorSpeedLB = new double[m_SensorSize, DayTI];
            for (int s = 0; s < m_SensorSize; s++)
                for (int t = 0; t < DayTI; t++)
                    SensorSpeedLB[s,t] = 100;            
            double[,] SensorSpeedMean = new double[m_SensorSize, DayTI];
            double spd = 0;

            for (int s = 0; s < m_SensorSize; s++)
            {
                for (int t = 0; t < DayTI; t++)
                {
                    for (int d = 0; d < DaySize; d++) 
                    {
                        spd = SensorSpeed[s, d * DayTI + t];
                        if (spd >= SensorSpeedUB[s, t])
                            SensorSpeedUB[s, t] = spd;
                        else if (spd <= SensorSpeedLB[s, t])
                            SensorSpeedLB[s, t] = spd;
                        SensorSpeedMean[s, t] += spd;
                    }
                    SensorSpeedMean[s, t] = SensorSpeedMean[s, t] / (double)DaySize;
                }
            }

            // find path travel time for each TI /////////////////////////////////////////////////
            int origin = 13, destination = 123, path_size = 5;   // int origin = 13, destination = 123         
            double[][] PathTT = new double[path_size * 2][]; // draw 2 lines for each path: UB and LB
            for (int p = 0; p < path_size * 2; p++)
            {
                PathTT[p] = new double[DayTI];
            }

            CRoute[] K_routes, routes = new CRoute[path_size];
            
            // K_ShortestPath(origin, destination, false, 0, 0, path_size, 9,out K_routes);
            K_ShortestPath_Unsorted(origin, destination, 0, 9, out K_routes);
            routes[0] = K_routes[0];
            routes[1] = K_routes[0];
            routes[2] = K_routes[4];
            routes[3] = K_routes[4];
            routes[4] = K_routes[8];

            for (int t = 0; t < DayTI; t++)
            {    
                // find path travel time UB and LB 
                for (int p = 0; p < path_size; p++)
                {
                    int link_size = routes[p].LinkSeq.Length;
                    for (int l = 0; l < link_size; l++)
                    {
                        int link_index = routes[p].LinkSeq[l];
                        int sensorID = aryCLink[link_index].SensorID;
                        if (sensorID != 0)
                        {
                            sensor_index = m_SensorIDtoIndex[sensor_ID];
                            PathTT[p * 2][t] += aryCLink[link_index].Link_Length / SensorSpeedUB[sensor_index, t] * 60 * distance_correction_factor;
                            PathTT[p * 2 + 1][t] += aryCLink[link_index].Link_Length / SensorSpeedLB[sensor_index, t] * 60 * distance_correction_factor;
                        }
                        else
                        {
                            PathTT[p * 2][t] += aryCLink[link_index].TravelTime * distance_correction_factor;
                            PathTT[p * 2 + 1][t] += aryCLink[link_index].TravelTime * distance_correction_factor;
                        }
                    }
                }

            }

            // generate string for web service
            string info = "", dir = "";
            for (int k = 0; k < path_size; k++)
            {
                info = info + "$" + (float)(routes[k].PathTime * distance_correction_factor + 0.0001) + "*" +
                    (float)(routes[k].PathDist * distance_correction_factor + 0.0001) + "*" + (float)(routes[k].PathCost * distance_correction_factor + 0.0001) + "*";
                for (int l = 0; l < routes[k].PathAry.Length; l++)
                {
                    info = info + (aryCNode[routes[k].PathAry[l]].Node_Lat + 0.000001) + ":" + (aryCNode[routes[k].PathAry[l]].Node_Long + 0.000001) + ":";
                }
                info = info + "%";
                //add link ids
                for (int l = 0; l < routes[k].LinkSeq.Length; l++)
                {
                    if (aryCLink[routes[k].LinkSeq[l]].ID.Dir)
                        dir = "+";
                    else
                        dir = "-";
                    info = info + aryCLink[routes[k].LinkSeq[l]].ID.ID + dir + ",";
                }
                info = info + "@";
            }

            // draw reliability chart ////////////////////////////////////////////////
            double[] X_data = new double[DayTI];
            for (int t = 0; t < DayTI; t++)
                X_data[t] = (double)(t) / 12.0; // 12 TI each hour
            int[] X_label = new int[]{0, 48, 96, 144, 192, 240};
            int[] Fill_UB = new int[path_size];
            int[] Fill_LB = new int[path_size];
            for (int p = 0; p < path_size; p++)
            {
                Fill_UB[p] = p * 2;
                Fill_LB[p] = p * 2 + 1;
            }

            Bitmap bmp = Chart(0, 0, X_data, PathTT, X_label, null, null, "Time Interval", 
                "Path Travel Time (Min)", "Path Travel Time Reliability (min)", true, true, true, Fill_UB, Fill_LB);
            bmp.Save("Chart.png", ImageFormat.Png);
            bmp.Dispose();
        }

        public Bitmap Chart(int width, int height, double[] X_data, double[][] Y_data, int[] X_label, double[] Y_label, Pen[] pens, 
            string X_title, string Y_title, string chart_title, bool X_grid, bool Y_grid, bool Fill, int[] Fill_UB, int[] Fill_LB)
        {
            //TODO: add chart class            

            if (X_data == null || Y_data == null || X_data.Length != Y_data[0].Length)
                return null;
            
            // default setting: width, height, pens, X_grid on, Y_grid on
            int X_label_size = 6, Y_label_size = 4;
            double[] X_label_value, Y_label_value;
            if (width <= 0)
                width = 1000;
            if (height <= 0)
                height = 600;
            
            // find data range
            double X_min = X_data[0], X_max = X_data[X_data.Length - 1];
            double Y_min = Y_data[0][0], Y_max = Y_data[0][0];
            int Y_1D_size = Y_data.Length, Y_2D_size = Y_data[0].Length;
            int X_size = X_data.Length;
            for (int i = 0; i < Y_1D_size; i++)
                for (int j = 0; j < Y_2D_size; j++)
                {
                    if (Y_data[i][j] >= Y_max)
                        Y_max = Y_data[i][j];
                    if (Y_data[i][j] <= Y_min)
                        Y_min = Y_data[i][j];
                }

            if (pens == null)
            {
                pens = new Pen[]{new Pen(Color.Blue, 4), new Pen(Color.Blue, 4), new Pen(Color.Green, 4), new Pen(Color.Green, 4), new Pen(Color.DarkOrange, 4), 
                    new Pen(Color.Red, 4), new Pen(Color.Black, 4), new Pen(Color.Purple, 4), new Pen(Color.Pink, 4)};
            }
            Pen pen_axis = new Pen(Color.Black, 3), pen_grid = new Pen(Color.Black, 1);

            // assign labels
            if (X_label != null)
            {
                X_label_size = X_label.Length;
                X_label_value = new double[X_label_size];
                for (int l = 0; l < X_label_size; l++)
                    X_label_value[l] = X_data[X_label[l]];
            }
            else
            {
                X_label_value = new double[X_label_size];
                for (int l = 0; l < X_label_size; l++)
                    X_label_value[l] = X_data[X_data.Length / X_label_size * l];
            }

            if (Y_label != null)
            {
                Y_label_size = Y_label.Length;
                Y_label_value = new double[Y_label_size];
                for (int l = 0; l < Y_label_size; l++)
                    Y_label_value[l] = Y_label[l];
            }
            else
            {
                Y_label_value = new double[Y_label_size];
                for (int l = 0; l < Y_label_size; l++)
                    Y_label_value[l] = (Y_max - Y_min) / Y_label_size * l + Y_min;
            }           


            // draw chart /////////////////////////////////////////////////////////////
            // drawing order: grid, axis, data lines (from last to first), labels, titles.
            Bitmap Bmp = new Bitmap(width, height);
            Graphics Gfx = Graphics.FromImage(Bmp);

            float data_up = (float)(height * 0.2), data_low = (float)(height * 0.9), data_left = (float)(width * 0.15), data_right = (float)(width * 0.9);

            // draw grid and label
            pen_grid.DashPattern = new float[]{4, 2}; 
            float[] a = new float[4];
            Font drawFont = new Font("Times New Roman", 20);
            SolidBrush drawBrush = new SolidBrush(Color.Black);
            for (int gx = 0; gx < X_label_size; gx++)
            {
                Gfx.DrawLine(pen_grid, a[0] = (float)((X_label_value[gx] - X_min) / (X_max - X_min) * (data_right - data_left) + data_left),
                    a[1] = data_up, a[2] = (float)((X_label_value[gx] - X_min) / (X_max - X_min) * (data_right - data_left) + data_left), a[3] = data_low);
                Gfx.DrawString(X_label_value[gx].ToString() + "h", drawFont, drawBrush,
                    (float)((X_label_value[gx] - X_min) / (X_max - X_min) * (data_right - data_left) + data_left - width * 0.02), (float)(data_low + height * 0.02));
            }
            for (int gy = 0; gy < Y_label_size; gy++)
            {
                Gfx.DrawLine(pen_grid, a[0] = data_left, a[1] = (float)(data_low - (Y_label_value[gy] - Y_min) / (Y_max - Y_min) * (data_low - data_up)),
                    a[2] = data_right, a[3] = (float)(data_low - (Y_label_value[gy] - Y_min) / (Y_max - Y_min) * (data_low - data_up)));
                Gfx.DrawString(Math.Round(Y_label_value[gy]).ToString(), drawFont, drawBrush, (float)(width * 0.05),
                    (float)(data_low - (Y_label_value[gy] - Y_min) / (Y_max - Y_min) * (data_low - data_up) - height * 0.04));
            }

            // draw axis
            // X
            Gfx.DrawLine(pen_axis, a[0] = data_left, a[1] = data_low, a[2] = data_right, a[3] = data_low);
            // Y
            Gfx.DrawLine(pen_axis, a[0] = data_left, a[1] = data_up, a[2] = data_left, a[3] = data_low);
            Gfx.DrawLine(pen_axis, a[0] = data_right, a[1] = data_up, a[2] = data_right, a[3] = data_low);

            // draw data lines (from last to first)
            if (Fill) // if need fill area, draw polygon
            {
                System.Drawing.Drawing2D.HatchBrush[] FillBrush = new System.Drawing.Drawing2D.HatchBrush[]{
                    new System.Drawing.Drawing2D.HatchBrush(System.Drawing.Drawing2D.HatchStyle.BackwardDiagonal, pens[0].Color, Color.White), 
                    new System.Drawing.Drawing2D.HatchBrush(System.Drawing.Drawing2D.HatchStyle.ForwardDiagonal, pens[1].Color, Color.White), 
                    new System.Drawing.Drawing2D.HatchBrush(System.Drawing.Drawing2D.HatchStyle.Vertical, pens[2].Color, Color.White), 
                    new System.Drawing.Drawing2D.HatchBrush(System.Drawing.Drawing2D.HatchStyle.Horizontal, pens[3].Color, Color.White), 
                    new System.Drawing.Drawing2D.HatchBrush(System.Drawing.Drawing2D.HatchStyle.Cross, pens[4].Color, Color.White)};
                int polygon_size = Y_1D_size / 2;
                for (int p = polygon_size - 1; p >= 0; p--)
                {
                    PointF[] point = new PointF[X_data.Length * 2];
                    for (int l = 0; l < X_size; l++)
                    {
                        point[l] = new PointF((float)((X_data[l] - X_min) / (X_max - X_min) * (data_right - data_left) + data_left), 
                            (float)(data_low - (Y_data[p*2][l] - Y_min) / (Y_max - Y_min) * (data_low - data_up)));
                        point[X_size * 2 - 1 - l] = new PointF((float)((X_data[l] - X_min) / (X_max - X_min) * (data_right - data_left) + data_left),
                            (float)(data_low - (Y_data[p*2+1][l] - Y_min) / (Y_max - Y_min) * (data_low - data_up)));
                    }
                    Gfx.FillPolygon(FillBrush[p], point);
                    Gfx.DrawPolygon(pens[p], point);                    
                }
            }
            else // draw line
            {

            }

            // write titles
            Gfx.DrawString(chart_title, drawFont, drawBrush, (float)(width * 0.3), (float)(height * 0.05));


            Gfx.Dispose();
            return (Bmp);
        }

        public void Generate_Chart(double[] tt, double[] scale, string filepath, string filename, int Width, int Height, string color)
        {
            int i = 0;
            string temp = null;
            string baseUrl = "http://chart.apis.google.com/chart?";

            // Chart type
            string CType = "cht=lc";
            // Chart line color
            string CLineColor = "chco=" + color;
            // Chart fill color
            string CFillColor = "chf=bg,s,ffffff";
            // Data fill color
            //string CDataFillColor = "chm=B,76A4FB,0,1,0";  //+ CDataFillColor + "&"
            // Chart size
            string CSize = "chs=" + Width + "x" + Height; //"chs=700x300";
            
            if (tt.Length > 288)
            {
                for (i = 0; i < m_TimeIntervalSize; i++)
                {
                    tt[i] = tt[i*(tt.Length / m_TimeIntervalSize)];
                }
            }
            temp = Convert.ToString(tt[0]);
            for (i = 1; i < m_TimeIntervalSize; i++)
            {
                temp += "," + tt[i];
            }
            int cut = 0;
            while (temp.Length > 1750)
            {
                temp = Convert.ToString(tt[0]);
                cut++;
                for (i = 1; i < m_TimeIntervalSize; i++)
                {
                    if (i % (24 - cut) != 0)
                        temp += "," + tt[i];
                }
            }

            // Data
            string CData = "chd=t:" + temp;
            // Chart Axis type
            string CAxisType = "chxt=x,y";
            // Axis Range
            string CAxisRange = "chxl=0:|0|2am|4am|6am|8am|10am|noon|2pm|4pm|6pm|8pm|10pm|midnight|1:|" + scale[2] + "|" + ((scale[1] - scale[2]) / 2 + scale[2]) + "|" + scale[1];
            // Axis color
            string CAxisColor = "chxs=0,000000|1,000000";
            // Chart Legend
            //string CLegend = "chdl=Path+1";//|Path+2";
            // Chart Title
            string CTitle = "chtt=Travel+Time+Plot";
            // Chart Title color
            string CTitleColor = "chts=000000,16";
            // Chart Reference Lines
            //double temp_min = scale[2]/100;
            //double temp_avg = (scale[0] - scale[2]) / 100;
            //double temp_max = (scale[1] - scale[0]) / 100;
            //double temp_final = (100 - scale[1]) / 100;

            // Chart Scaling
            string CScale = "chds=" + scale[2] + "," + scale[1];

            //string CRefLines = "chf=c,ls,90,999999," + temp_min + ",BBBBBB," + temp_avg + ",DDDDDD," + temp_max + ",FFFFFF," + temp_final;

            string imgQuery = baseUrl + CType + "&" + CLineColor + "&" + CFillColor + "&" + CSize + "&" + CData + "&" + CAxisType + "&" + CAxisRange + "&" + CAxisColor + "&" + CTitle + "&" + CTitleColor + "&" + CScale;

            //////////////////////////////////////////////////////
            // Get and Save image from URL
            byte[] b = null;
            HttpWebRequest myReq = null;
            WebResponse myResp = null;
            Stream stream;
            BinaryReader br = null;
            FileStream fs = new FileStream(filepath + filename, FileMode.Create);
            BinaryWriter w = new BinaryWriter(fs);

            while (w.BaseStream.Length == 0)
            {
                myReq = (HttpWebRequest)WebRequest.Create(imgQuery);
                myResp = myReq.GetResponse();
                stream = myResp.GetResponseStream();
                br = new BinaryReader(stream);
                b = br.ReadBytes(500000);
                w.Write(b);
            }

            br.Close();
            myResp.Close();

            fs.Close();
            w.Close();


        }

        //TODO: change Contour_Generate function to generate contours for only one route
        public bool Contour_Generate(int User_ID, string filepath, int[][] K_LinkSeq, double[] K_Dist, int StartTimeInterval, int EndTimeInterval, int Width, int Height)
        {

            Bitmap bmp;
            int Path_size = K_LinkSeq.GetLength(0);
            double[][] TT = new double[Path_size][];
            double[][] scale = new double[Path_size][]; ;
            string filename;
            string[] colors = null;
            switch (Path_size)
            {
                case 6:
                    colors = new string[6] { "ffff00", "0000ff", "008B00", "FF8C00", "ff0000", "000000" };
                    break;
                case 5:
                    colors = new string[5] { "ffff00", "0000ff", "008B00", "FF8C00", "ff0000" };
                    break;                
                case 1:
                    colors = new string[1] { "8B4513" };
                    break;
            }
            for (int i = 0; i < Path_size; i++)
            {
                if (K_LinkSeq[i] != null)
                {
                    if (Path_size > 1)
                    {
                        filename = i.ToString();
                        bmp = RealTime_Contour(false, K_LinkSeq[i], K_Dist[i], StartTimeInterval, EndTimeInterval, Width, Height, out TT[i], out scale[i]);
                        bmp.Save(filepath + "TS_" + User_ID + "_" + filename + ".png", ImageFormat.Png);
                        bmp.Dispose();
                        Generate_Chart(TT[i], scale[i], filepath, "TT_" + User_ID + "_" + filename + ".png", Width, Height, colors[i]);
                    }
                    else
                    {
                        filename = "6";
                        bmp = RealTime_Contour(true, K_LinkSeq[i], K_Dist[i], StartTimeInterval, EndTimeInterval, Width, Height, out TT[i], out scale[i]);
                        bmp.Save(filepath + "TS_" + User_ID + "_" + filename + ".png", ImageFormat.Png);
                        bmp.Dispose();
                        Generate_Chart(TT[i], scale[i], filepath, "TT_" + User_ID + "_" + filename + ".png", Width, Height, colors[i]);
                    }
                }
            }
            return true;

        }


        public Bitmap RealTime_Contour(bool transit_flag, int[] LinkSeq, double Distance, int StartTimeInterval, int EndTimeInterval, int Width, int Heigth, out double[] TT, out double[] scale)
        {
            Bitmap Bmp = new Bitmap(Width, Heigth);
            Graphics Gfx = Graphics.FromImage(Bmp);
            int x, y;
            double single_width = (double)Width / (double)(EndTimeInterval - StartTimeInterval), single_heigth;
            double sum_length = 0, temp_x;
            double plot_heigth = (double)(Heigth - 30); // leave space for title

            if (LinkSeq == null)
            {
                Gfx.Dispose();
                TT = null;
                scale = null;
                return Bmp = null;
            }
            // Create solid brush.
            SolidBrush[] bru = { new SolidBrush(Color.Green), new SolidBrush(Color.Yellow), new SolidBrush(Color.Red), };
            Rectangle rect;
            for (int link = 0; link < LinkSeq.Length; link++)
            {
                single_heigth = (aryCLink[LinkSeq[link]].Link_Length / Distance) * plot_heigth;
                if (aryCLink[LinkSeq[link]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[LinkSeq[link]].TMC))// && TMCIDtoIndex.ContainsKey(aryCLink[LinkSeq[link]].Link_TMC))
                {
                    if (single_heigth < 3)
                        single_heigth = 3;
                }
                sum_length = sum_length + aryCLink[LinkSeq[link]].Link_Length;
                y = Heigth - (int)((sum_length / Distance) * plot_heigth);
                if (y >= Heigth)
                    y = Heigth;
                for (int TI = StartTimeInterval; TI < EndTimeInterval; TI++)
                {
                    temp_x = single_width * (TI - StartTimeInterval);
                    x = (int)(Math.Floor(temp_x)) - 1 + 27; // leave a space for writing A B
                    rect = new Rectangle(x, y, (int)single_width, (int)single_heigth);

                    if (aryCLink[LinkSeq[link]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[LinkSeq[link]].TMC))// && TMCIDtoIndex.ContainsKey(aryCLink[LinkSeq[link]].Link_TMC))
                    {
                        if (aryCLink[LinkSeq[link]].TravelTime / LinkCost_TimeD[LinkSeq[link], TI] >= 0.90)
                            Gfx.FillRectangle(bru[0], rect);
                        else if (aryCLink[LinkSeq[link]].TravelTime / LinkCost_TimeD[LinkSeq[link], TI] <= 0.55)
                            Gfx.FillRectangle(bru[2], rect);
                        else
                            Gfx.FillRectangle(bru[1], rect);
                        
                    }
                }
            }
            Font drawFont = new Font("Arial", 16, FontStyle.Bold, GraphicsUnit.Pixel);
            SolidBrush drawBrush = new SolidBrush(Color.Black);
            float[] b = new float[2];
            Gfx.DrawString("A", drawFont, drawBrush, 5, Heigth - 20);
            Gfx.DrawString("B", drawFont, drawBrush, 5, 40);
            Gfx.DrawString("Speed Contour", drawFont, drawBrush, 240, 10);
            
            Gfx.Dispose();

            /*/calculating dynamic travel time

            double VoverC;
            double gamma = 0.9;
            double alpha = 0.15;
            double beta = 4.0;
            double a, b = 0, c;

            TT = new double[EndTimeInterval - StartTimeInterval];
            double curr_Time = 0;
            double max_value = 0, min_value = 1000, average_value = 0;
            int curr_Interval;
            for (int i = StartTimeInterval; i < EndTimeInterval; i++)
            {
                curr_Time = (double)(i * m_TimeInterval);
                for (int j = 0; j < LinkSeq.Length; j++)
                {
                    // travel time calculation
                    if (i < 288)
                    {
                        curr_Interval = (int)Math.Floor(curr_Time / m_TimeInterval) % m_TimeIntervalSize;
                        TT[i] += LinkCost_TimeD[LinkSeq[j], curr_Interval];
                        curr_Time += LinkCost_TimeD[LinkSeq[j], curr_Interval];
                    }

                    // reliable travel time calculation
                    else
                    {
                        curr_Interval = (int)Math.Floor(curr_Time / m_TimeInterval) % m_TimeIntervalSize;
                        c = LinkCost_TimeD[LinkSeq[j], curr_Interval] / aryCLink[LinkSeq[j]].Link_FFTT;
                        if (c < 1)
                        {
                            c = 1;
                        }
                        VoverC = Math.Pow(((c - 1) / alpha), (double)1 / beta);
                        a = aryCLink[LinkSeq[j]].Link_FFTT; // LinkCost_TimeD[LinkSeq[j], curr_Interval]; //
                        if (c != 1)
                        {
                            //b = alpha * beta * Math.Pow(VoverC, beta - 3) * gamma * aryCLink[LinkSeq[j]].Link_FFTT;
                            b = (Math.Pow(c, 2) - 1) * aryCLink[LinkSeq[j]].Link_FFTT * gamma;
                        }
                        else
                        {
                            b = 0;
                        }
                        TT[i] += (a + b);
                        curr_Time += (a + b);
                    }

                }

                TT[i] = Math.Floor(TT[i] * 100) / 100;

                average_value += TT[i];
                if (TT[i] > max_value)
                    max_value = TT[i];
                if (TT[i] < min_value)
                    min_value = TT[i];
            }
            average_value = Math.Floor(average_value / (double)(EndTimeInterval - StartTimeInterval) * 100) / 100;
            if (min_value * 2 - average_value > 0)
            {
                min_value = Math.Floor((min_value * 2 - average_value) / 5) * 5;
            }
            else
            {
                min_value = 0;
            }
            max_value = Math.Floor((max_value + average_value - min_value) / 5) * 5 + 5;
            scale = new double[] { average_value, max_value, min_value };
            //////////////////////////////////////////////////////*/

            //calculating dynamic travel time
            
            double curr_Time = 0;
            double max_value = 0, min_value = 1000, average_value = 0;
            int curr_Interval;
            int zero_count = 0;
            string str = null;
            if (transit_flag == false)
            {
                TT = new double[EndTimeInterval - StartTimeInterval];
                for (int i = StartTimeInterval; i < EndTimeInterval; i++)
                {
                    curr_Time = (double)(i * m_TimeInterval);
                    for (int j = 0; j < LinkSeq.Length; j++)
                    {
                        curr_Interval = (int)Math.Floor(curr_Time / m_TimeInterval) % m_TimeIntervalSize;
                        TT[i] += LinkCost_TimeD[LinkSeq[j], curr_Interval];
                        curr_Time += LinkCost_TimeD[LinkSeq[j], curr_Interval];
                    }
                    TT[i] = Math.Floor(TT[i] * 100) / 100;
                    average_value += TT[i];
                    if (TT[i] > max_value)
                        max_value = TT[i];
                    if (TT[i] < min_value)
                        min_value = TT[i];
                }
            }
            else
            {
                EndTimeInterval = m_TimeIntervalTransitSize;
                TT = new double[EndTimeInterval - StartTimeInterval];
                for (int i = StartTimeInterval; i < EndTimeInterval; i++)
                {
                    curr_Time = (double)(i * m_TimeIntervalTransit);
                    for (int j = 0; j < LinkSeq.Length; j++)
                    {
                        curr_Interval = (int)Math.Floor(curr_Time / m_TimeIntervalTransit) % m_TimeIntervalTransitSize;
                        TT[i] += LinkCost_TimeD_Transit[LinkSeq[j], curr_Interval];
                        curr_Time += LinkCost_TimeD_Transit[LinkSeq[j], curr_Interval];
                    }
                    //TT[i] = Math.Floor(TT[i] * 100) / 100;
                    str = TT[i].ToString().Substring(0, 4);
                    if (str.IndexOf(".") == 3)
                        str = str.Substring(0, 3);
                    else if (str.IndexOf(".") == -1)
                        str = "0";
                    TT[i] = double.Parse(str);

                }                
                for (int i = StartTimeInterval; i < EndTimeInterval; i++)
                {
                    if (TT[i] > 1.5 * TT[EndTimeInterval / 2] || TT[i] == 0)
                    {
                        TT[i] = 0; // TT[i] = 1.7 * TT[EndTimeInterval / 2];
                        zero_count++;
                    }
                    average_value += TT[i];
                    if (TT[i] > max_value)
                        max_value = TT[i];
                    if (TT[i] < min_value && TT[i] != 0)
                        min_value = TT[i];
                }
            }
            average_value = Math.Floor(average_value / (double)(EndTimeInterval - StartTimeInterval - zero_count) * 100) / 100;
            if (min_value * 2 - average_value > 0)
            {
                min_value = Math.Floor((min_value * 2 - average_value) / 5) * 5;
            }
            else
            {
                min_value = 0;
            }
            max_value = Math.Floor((max_value + average_value - min_value) / 5) * 5 + 5;
            scale = new double[] { average_value, max_value, min_value };
            for (int j = 0; j < EndTimeInterval; j++)
            {
                if (Math.Floor(TT[j]) - TT[j] == 0)
                    TT[j] += 1;
            }
            return Bmp;

        }

        //TODO: change function TrafficColorCode
        public bool TrafficColorCode(int DepartureTimeInterval, int[] LinkSeq, out int[] Tcolor)
        {
            if (LinkSeq == null)
            {
                Tcolor = null;
                return false;
            }
            Tcolor = new int[LinkSeq.Length];

            for (int link = 0; link < LinkSeq.Length; link++)
            {
                //This part of code is used to determing congestion condition
                //based on the ratio between real time TT and historical TT
                /*
                if (aryCLink[LinkSeq[link]].Link_FFTT / LinkCost_TimeD[LinkSeq[link], DepartureTimeInterval] >= 0.90)
                    Tcolor[link] = 0;
                else if (aryCLink[LinkSeq[link]].Link_FFTT / LinkCost_TimeD[LinkSeq[link], DepartureTimeInterval] <= 0.55)
                    Tcolor[link] = 2;
                else
                    Tcolor[link] = 1;
                ///////////////////////////////*/

                //this is the demo code, congestion color assigned based on the speed of link
                if (aryCLink[LinkSeq[link]].SpeedLimit <= 40)
                    Tcolor[link] = 0;
                else if (aryCLink[LinkSeq[link]].SpeedLimit >= 60)
                    Tcolor[link] = 2;
                else
                    Tcolor[link] = 1;
            }

            return true;

        }

        public bool CoordinateConvertRectToImage(double x, double y, CBound bound, double ImageWidth, double ImageHeight, out double ImageX, out double ImageY)
        {
            if (x < bound.left || x > bound.right || y < bound.low || y > bound.up || bound.up <= bound.low || bound.left >= bound.right)
            {
                ImageX = 0;
                ImageY = 0;
                return false;
            }
            ImageX = ImageWidth * ((x - bound.left) / (bound.right - bound.left));
            ImageY = ImageHeight * ((bound.up - y) / (bound.up - bound.low));
            return true;
        }


    }
}