//  Copyright 2008-2010 Tao Xing, Xuesong Zhou @ University of Utah
//  tao.xing@utah.edu
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Text;

using System.Drawing;
using System.Drawing.Imaging;

using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;

using System.Xml;
using System.Net;

using UTMconv;


namespace Routing_Engine
{
    public partial class CNetwork
    {
        // file input functions

        public class DirectionalIDEqualityComparer : IEqualityComparer<DirectionalID>
        {

            public bool Equals(DirectionalID x, DirectionalID y)
            {
                return x.ID == y.ID && x.Dir == y.Dir;
            }

            public int GetHashCode(DirectionalID x)
            {
                return (int)(x.ID + ((x.Dir) ? 1 : 0));
            }

        }

        public void LoadNetwork_NEXTA_CSV(string filepath, string filename)
        {
            m_NodeSize = 0; m_LinkSize = 0; m_SensorSize = 0;           
            string szSrcLine, subStr;
            int index, subLength;
            int line = 0;

            string path = filepath;
            FileStream nwfsInput;
            StreamReader nwsrInput;

            // read link and node size
            path = filepath + "input_node.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            szSrcLine = nwsrInput.ReadLine(); // read label line
            while ((szSrcLine = nwsrInput.ReadLine()) != null && szSrcLine.Trim() != null)
            {
                m_NodeSize++;
            }
            nwsrInput.Close();
            nwfsInput.Close();

            path = filepath + "input_link.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            szSrcLine = nwsrInput.ReadLine(); // read label line
            while ((szSrcLine = nwsrInput.ReadLine()) != null && szSrcLine.Trim() != null)
            {
                m_LinkSize++;
            }
            nwsrInput.Close();
            nwfsInput.Close();

            //int sensor_size = 0;
            //path = filepath + "input_sensor_location.csv";
            //nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //nwsrInput = new StreamReader(nwfsInput);
            //szSrcLine = nwsrInput.ReadLine(); // read label line
            //while ((szSrcLine = nwsrInput.ReadLine()) != null && szSrcLine.Trim() != null)
            //{
            //    sensor_size++;
            //}
            //nwsrInput.Close();
            //nwfsInput.Close();

            ////////////////////////////////////////////////////////////////////////
            m_NodeIndextoID = new int[m_NodeSize];
            m_NodeIDtoIndex = new Dictionary<int, int>();
            m_LinkIDtoIndex = new Dictionary<DirectionalID, int>();
            //Dictionary<int, int> NodeIDtoIndex_Raw = new Dictionary<int, int>();
            aryCNode = new CNode[m_NodeSize];
            aryCLink = new CLink[m_LinkSize];
            m_SensorIDtoIndex = new Dictionary<int, int>();
            ////////////////////////////////////////////////////////////////////////


            // read in node file
            int node_id = 0, node_areaID = 0, node_maplevel = 0, node_controltype = 0, UTM_zone = 0, node_type = 0;
            double node_long = 0, node_lat = 0, node_UTM_easting = 0, node_UTM_northing = 0;
            string node_name = null;
            CNode node;
            int node_count = 0;

            path = filepath + "input_node.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);

            szSrcLine = nwsrInput.ReadLine(); // read label line
            while ((szSrcLine = nwsrInput.ReadLine()) != null && szSrcLine.Trim() != null)
            {
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(",");
                if (index != -1)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(",");
                        if (index == -1)
                        {
                            subStr = null;
                        }
                        else
                        {
                            subStr = szSrcLine.Substring(0, index);
                        }
                        switch (i)
                        {
                            case 1:
                                node_id = int.Parse(subStr);
                                break;
                            case 2:
                                node_controltype = int.Parse(subStr);
                                break;
                            case 3:
                                node_lat = double.Parse(subStr);
                                break;
                            case 4:
                                node_long = double.Parse(subStr);
                                break;
                        }
                        subLength = szSrcLine.Length;
                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                    }                    
                    // add node
                    node = new CNode(node_id, node_areaID, node_long, node_lat, node_UTM_easting, node_UTM_northing, UTM_zone,
                                node_maplevel, node_controltype, node_type, node_name);
                    aryCNode[node_count] = node;
                    m_NodeIDtoIndex.Add(node_id, node_count);
                    m_NodeIndextoID[node_count] = node_id;
                    node_count++;
                    node_id = 0; node_areaID = 0; node_maplevel = 0; node_controltype = 0; UTM_zone = 0;
                    node_long = 0; node_lat = 0; node_UTM_easting = 0; node_UTM_northing = 0;
                    node_name = null;
                }
            }
            nwsrInput.Close();
            nwfsInput.Close();
            ////////////////////////////////////////////////////////////////////////

            // read in link file
            long link_id = -1;
            bool link_Dir = true;
            int link_areaID = 0, link_fromID = -1, link_toID = -1, link_maplevel = 0, link_modeflag = 0, link_capacity = 0;
            int link_lanesize = 0, link_type = 1, link_isshape = 0, link_shapeID = -1;
            double link_length = 0, link_fftt = 0, link_speedlimit = 0;
            string link_name = null, link_tmc = null;
            CLink link;
            int link_count = 0;
            DirectionalID DirLinkID = new DirectionalID();

            path = filepath + "input_link.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            szSrcLine = nwsrInput.ReadLine(); // read label line
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(",");
                if (index != -1)
                {
                    for (int i = 0; i < 21; i++)
                    {
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(",");
                        if (index == -1)
                        {
                            subStr = null;
                        }
                        else
                        {
                            subStr = szSrcLine.Substring(0, index);
                        }
                        switch (i)
                        {
                            case 1:
                                link_id = int.Parse(subStr);
                                break;
                            case 2:
                                link_fromID = int.Parse(subStr);
                                break;
                            case 3:
                                link_toID = int.Parse(subStr);
                                break;
                            case 4:
                                if (subStr == "1")
                                    link_Dir = true;
                                else if (subStr == "0")
                                    link_Dir = false;
                                break;
                            case 5:
                                link_length = double.Parse(subStr);
                                break;
                            case 6:
                                link_lanesize = int.Parse(subStr);
                                break;
                            case 7:
                                link_speedlimit = double.Parse(subStr);
                                break;
                            case 9:
                                link_capacity = (int)(double.Parse(subStr));
                                break;
                            case 10:
                                link_type = int.Parse(subStr);
                                break;
                        }
                        subLength = szSrcLine.Length;
                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                    }
                    // add link
                    //link_id = link_count + 1;
                    DirLinkID = new DirectionalID(link_id, true);
                    link = new CLink(DirLinkID, link_areaID, link_name, link_fromID, link_toID, link_maplevel, link_modeflag,
                        "mile", link_capacity, link_length, link_lanesize, link_speedlimit, link_type, false, link_shapeID, true, 0, false, 0);
                    aryCLink[link_count] = link;
                    m_LinkIDtoIndex.Add(DirLinkID, link_count);
                    link_count++;
                    link_id = -1; link_areaID = 0; link_fromID = -1; link_toID = -1; link_maplevel = 0; link_modeflag = 0;
                    link_lanesize = 0; link_speedlimit = 0; link_type = 1; link_isshape = 0; link_shapeID = -1; link_capacity = 0;
                    link_length = 0; link_fftt = 0;
                    link_name = null; link_tmc = null;
                }
            }
            nwsrInput.Close();
            nwfsInput.Close();
            ////////////////////////////////////////////////////////////////////////

            // analysis network
            Analysis_Network(filename);
            ////////////////////////////////////////////////////////////////////////

            // read in sensor file (if available)
            int sensor_fromID = 0, sensor_toID = 0, sensor_type = 0, sensor_ID = 0;
            int sensor_from_index = 0;
            path = filepath + "input_sensor_location.csv";
            try
            {
                nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
                nwsrInput = new StreamReader(nwfsInput);
                szSrcLine = nwsrInput.ReadLine(); // read label line
                while ((szSrcLine = nwsrInput.ReadLine()) != null)
                {
                    szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf(",");
                    if (index != -1)
                    {
                        for (int i = 1; i < 4; i++)
                        {
                            szSrcLine = szSrcLine.Trim();
                            index = szSrcLine.IndexOf(",");
                            if (index == -1)
                            {
                                subStr = null;
                            }
                            else
                            {
                                subStr = szSrcLine.Substring(0, index);
                            }
                            switch (i)
                            {
                                case 1:
                                    sensor_fromID = int.Parse(subStr);
                                    break;
                                case 2:
                                    sensor_toID = int.Parse(subStr);
                                    break;
                                case 3:
                                    sensor_type = int.Parse(subStr);
                                    break;
                            }
                            subLength = szSrcLine.Length;
                            szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                        }
                        sensor_ID = int.Parse(szSrcLine);
                        if (!m_SensorIDtoIndex.ContainsKey(sensor_ID))
                        {
                            m_SensorIDtoIndex.Add(sensor_ID, m_SensorSize);
                        }
                        m_SensorSize++;
                        // add sensor
                        sensor_from_index = m_NodeIDtoIndex[sensor_fromID];
                        for (int n = 0; n < OutgoingLinkSize[sensor_from_index]; n++)
                        {
                            if (sensor_toID == aryCLink[OutgoingLinkAry[sensor_from_index, n]].ToID)
                            {
                                aryCLink[OutgoingLinkAry[sensor_from_index, n]].SensorID = sensor_ID;
                            }
                        }
                    }
                }

                nwsrInput.Close();
                nwfsInput.Close();
            }
            catch (Exception e)
            { }
            ////////////////////////////////////////////////////////////////////////

            // read in zone file
        }

        public void LoadNetwork_CSV(string filepath, string filename)
        {

            m_NodeSize = 53124; m_LinkSize = 93900; //Func Class = 2,3,4

            m_NodeIndextoID = new int[m_NodeSize];
            m_NodeIDtoIndex = new Dictionary<int, int>();
            m_LinkIDtoIndex = new Dictionary<DirectionalID, int>();
            Dictionary<int, int> NodeIDtoIndex_Raw = new Dictionary<int, int>();
            aryCNode = new CNode[m_NodeSize];
            aryCLink = new CLink[m_LinkSize];
            string szSrcLine, subStr;
            int index, subLength;
            int line = 0;

            string path;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            //////////////////////////////////////////////////////////////////////////////////////////

            //read Links & Nodes
            int node_UTM_zone = 0;
            double node_easting = 0, node_northing = 0;
            CNode node;
            int node_count = 0;
            LatLongValue nval;

            //int count_node = 0;
            int link_speedcat = 0, link_func_class = 0;
            long linkID = -1;
            DirectionalID DirLinkID = new DirectionalID(), DirLinkPlus = new DirectionalID(), DirLinkMinus = new DirectionalID();
            double from_lat = 0, from_long = 0, to_lat = 0, to_long = 0;
            int fromID = -1, toID = -1, link_lanesize = 0, link_shapeID = 0;//, link_type = 0
            double link_length = 0, link_speedlimit = 30;
            string link_name = null, link_dir = null;
            CLink link;

            path = filepath + filename + ".csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);

            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(",");
                if (index != -1)
                {
                    for (int i = 1; i < 43; i++)
                    {
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(",");
                        if (index == -1)
                        {
                            subStr = null;
                        }
                        else
                        {
                            subStr = szSrcLine.Substring(0, index);
                        }
                        switch (i)
                        {
                            case 1:
                                from_lat = double.Parse(subStr) / 1000000;
                                while (from_lat > 90)
                                    from_lat = from_lat / 10;
                                while (from_lat < 10)
                                    from_lat = from_lat * 10;
                                break;
                            case 2:
                                to_lat = double.Parse(subStr) / 1000000;
                                while (to_lat > 90)
                                    to_lat = to_lat / 10;
                                while (to_lat < 10)
                                    to_lat = to_lat * 10;
                                break;
                            case 3:
                                from_long = double.Parse(subStr) / 1000000;
                                while (from_long < -180)
                                    from_long = from_long / 10;
                                while (from_long > -40)
                                    from_long = from_long * 10;
                                break;
                            case 4:
                                to_long = double.Parse(subStr) / 1000000;
                                while (to_long < -180)
                                    to_long = to_long / 10;
                                while (to_long > -40)
                                    to_long = to_long * 10;
                                break;
                            case 5:
                                fromID = int.Parse(subStr);
                                break;
                            case 6:
                                toID = int.Parse(subStr);
                                break;

                            //TODO: add shape ID

                            case 8:
                                link_length = double.Parse(subStr) / 1000000;
                                break;
                            case 10:
                                linkID = long.Parse(subStr);
                                break;
                            case 11:
                                if (subStr == "")
                                    link_name = "";
                                else
                                    link_name = subStr.Substring(1, subStr.Length - 2);
                                break;
                            case 33:
                                link_func_class = int.Parse(subStr.Substring(1, subStr.Length - 2));
                                break;
                            case 34:
                                link_speedcat = int.Parse(subStr.Substring(1, subStr.Length - 2));
                                break;
                            case 42:
                                link_dir = subStr.Substring(1, subStr.Length - 2);
                                break;
                        }
                        subLength = szSrcLine.Length;
                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                    }


                    switch (link_speedcat)
                    {
                        case 1:
                            link_speedlimit = 80;
                            break;
                        case 2:
                            link_speedlimit = 65;
                            break;
                        case 3:
                            link_speedlimit = 55;
                            break;
                        case 4:
                            link_speedlimit = 40;
                            break;
                        case 5:
                            link_speedlimit = 30;
                            break;
                        case 6:
                            link_speedlimit = 20;
                            break;
                        case 7:
                            link_speedlimit = 10;
                            break;
                        case 8:
                            link_speedlimit = 5;
                            break;
                    }
                    DirLinkPlus = new DirectionalID(linkID, true);
                    DirLinkMinus = new DirectionalID(linkID, false);
                    if (!m_LinkIDtoIndex.ContainsKey(DirLinkPlus) && !m_LinkIDtoIndex.ContainsKey(DirLinkMinus) && link_func_class < 5)
                    {
                        if (link_dir == "B")
                        {
                            if (from_lat == to_lat && from_long == to_long)
                            {

                            }
                            else if ((from_lat < to_lat) || (from_lat == to_lat && from_long < to_long))
                            {
                                DirLinkID = DirLinkPlus;
                                link = new CLink(DirLinkID, 0, link_name, fromID, toID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;

                                DirLinkID = DirLinkMinus;
                                link = new CLink(DirLinkID, 0, link_name, toID, fromID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;
                            }
                            else
                            {
                                DirLinkID = DirLinkPlus;
                                link = new CLink(DirLinkID, 0, link_name, fromID, toID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;

                                DirLinkID = DirLinkMinus;
                                link = new CLink(DirLinkID, 0, link_name, toID, fromID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;
                            }

                        }
                        else if (link_dir == "F")
                        {
                            if (from_lat == to_lat && from_long == to_long)
                            {

                            }
                            else if ((from_lat < to_lat) ||
                                (from_lat == to_lat && from_long < to_long))
                            {
                                DirLinkID = DirLinkPlus;
                                link = new CLink(DirLinkID, 0, link_name, fromID, toID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;
                            }
                            else
                            {
                                DirLinkID = DirLinkPlus;
                                link = new CLink(DirLinkID, 0, link_name, toID, fromID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;
                            }
                        }
                        else if (link_dir == "T")
                        {
                            if (from_lat == to_lat && from_long == to_long)
                            {

                            }
                            else if ((from_lat < to_lat) ||
                                (from_lat == to_lat && from_long < to_long))
                            {
                                DirLinkID = DirLinkMinus;
                                link = new CLink(DirLinkID, 0, link_name, toID, fromID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;
                            }
                            else
                            {
                                DirLinkID = DirLinkMinus;
                                link = new CLink(DirLinkID, 0, link_name, fromID, toID, 0, 0, "mile", 0, link_length, link_lanesize, link_speedlimit, link_func_class, false, link_shapeID, true, 0, false, 0);
                                aryCLink[line] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, line);
                                line++;
                            }
                        }

                        if (!m_NodeIDtoIndex.ContainsKey(fromID))
                        {
                            //LatLong2UTM
                            nval = new LatLongValue();
                            nval = LatLongValue.LatLongToUTM(from_lat, from_long);
                            node_easting = nval.utmEx;
                            node_northing = nval.utmNy;
                            node_UTM_zone = nval.zone;
                            node = new CNode(fromID, 0, from_long, from_lat, node_easting, node_northing, node_UTM_zone, 0, 0, 0, null);
                            m_NodeIDtoIndex.Add(fromID, node_count);
                            m_NodeIndextoID[node_count] = fromID;
                            aryCNode[node_count] = node;
                            node_count++;
                            node_UTM_zone = 0;
                            from_long = 0; from_lat = 0; node_easting = 0; node_northing = 0;
                        }
                        if (!m_NodeIDtoIndex.ContainsKey(toID))
                        {
                            //LatLong2UTM
                            nval = new LatLongValue();
                            nval = LatLongValue.LatLongToUTM(to_lat, to_long);
                            node_easting = nval.utmEx;
                            node_northing = nval.utmNy;
                            node_UTM_zone = nval.zone;
                            node = new CNode(toID, 0, to_long, to_lat, node_easting, node_northing, node_UTM_zone, 0, 0, 0, null);
                            m_NodeIDtoIndex.Add(toID, node_count);
                            m_NodeIndextoID[node_count] = toID;
                            aryCNode[node_count] = node;
                            node_count++;
                            node_UTM_zone = 0;
                            to_long = 0; to_lat = 0; node_easting = 0; node_northing = 0;
                        }

                    }
                    linkID = -1;
                    link_speedlimit = 30; link_length = 0; link_shapeID = 0;
                    link_name = null;

                }

            }
            nwsrInput.Close();
            nwfsInput.Close();

            path = filepath + "Traffic_" + filename + ".csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            int count = 0;
            string TMCDir = "";
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(",");
                if (index != -1)
                {
                    subStr = szSrcLine.Substring(0, index);
                    linkID = long.Parse(subStr);
                    DirLinkID = new DirectionalID(linkID, true);
                    if (m_LinkIDtoIndex.ContainsKey(DirLinkID))
                    {
                        TMCDir = szSrcLine.Substring(index + 2, 1);
                        if (TMCDir == "+")
                        {
                            aryCLink[m_LinkIDtoIndex[DirLinkID]].TMC = szSrcLine.Substring(index + 2, 10);
                            count++;
                        }
                    }
                    DirLinkID = new DirectionalID(linkID, false);
                    if (m_LinkIDtoIndex.ContainsKey(DirLinkID))
                    {
                        TMCDir = szSrcLine.Substring(index + 2, 1);
                        if (TMCDir == "-")
                        {
                            aryCLink[m_LinkIDtoIndex[DirLinkID]].TMC = szSrcLine.Substring(index + 2, 10);
                            count++;
                        }
                    }
                }

            }
            nwsrInput.Close();
            nwfsInput.Close();

            Analysis_Network(filename);
        }

        /*public void LoadNetwork_TXT(string filepath)
        {
            m_NodeSize = 2135; m_LinkSize = 6746;
            m_NodeIDtoIndex = new Dictionary<int, int>();
            m_NodeIndextoID = new int[m_NodeSize];
            string szSrcLine, subStr;
            int index, subLength;
            int nodeID = -1, node_UTM_zone = 0;
            double node_long = 0, node_lat = 0, node_easting = 0, node_northing = 0;
            string node_name = null;
            CNode node;


            aryCNode = new CNode[m_NodeSize];
            aryCLink = new CLink[m_LinkSize];

            //read Nodes.txt
            int line = 0;
            //string filepath = @"E:\DATA\CA\";
            string path = filepath + "Nodes_CA.txt";
            FileStream nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {

                for (int i = 0; i < 6; i++)
                {
                    //szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf("\t");
                    if (index == 0)
                    {
                        subStr = null;
                    }
                    else
                    {
                        subStr = szSrcLine.Substring(0, index);
                    }
                    switch (i)
                    {
                        case 0:
                            nodeID = int.Parse(subStr);
                            break;
                        case 1:
                            node_long = double.Parse(subStr);
                            break;
                        case 2:
                            node_lat = double.Parse(subStr);
                            break;
                        case 3:
                            node_name = subStr;
                            break;
                        case 4:
                            node_northing = double.Parse(subStr);
                            break;
                        case 5:
                            node_easting = double.Parse(subStr);
                            break;

                    }
                    subLength = szSrcLine.Length;
                    szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                }
                szSrcLine = szSrcLine.Trim();//last element
                node_UTM_zone = int.Parse(szSrcLine);
                node = new CNode(nodeID, 0, node_long, node_lat, node_easting, node_northing, node_UTM_zone, 0, 0, 0, node_name);
                aryCNode[line] = node;
                m_NodeIDtoIndex.Add(nodeID, line);
                m_NodeIndextoID[line] = nodeID;
                line++;
                nodeID = -1; node_UTM_zone = 10;
                node_long = 0; node_lat = 0; node_easting = 0; node_northing = 0;
                node_name = null;

            }

            nwsrInput.Close();
            nwfsInput.Close();


            //read Links.txt
            line = 0;
            int linkID = -1, fromID = -1, toID = -1, link_type = 0, link_lanesize = 0;
            double link_length = 0, link_speedlimit = 0, link_fftt = 0;
            string link_name = null;
            CLink link;

            path = filepath + "Links_CA.txt";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {

                for (int i = 0; i < 8; i++)
                {
                    //szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf("\t");
                    if (index == 0)
                    {
                        subStr = null;
                    }
                    else
                    {
                        subStr = szSrcLine.Substring(0, index);
                    }
                    switch (i)
                    {
                        case 0:
                            linkID = int.Parse(subStr);
                            break;
                        case 1:
                            link_name = subStr;
                            break;
                        case 2:
                            fromID = int.Parse(subStr);
                            break;
                        case 3:
                            toID = int.Parse(subStr);
                            break;
                        case 4:
                            link_length = double.Parse(subStr);
                            break;
                        case 5:
                            link_lanesize = int.Parse(subStr);
                            break;
                        case 6:
                            link_speedlimit = double.Parse(subStr);
                            break;
                        case 7:
                            link_type = int.Parse(subStr);
                            break;

                    }
                    subLength = szSrcLine.Length;
                    szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                }
                szSrcLine = szSrcLine.Trim();//last element
                link_fftt = double.Parse(szSrcLine);
                link = new CLink(linkID, 0, link_name, fromID, toID, 0, 0, "mile", link_length, link_lanesize, link_speedlimit, link_type, 0, 0, true, 0);
                aryCLink[line] = link;
                line++;
                linkID = -1; fromID = -1; toID = -1; link_type = 0; link_lanesize = 0;
                link_length = 0; link_speedlimit = 0; link_fftt = 0;
                link_name = null;

            }

            nwsrInput.Close();
            nwfsInput.Close();

            Analysis_Network("CA");
        }*/

        /// <summary>
        /// Load network from network.dat file for sensor location on Irvin network
        /// </summary>
        /// <param name="filepath">file path, default ""</param>
        /// <param name="additionLinkSize">Recusively load network, for computational test ONLY</param>
        public void LoadNetwork_DAT(string filepath, int additionLinkSize)
        {
            bool SingleDirNetwork = false;  // single direction network
            string szSrcLine, subStr;
            int index, subLength;
            int id, zone;
            double x, y;
            CNode node;
            int fromID = -1, toID = -1, link_type = 0, link_lanesize = 0;
            double length = 0, link_speedlimit = 0;
            CLink link;
            m_NodeIDtoIndex = new Dictionary<int, int>();
            int initialLinkSize = 0;

            //read network.dat
            int line = 0;
            long L = 0;
            DirectionalID DirLinkID = new DirectionalID();
            filepath = @"C:\DATA\Irvine_gis\";
            string path = filepath + "network.dat";
            FileStream nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                if (line == 0)//first line
                {
                    for (int i = 0; i < 4; i++)
                    {
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(@" ");
                        subStr = szSrcLine.Substring(0, index);
                        switch (i)
                        {
                            case 1:
                                m_NodeSize = int.Parse(subStr);
                                aryCNode = new CNode[m_NodeSize];
                                m_NodeIndextoID = new int[m_NodeSize];
                                break;
                            case 2:
                                m_LinkSize = int.Parse(subStr);
                                initialLinkSize = m_LinkSize;
                                if (SingleDirNetwork)
                                    m_LinkSize = m_LinkSize * 2;
                                if (additionLinkSize > 0)
                                    m_LinkSize += additionLinkSize;
                                aryCLink = new CLink[m_LinkSize];
                                break;
                        }
                        subLength = szSrcLine.Length;
                        szSrcLine = szSrcLine.Substring(index, subLength - index);
                    }
                    szSrcLine = szSrcLine.Trim();//last element
                    line++;
                }

                else if (line > 0 && line < m_NodeSize + 1)//read nodes
                {
                    id = 0;
                    szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf(@" ");
                    subStr = szSrcLine.Substring(0, index);
                    subLength = szSrcLine.Length;
                    id = int.Parse(subStr);
                    szSrcLine = szSrcLine.Substring(index, subLength - index);
                    szSrcLine = szSrcLine.Trim();
                    zone = int.Parse(szSrcLine);
                    //insert node
                    node = new CNode(id, zone, 0, 0, 0, 0, 0, 0, 0, 0, null);
                    aryCNode[line - 1] = node;
                    m_NodeIDtoIndex.Add(id, line - 1);
                    m_NodeIndextoID[line - 1] = id;

                    line++;
                }
                else // read links
                {
                    for (int i = 0; i < 12; i++)
                    {
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(@" ");
                        subStr = szSrcLine.Substring(0, index);
                        switch (i)
                        {
                            case 0:
                                fromID = int.Parse(subStr);
                                break;
                            case 1:
                                toID = int.Parse(subStr);
                                break;
                            case 4:
                                length = double.Parse(subStr);
                                break;
                            case 5:
                                link_lanesize = int.Parse(subStr);
                                break;
                            case 8:
                                link_speedlimit = int.Parse(subStr);
                                break;
                            case 11:
                                link_type = int.Parse(subStr);
                                break;
                        }
                        subLength = szSrcLine.Length;
                        szSrcLine = szSrcLine.Substring(index, subLength - index);
                    }
                    szSrcLine = szSrcLine.Trim();//last element
                    DirLinkID = new DirectionalID(L, true);
                    link = new CLink(DirLinkID, 1, null, fromID, toID, 0, 0, "feet", 0, length, link_lanesize, link_speedlimit, link_type, false, 0, true, 0, false, 0);
                    aryCLink[L] = link;
                    L++;
                    // for single dir network
                    if (SingleDirNetwork)
                    {
                        DirLinkID = new DirectionalID(L, false);
                        link = new CLink(DirLinkID, 1, null, toID, fromID, 0, 0, "feet", 0, length, link_lanesize, link_speedlimit, link_type, false, 0, true, 0, false, 0);
                        aryCLink[L] = link;
                        L++;
                    }
                    // for computational time evaluation ONLY
                    int iterativeL = 1;
                    while (m_LinkSize - iterativeL * initialLinkSize > L - 1)
                    {
                        DirLinkID = new DirectionalID(L - 1 + iterativeL * initialLinkSize, true);
                        link = new CLink(DirLinkID, 1, null, fromID, toID, 0, 0, "feet", 0, length, link_lanesize, link_speedlimit, link_type, false, 0, true, 0, false, 0);
                        aryCLink[L - 1 + iterativeL * initialLinkSize] = link;
                        iterativeL++;
                    }
                    fromID = -1; toID = -1; link_type = 0; link_lanesize = 0;
                    length = 0; link_speedlimit = 0;
                }
            }
            nwsrInput.Close();
            nwfsInput.Close();

            //read xy.dat
            path = filepath + "xy.dat";
            FileStream xyfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader xysrInput = new StreamReader(xyfsInput);
            line = 0;
            while ((szSrcLine = xysrInput.ReadLine()) != null)
            {
                //find node ID
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(@" ");
                subStr = szSrcLine.Substring(0, index);
                id = int.Parse(subStr);
                subLength = szSrcLine.Length;
                szSrcLine = szSrcLine.Substring(index, subLength - index);
                //find node X
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(@" ");
                subStr = szSrcLine.Substring(0, index);
                x = double.Parse(subStr);
                subLength = szSrcLine.Length;
                szSrcLine = szSrcLine.Substring(index, subLength - index);
                //find node Y
                subStr = szSrcLine.Trim();
                y = double.Parse(subStr);
                //insert X,Y values
                if (aryCNode[line].Node_ID == id)
                {
                    aryCNode[line].Node_Long = x;
                    aryCNode[line].Node_Lat = y;
                    x = 0; y = 0;
                }
                line++;
            }
            xysrInput.Close();
            xyfsInput.Close();

            Analysis_Network("");

        }

        public bool LoadNetwork_XML(string filepath, string filename, params object[] BusLayer)
        {
            city = filename;
            // process bus layer 1.number
            bool bus_flag = false;
            if (BusLayer.Length > 0) // load bus layer
            {
                string transit_path = filepath + "Transit_" + filename + ".csv";
                FileStream nwfsInput = new FileStream(transit_path, FileMode.Open, FileAccess.Read);
                StreamReader nwsrInput = new StreamReader(nwfsInput);
                int bus_stop_size = 0;
                string szSrcLine, subStr;
                int index, subLength;
                // Open file, read the number of bus stop(bus_stop_size) and number of link with stop (bus_link_size)
                while ((szSrcLine = nwsrInput.ReadLine()) != null)
                {
                    szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf(",");
                    if (index == -1)
                    {
                        subStr = null;
                    }
                    else
                    {
                        subStr = szSrcLine.Substring(0, index);
                    }

                    if (subStr == "Route")
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            szSrcLine = szSrcLine.Trim();
                            index = szSrcLine.IndexOf(",");
                            subLength = szSrcLine.Length;
                            szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                        }
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(",");
                        subStr = szSrcLine.Substring(0, index); // get bus_stop_size
                        bus_stop_size = int.Parse(subStr);
                        m_NodeSize += bus_stop_size; // number of bus layer node = bus_stop_size
                        m_LinkSize += (bus_stop_size - 1); // number of bus layer link = bus_stop_size - 1
                        m_LinkSize += (bus_stop_size * 4); // number of bus layer connector = bus_stop_size * 4
                        // consider transfer: links between stations (under developping)
                    }
                }
                m_TransitSize = m_NodeSize;
                bus_flag = true;
                nwsrInput.Close();
                nwfsInput.Close();
            }

            string Element_Name = null;
            //string filepath = @"C:\works\VII\Test\2008.04.28.Chris.XMLMAker_JavaDB\";
            m_NodeIDtoIndex = new Dictionary<int, int>();
            //read NetworkSize file
            string path = filepath + "NetworkSize_" + filename + ".xml";
            XmlTextReader reader = new XmlTextReader(path);
            if (!reader.Read())
                return false;
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // element.
                        Element_Name = reader.Name;
                        break;
                    case XmlNodeType.Text:
                        switch (Element_Name)
                        {
                            case "NumOfRecords_Nodes":
                                m_NodeSize += int.Parse(reader.Value);
                                aryCNode = new CNode[m_NodeSize];
                                m_NodeIndextoID = new int[m_NodeSize];
                                break;
                            case "NumOfRecords_Links":
                                m_LinkSize += int.Parse(reader.Value);
                                aryCLink = new CLink[m_LinkSize];
                                break;
                            case "LEFT":
                                left = double.Parse(reader.Value);
                                break;
                            case "RIGHT":
                                right = double.Parse(reader.Value);
                                break;
                            case "UP":
                                up = double.Parse(reader.Value);
                                break;
                            case "LOW":
                                low = double.Parse(reader.Value);
                                break;
                        }
                        break;
                }

            }
            reader.Close();


            //read node file
            int node_id = 0, node_areaID = 0, node_maplevel = 0, node_controltype = 0, UTM_zone = 0, node_type = 0;
            double node_long = 0, node_lat = 0, node_UTM_easting = 0, node_UTM_northing = 0;
            string node_name = null;
            CNode node;
            int node_count = 0;

            path = filepath + "Nodes_" + filename + ".xml"; ;
            reader = new XmlTextReader(path);
            if (!reader.Read())
                return false;
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // element.
                        Element_Name = reader.Name;
                        break;
                    case XmlNodeType.Text:
                        switch (Element_Name)
                        {
                            case "NodeID":
                                node_id = int.Parse(reader.Value);
                                break;
                            case "AreaID":
                                node_areaID = int.Parse(reader.Value);
                                break;
                            case "NodeName":
                                node_name = reader.Value;
                                break;
                            case "LNG":
                                node_long = double.Parse(reader.Value);
                                break;
                            case "LAT":
                                node_lat = double.Parse(reader.Value);
                                break;
                            case "UTMEasting":
                                node_UTM_easting = double.Parse(reader.Value);
                                break;
                            case "UTMNorthing":
                                node_UTM_northing = double.Parse(reader.Value);
                                break;
                            case "UTMZone":
                                UTM_zone = int.Parse(reader.Value);
                                break;
                            case "MapLevel":
                                node_maplevel = int.Parse(reader.Value);
                                break;
                            case "NodeControlType":
                                node_controltype = int.Parse(reader.Value);
                                break;
                            case "NodeType":
                                node_type = int.Parse(reader.Value);
                                break;


                        }
                        break;
                    case XmlNodeType.EndElement:
                        if (reader.Name == "Node")
                        {
                            node = new CNode(node_id, node_areaID, node_long, node_lat, node_UTM_easting, node_UTM_northing, UTM_zone,
                                node_maplevel, node_controltype, node_type, node_name);
                            aryCNode[node_count] = node;
                            m_NodeIDtoIndex.Add(node_id, node_count);
                            m_NodeIndextoID[node_count] = node_id;
                            node_count++;
                            node_id = 0; node_areaID = 0; node_maplevel = 0; node_controltype = 0; UTM_zone = 0;
                            node_long = 0; node_lat = 0; node_UTM_easting = 0; node_UTM_northing = 0;
                            node_name = null;
                        }
                        break;
                }
            }
            reader.Close();

            //read link file
            long link_id = -1;
            bool link_Dir = true;
            int link_areaID = 0, link_fromID = -1, link_toID = -1, link_maplevel = 0, link_modeflag = 0;
            int link_lanesize = 0, link_type = 1, link_isshape = 0, link_shapeID = -1;
            double link_length = 0, link_fftt = 0, link_speedlimit = 0;
            string link_name = null, link_tmc = null;
            CLink link;
            int link_count = 0;
            DirectionalID DirLinkID = new DirectionalID();
            m_LinkIDtoIndex = new Dictionary<DirectionalID, int>(new DirectionalIDEqualityComparer());

            path = filepath + "Links_" + filename + ".xml"; ;
            reader = new XmlTextReader(path);
            if (!reader.Read())
                return false;
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // element.
                        Element_Name = reader.Name;
                        break;
                    case XmlNodeType.Text:
                        switch (Element_Name)
                        {
                            case "LinkID":
                                link_id = long.Parse(reader.Value);
                                break;
                            case "LinkDir":
                                link_Dir = bool.Parse(reader.Value);
                                break;
                            case "AreaID":
                                link_areaID = int.Parse(reader.Value);
                                break;
                            case "LinkName":
                                link_name = reader.Value;
                                break;
                            case "FromNodeID":
                                link_fromID = int.Parse(reader.Value);
                                break;
                            case "ToNodeID":
                                link_toID = int.Parse(reader.Value);
                                break;
                            case "MapLevel":
                                link_maplevel = int.Parse(reader.Value);
                                break;
                            case "ModeFlag":
                                link_modeflag = int.Parse(reader.Value);
                                break;
                            case "LinkLength":
                                link_length = double.Parse(reader.Value);
                                break;
                            case "NumberOfLanes":
                                link_lanesize = int.Parse(reader.Value);
                                break;
                            case "SpeedLimit":
                                link_speedlimit = double.Parse(reader.Value);
                                break;
                            case "FFTT":
                                link_fftt = double.Parse(reader.Value);
                                break;
                            case "LinkType":
                                link_type = int.Parse(reader.Value);
                                break;
                            case "IsShape":
                                link_isshape = int.Parse(reader.Value);
                                break;
                            case "ShapeID":
                                link_shapeID = int.Parse(reader.Value);
                                break;
                            case "TMC":
                                link_tmc = reader.Value;
                                break;
                        }
                        break;
                    case XmlNodeType.EndElement:
                        if (reader.Name == "Link" && link_fromID != link_toID)
                        {
                            DirLinkID = new DirectionalID(link_id, link_Dir);
                            link = new CLink(DirLinkID, link_areaID, link_name, link_fromID, link_toID, link_maplevel, link_modeflag,
                                "mile", 0, link_length, link_lanesize, link_speedlimit, link_type, false, link_shapeID, true, 0, false, 0);
                            link.TMC = link_tmc;
                            aryCLink[link_count] = link;
                            m_LinkIDtoIndex.Add(DirLinkID, link_count);
                            link_count++;
                            link_id = -1; link_areaID = 0; link_fromID = -1; link_toID = -1; link_maplevel = 0; link_modeflag = 0;
                            link_lanesize = 0; link_speedlimit = 0; link_type = 1; link_isshape = 0; link_shapeID = -1;
                            link_length = 0; link_fftt = 0;
                            link_name = null; link_tmc = null;
                        }
                        break;
                }
            }
            reader.Close();

            // process bus layer 2.read data
            if (bus_flag == true)
            {
                //// for demo only ////////////////////////////// 
                // long[] BusStopLinkSeq_1 = { 21627609, 21614960, 711640727, 119967755, 726122268 };
                // AddTransitLayer_Demo(BusStopLinkSeq_1, node_count, link_count, out node_count, out link_count);
                ///////////////////////////////////////////////
                LoadTransitLayer(filepath, filename, node_count, link_count);
                Analysis_Network_withTransit(filepath, filename);
                return true;

            }

            Analysis_Network(filename);
            return true;
        }

        public bool LoadTransitLayer(string filepath, string filename, int node_count, int link_count)
        {
            CNode node;
            CLink link = new CLink();
            int stop_link = 0;
            int node_id = 0, node_areaID = 0, node_maplevel = 0, node_controltype = 0, node_UTM_zone = 0, node_type = 1;
            double node_long = 0, node_lat = 0, node_UTM_easting = 0, node_UTM_northing = 0;
            string node_name = null;
            LatLongValue nval;
            int node_id_pre = 0;
            long link_id = 0;
            int link_areaID = 0, link_fromID = -1, link_toID = -1, link_maplevel = 0, link_modeflag = 0;
            int from_id = 0, to_id = 0;
            int link_lanesize = 0, link_type = 0, link_shapeID = -1;
            double link_length = 0, link_speedlimit = 0;
            string link_name = null;

            string route_name = null;
            string[] ary_stop_name = null;
            long[] ary_stop_linkID = null;
            int k = 0, RouteSize = 0;

            string transit_path = filepath + "Transit_" + filename + ".csv";
            FileStream nwfsInput = new FileStream(transit_path, FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            int bus_stop_size = 0;
            string szSrcLine, subStr;
            int index;
            DirectionalID DirLinkPlus = new DirectionalID(), DirLinkMinus = new DirectionalID(), DirLinkID = new DirectionalID();

            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(",");
                if (index != -1 && szSrcLine.Substring(0, index) == "Route")
                {
                    for (int i = 0; i < 3; i++)
                    {
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(",");
                        if (index == -1)
                        {
                            subStr = null;
                        }
                        else
                        {
                            subStr = szSrcLine.Substring(0, index);
                        }
                        switch (i)
                        {
                            case 1:
                                route_name = subStr;
                                break;
                            case 2:
                                bus_stop_size = int.Parse(subStr);
                                ary_stop_name = new string[bus_stop_size];
                                ary_stop_linkID = new long[bus_stop_size];
                                k = 0;
                                break;
                        }
                        szSrcLine = szSrcLine.Substring(index + 1);
                    }
                }
                else if (index != -1 && szSrcLine.Substring(0, index) == "RouteSize")
                {
                    RouteSize = int.Parse(szSrcLine.Substring(index + 1));
                }
                else
                {
                    if (index != -1 && bus_stop_size > 0)
                    {
                        subStr = szSrcLine.Substring(0, index);
                        ary_stop_linkID[k] = long.Parse(subStr);
                        ary_stop_name[k] = route_name + "," + szSrcLine.Substring(index + 1);
                        k++;
                        bus_stop_size--;
                    }
                    else if (index != -1 && bus_stop_size == 0)
                    {
                        // add node and link
                        for (int i = 0; i < ary_stop_linkID.Length; i++)
                        {
                            DirLinkPlus = new DirectionalID(ary_stop_linkID[i], true);
                            DirLinkMinus = new DirectionalID(ary_stop_linkID[i], false);
                            if (m_LinkIDtoIndex.ContainsKey(DirLinkPlus))
                            {
                                stop_link = m_LinkIDtoIndex[DirLinkPlus];
                            }
                            else if (m_LinkIDtoIndex.ContainsKey(DirLinkMinus))
                            {
                                stop_link = m_LinkIDtoIndex[DirLinkMinus];
                            }

                            // add bus node
                            //node id
                            while (m_NodeIDtoIndex.ContainsKey(node_id))
                            {
                                node_id++;
                            }
                            //node long/lat                
                            node_long = (aryCNode[m_NodeIDtoIndex[aryCLink[stop_link].FromID]].Node_Long + aryCNode[m_NodeIDtoIndex[aryCLink[stop_link].ToID]].Node_Long) / 2;
                            node_lat = (aryCNode[m_NodeIDtoIndex[aryCLink[stop_link].FromID]].Node_Lat + aryCNode[m_NodeIDtoIndex[aryCLink[stop_link].ToID]].Node_Lat) / 2;
                            //node UTM
                            nval = new LatLongValue();
                            nval = LatLongValue.LatLongToUTM(node_lat, node_long);
                            node_UTM_easting = nval.utmEx;
                            node_UTM_northing = nval.utmNy;
                            node_UTM_zone = nval.zone;
                            node_name = ary_stop_name[i];
                            // add node to aryCNode
                            node = new CNode(node_id, node_areaID, node_long, node_lat, node_UTM_easting, node_UTM_northing, node_UTM_zone,
                                            node_maplevel, node_controltype, node_type, node_name);
                            aryCNode[node_count] = node;
                            m_NodeIDtoIndex.Add(node_id, node_count);
                            m_NodeIndextoID[node_count] = node_id;
                            node_count++;
                            node_areaID = 0; node_maplevel = 0; node_controltype = 0; node_UTM_zone = 0;
                            node_long = 0; node_lat = 0; node_UTM_easting = 0; node_UTM_northing = 0;
                            node_name = null;

                            ///////////////////////////////////////////////////////////////////////////////////////////////////
                            // add connector link_type = 10
                            link_length = aryCLink[stop_link].Link_Length / 2;
                            link_speedlimit = m_WalkingSpeed;
                            link_type = 10;
                            for (int c = 0; c < 4; c++)
                            {
                                DirLinkPlus = new DirectionalID(link_id, true);
                                DirLinkMinus = new DirectionalID(link_id, false);
                                while (m_LinkIDtoIndex.ContainsKey(DirLinkPlus) || m_LinkIDtoIndex.ContainsKey(DirLinkMinus))
                                {
                                    link_id++;
                                    DirLinkPlus = new DirectionalID(link_id, true);
                                    DirLinkMinus = new DirectionalID(link_id, false);
                                }
                                if (aryCLink[stop_link].ID.Dir)
                                {
                                    switch (c) // add 4 connector for each bus stop
                                    {
                                        case 0:
                                            link_fromID = aryCLink[stop_link].FromID;
                                            link_toID = node_id;
                                            DirLinkID = DirLinkPlus;
                                            break;
                                        case 1:
                                            link_fromID = node_id;
                                            link_toID = aryCLink[stop_link].FromID;
                                            DirLinkID = DirLinkMinus;
                                            break;
                                        case 2:
                                            link_fromID = node_id;
                                            link_toID = aryCLink[stop_link].ToID;
                                            DirLinkID = DirLinkPlus;
                                            break;
                                        case 3:
                                            link_fromID = aryCLink[stop_link].ToID;
                                            link_toID = node_id;
                                            DirLinkID = DirLinkMinus;
                                            break;
                                    }
                                }
                                else
                                {
                                    switch (c) // add 4 connector for each bus stop
                                    {
                                        case 0:
                                            link_fromID = aryCLink[stop_link].ToID;
                                            link_toID = node_id;
                                            DirLinkID = DirLinkPlus;
                                            break;
                                        case 1:
                                            link_fromID = node_id;
                                            link_toID = aryCLink[stop_link].ToID;
                                            DirLinkID = DirLinkMinus;
                                            break;
                                        case 2:
                                            link_fromID = node_id;
                                            link_toID = aryCLink[stop_link].FromID;
                                            DirLinkID = DirLinkPlus;
                                            break;
                                        case 3:
                                            link_fromID = aryCLink[stop_link].FromID;
                                            link_toID = node_id;
                                            DirLinkID = DirLinkMinus;
                                            break;
                                    }
                                }
                                link = new CLink(DirLinkID, link_areaID, link_name, link_fromID, link_toID, link_maplevel, link_modeflag,
                                                "mile", 0, link_length, link_lanesize, link_speedlimit, link_type, false, link_shapeID, true, 0, false, 0);
                                //link.Link_TMC = link_tmc;
                                aryCLink[link_count] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, link_count);
                                link_count++;
                                link_id++;
                            }
                            link_areaID = 0; link_fromID = -1; link_toID = -1; link_maplevel = 0; link_modeflag = 0;
                            link_lanesize = 0; link_speedlimit = 0; link_type = 0; link_shapeID = -1;
                            link_length = 0;
                            link_name = null;
                            ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (i > 0)
                            {
                                // add bus link link_type = 9
                                DirLinkPlus = new DirectionalID(link_id, true);
                                DirLinkMinus = new DirectionalID(link_id, false);
                                while (m_LinkIDtoIndex.ContainsKey(DirLinkPlus) || m_LinkIDtoIndex.ContainsKey(DirLinkMinus))
                                {
                                    link_id++;
                                    DirLinkPlus = new DirectionalID(link_id, true);
                                    DirLinkMinus = new DirectionalID(link_id, false);
                                }
                                link_type = 9;
                                link_length = 100;
                                link_speedlimit = m_WalkingSpeed;
                                link_fromID = node_id_pre;
                                link_toID = node_id;
                                from_id = m_NodeIDtoIndex[link_fromID];
                                to_id = m_NodeIDtoIndex[link_toID];
                                if ((aryCNode[from_id].Node_Lat < aryCNode[to_id].Node_Lat)
                                    || (aryCNode[from_id].Node_Lat == aryCNode[to_id].Node_Lat && aryCNode[from_id].Node_Long < aryCNode[to_id].Node_Long))
                                {
                                    DirLinkID = DirLinkPlus;
                                }
                                else
                                {
                                    DirLinkID = DirLinkMinus;
                                }

                                link = new CLink(DirLinkID, link_areaID, link_name, link_fromID, link_toID, link_maplevel, link_modeflag,
                                                    "mile", 0, link_length, link_lanesize, link_speedlimit, link_type, false, link_shapeID, true, 0, false, 0);
                                aryCLink[link_count] = link;
                                m_LinkIDtoIndex.Add(DirLinkID, link_count);
                                link_count++;
                                link_id++;
                                link_areaID = 0; link_fromID = -1; link_toID = -1; link_maplevel = 0; link_modeflag = 0;
                                link_lanesize = 0; link_speedlimit = 0; link_type = 0; link_shapeID = -1;
                                link_length = 0;
                                link_name = null;
                            }

                            ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            node_id_pre = node_id;
                            node_id++;

                        }

                        bus_stop_size--;
                    }
                }
            }

            nwsrInput.Close();
            nwfsInput.Close();
            return true;

        }

        public bool LoadHistData_SQL2CSV()
        {

            // read TXT file for RecordID
            string path = @"netdata/";
            string filename;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            string szSrcLine;
            int[] RecordID;
            int SingleDataSize = 2426; // TMC link size

            filename = "9am.txt";
            nwfsInput = new FileStream(path + filename, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            int size = 73;
            RecordID = new int[size];
            int count = 0;

            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                RecordID[count] = int.Parse(szSrcLine);
                count++;
            }

            nwsrInput.Close();
            nwfsInput.Close();

            // read SQL
            double[,] HistSpd = new double[SingleDataSize, size];
            string[] TMCID = new string[SingleDataSize];
            SqlConnection myConnection = new SqlConnection();
            myConnection.ConnectionString = "Data Source=ZHOU-LAB-PC;" + "Integrated Security=SSPI;Initial Catalog=LiveTraffic;"
                + "user id=Tao;" + "password=taoxing;";
            myConnection.Open();
            SqlCommand cmd;

            for (int i = 0; i < size; i++)
            {
                cmd = new SqlCommand("SELECT [LinkID],[ThruCurrSpeed] FROM [LiveTraffic].[dbo].[Traffic_Bay] WHERE [RecordID] BETWEEN " +
                    RecordID[i] + " AND " + (RecordID[i] + SingleDataSize - 1) + "order by [RecordID]", myConnection);

                SqlDataReader rdr = cmd.ExecuteReader();
                count = 0;
                if (i == 0)
                    while (rdr.Read())
                    {
                        TMCID[count] = rdr.GetString(0);
                        HistSpd[count, i] = rdr.GetFloat(1);
                        count++;
                    }
                else
                    while (rdr.Read())
                    {
                        if (TMCID[count] != rdr.GetString(0))
                        { Console.WriteLine(RecordID[i] + count + "\t" + TMCID[count] + "\t" + rdr.GetString(0)); }
                        HistSpd[count, i] = rdr.GetFloat(1);
                        count++;
                    }
                rdr.Close();
                Console.WriteLine(RecordID[i] + "\t" + count);
            }
            myConnection.Close();

            // write into csv file
            StreamWriter file = new StreamWriter(path + "9am.csv");
            string temp = "";
            for (int i = 0; i < SingleDataSize; i++)
            {
                temp = TMCID[i] + ",";
                for (int j = 0; j < size; j++)
                {
                    temp += Math.Round(HistSpd[i, j], 2) + ",";
                }
                file.WriteLine(temp);
            }
            file.Close();

            return true;
        }

        public bool LoadHistData_CSV(string time, out double[] day_MeanVar)
        {
            // read CSV file for TMC table and Hist Spd
            string path = @"netdata/";
            string filename;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            string szSrcLine = "", subStr = "";
            int index = 0, subLength = 0;
            int SingleDataSize = 2388; // 2426; // TMC link size
            int DaySize = 73;
            //TODO: add TMC size and day size to the first line of CSV file
            TMCHistSpd = new double[SingleDataSize, DaySize];
            TMCwithRealData = new Dictionary<string, int>();

            filename = time + ".csv";
            nwfsInput = new FileStream(path + filename, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);

            int count = 0, line = -1;

            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                count = -1;
                while (szSrcLine.IndexOf(",") != -1)
                {
                    index = szSrcLine.IndexOf(",");
                    subStr = szSrcLine.Substring(0, index);
                    if (count == -1)
                    {
                        if ((!TMCIDtoLink.ContainsKey(subStr)) || TMCwithRealData.ContainsKey(subStr))
                        {
                            break;
                        }
                        line++;
                        TMCwithRealData.Add(subStr, line);
                    }
                    else
                    {
                        TMCHistSpd[line, count] = double.Parse(subStr);
                        if (TMCHistSpd[line, count] == -1)
                            TMCHistSpd[line, count] = TMCHistSpd[line, count - 1];
                    }
                    count++;
                    subLength = szSrcLine.Length;
                    if (subLength > 0)
                    {
                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                        szSrcLine = szSrcLine.Trim();
                    }
                }

            }

            nwsrInput.Close();
            nwfsInput.Close();

            int tmc_index = 0, tmc_size = TMCHistSpd.GetLength(0);
            double tt = 0, tt_min = 0, tt_max = 0, var = 0, length = 0, spd = 0, MeanTTvar = 0;
            day_MeanVar = new double[DaySize];

            // fill no-sensor link TT with random values
            LinkCost_DayD = new double[DaySize][]; // sample link costs in min
            for (int d = 0; d < DaySize; d++)
            {
                LinkCost_DayD[d] = new double[m_LinkSize];
            }
            Random r = new Random();
            count = 0;
            for (int l = 0; l < m_LinkSize; l++)
            {
                if (aryCLink[l].TMC != null && TMCwithRealData.ContainsKey(aryCLink[l].TMC))
                {
                    tmc_index = TMCwithRealData[aryCLink[l].TMC];
                    for (int d = 0; d < DaySize; d++)
                    {
                        LinkCost_DayD[d][l] = aryCLink[l].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                        //if (LinkCost_DayD[d][l] < 0)
                        //    LinkCost_DayD[d][l] = 0;
                    }
                    aryCLink[l].RealData = true;
                    count++;
                }
                else
                {
                    r = new Random(l);
                    for (int d = 0; d < DaySize; d++)
                    {
                        LinkCost_DayD[d][l] = LinkCost[l] * (r.NextDouble() + 0.5);
                    }
                }
            }

            // assign mean and variance value to each link
            LinkCost_min = new double[m_LinkSize];
            LinkCost_max = new double[m_LinkSize];
            m_max_ratio = 1;
            for (int l = 0; l < aryCLink.Length; l++)
            {
                tt = 0; var = 0;
                tt_min = 100000; tt_max = 0;
                length = aryCLink[l].Link_Length;
                spd = aryCLink[l].SpeedLimit;
                // calculate mean travel time
                for (int d = 0; d < DaySize; d++)
                {
                    tt += LinkCost_DayD[d][l];
                    if (LinkCost_DayD[d][l] < tt_min)
                        tt_min = LinkCost_DayD[d][l];
                    if (LinkCost_DayD[d][l] > tt_max)
                        tt_max = LinkCost_DayD[d][l];
                }
                tt = tt / (double)DaySize;
                aryCLink[l].TravelTime = tt;
                LinkCost[l] = tt;
                LinkCost_min[l] = tt_min;
                LinkCost_max[l] = tt_max;
                if (tt_max / tt_min > m_max_ratio)
                    m_max_ratio = tt_max / tt_min;
                
                // calculate travel time variance
                if (aryCLink[l].TMC != null && TMCwithRealData.ContainsKey(aryCLink[l].TMC))
                {
                    tmc_index = TMCwithRealData[aryCLink[l].TMC];
                    for (int d = 0; d < DaySize; d++)
                    {
                        var += Math.Pow((LinkCost_DayD[d][l] - tt) / (length / spd * 60), 2);
                        day_MeanVar[d] += Math.Pow((length / TMCHistSpd[tmc_index, d] * 60 - tt) / (length / spd * 60), 2);
                    }
                    var = var / DaySize;
                    aryCLink[l].TTVariance = var;
                }
                else
                {
                    for (int d = 0; d < DaySize; d++)
                    {
                        var += Math.Pow((LinkCost_DayD[d][l] - tt) / (length / spd * 60), 2);
                    }
                    var = var / DaySize;
                    aryCLink[l].TTVariance = var;
                }
            }
            for (int d = 0; d < DaySize; d++)
            {
                day_MeanVar[d] = day_MeanVar[d] / (count - 1); // mean TTI variance for each sample day 
            }

            //// output history tt to link-based format //////////////////////////////////
            //StreamWriter tt_file = new StreamWriter(path + "CA/traveltime.csv");
            //tt_file.Write("from_node_id, to_node_id,average_travel_time (min)");
            //for (int d = 1; d <= DaySize; d++)
            //{
            //    tt_file.Write(",day" + d);
            //}
            //tt_file.Write("\n");
            //count = 0;
            //bool dup_link = false;
            //for (int l = 0; l < m_LinkSize; l++)
            //{
            //    // check links with same OD
            //    dup_link = false;
            //    for (int exist_l = 0; exist_l < l; exist_l++)
            //    {
            //        if (aryCLink[exist_l].FromID == aryCLink[l].FromID && aryCLink[exist_l].ToID == aryCLink[l].ToID)
            //        {
            //            count++;
            //            dup_link = true;
            //            break;
            //        }
            //    }
            //    if (!dup_link)
            //    {
            //        tt_file.Write(aryCLink[l].FromID + "," + aryCLink[l].ToID + "," + aryCLink[l].TravelTime.ToString("F3"));
            //        for (int d = 0; d < DaySize; d++)
            //        {
            //            tt_file.Write("," + LinkCost_DayD[d][l].ToString("F3"));
            //        }
            //        tt_file.Write("\n");
            //    }
            //}
            //tt_file.Close();
            //////////////////////////////////////////////////////////////////////////////

            return true;
        }


        public void KNN_data()
        {
            string szSrcLine, subStr;
            int index, subLength;
            string filepath = @"C:\Research\Nonparametric Prediction\Data\speed_volume_occupancy\";
            string path = filepath;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            StreamWriter NewFile;

            #region
            // generate Inrix speed data into a single file            
            //NewFile = new StreamWriter(filepath + "Inrix_2010.csv");
            //NewFile.WriteLine("\"tmc_code\",\"measurement_tstamp\",\"speed\",\"average_speed\",\"reference_speed\"");
            //for (int q = 1; q <= 4; q++)
            //{
            //    path = filepath + "inrix_2010_q" + q + ".csv";
            //    nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //    nwsrInput = new StreamReader(nwfsInput);
            //    while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //    {                    
            //        if (szSrcLine.Substring(1, 9) == "110-04262")
            //            NewFile.WriteLine(szSrcLine);
            //    }
            //    nwsrInput.Close();
            //    nwfsInput.Close();
            //}             
            //NewFile.Close();            

            // generate weather data into a single file
            //NewFile = new StreamWriter(filepath + "Weather_2010_new.csv");
            //NewFile.WriteLine("Time,Temp,Humidity,DewPointTemp,BarometricPressure,AveWindSpeed,WindGust,WindDir,Precipitation,PrecipIntensity,PrecipAccumulation,Rate,Visibility(miles),SurfTemp,PrecipTotal");
            //int line = 0, count = 0;
            //string[] raw = new string[1];
            //string[] filenames = new string[] { "US-29_@_Mid_Patuxent 01_2011", "I-95_@_Patuxent 02_2011" };
            //for (int q = 1; q <= 14; q++)
            //{
            //    line = 0; count = 0;
            //    if (q > 12)
            //        path = filepath + filenames[q - 12 - 1] + ".csv";
            //    else
            //        path = filepath + "US-29_@_Mid_Patuxent " + q.ToString("D2") + "_2010.csv";
            //    nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //    nwsrInput = new StreamReader(nwfsInput);
            //    while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //    {
            //        line++;
            //    }
            //    nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //    nwsrInput = new StreamReader(nwfsInput);
            //    raw = new string[line];
            //    while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //    {
            //        raw[line - 1 - count] = szSrcLine;
            //        count++;
            //    }
            //    for (int i = 0; i < line; i++)
            //    {
            //        NewFile.WriteLine(raw[i]);
            //    }

            //    nwsrInput.Close();
            //    nwfsInput.Close();
            //}
            //NewFile.Close();

            //// format date time for incident data
            //path = filepath + "incidentsdata_112010-022011.csv";
            //nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //nwsrInput = new StreamReader(nwfsInput);
            //NewFile = new StreamWriter(filepath + "Incident_2011.csv");
            //NewFile.WriteLine("location,start_time,end_time,type,ritis_subtype,county");
            //string[] raw_data = new string[6];
            //string write = null;
            //DateTime start = new DateTime(), end = new DateTime();
            //szSrcLine = nwsrInput.ReadLine();
            //while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //{
            //    raw_data = szSrcLine.Split(',');
            //    start = Convert.ToDateTime(raw_data[1]);
            //    end = Convert.ToDateTime(raw_data[2]);
            //    raw_data[1] = start.ToString("yyyy/MM/dd HH:mm");
            //    raw_data[2] = end.ToString("yyyy/MM/dd HH:mm");
            //    for (int i = 0; i < 6; i++)
            //    {
            //        write += raw_data[i] + ",";
            //    }
            //    write = write.Substring(0, write.Length - 1);
            //    NewFile.WriteLine(write);
            //    write = "";
            //}
            //nwsrInput.Close();
            //nwfsInput.Close();
            //NewFile.Close();
            //////////////////////////////////////////
            #endregion


            int DataSize = 423 * 288;// until 2011-02-27 // 340 * 288; // until 2010-12-06
            double link_length = 1.08919;
            DateTime[] TimeStamp = new DateTime[DataSize];
            double[] TravelTime = new double[DataSize];
            int[] UpStreamVolume = new int[DataSize], DownStreamVolume = new int[DataSize], day_of_week = new int[DataSize], Incident = new int[DataSize];
            int[] Precipitation = new int[DataSize], Intensity = new int[DataSize], Visibility = new int[DataSize], WindSpeed = new int[DataSize];
            
            TimeStamp[0] = new DateTime(2010, 1, 1, 0, 0, 0);
            TravelTime[0] = -1; UpStreamVolume[0] = -1; DownStreamVolume[0] = -1; day_of_week[0] = 2;

            // holidays            
            DateTime[] holidays = new DateTime[13]{new DateTime(2010, 1, 1), new DateTime(2010, 1, 18), new DateTime(2010, 2, 15), 
                new DateTime(2010, 5, 31), new DateTime(2010, 7, 4), new DateTime(2010, 9, 6), new DateTime(2010, 10, 11), 
                new DateTime(2010, 11, 11), new DateTime(2010, 11, 25), new DateTime(2010, 12, 25), new DateTime(2010, 12, 31),
                new DateTime(2010, 1, 17), new DateTime(2010, 2, 21)};
            Dictionary<DateTime, int> Holiday = new Dictionary<DateTime, int>(10);
            for (int h = 0; h < 13; h++)
            {
                Holiday.Add(holidays[h], h);
            }
            // initial TimeStamp, values, and day of week
            for (int t = 1; t < DataSize; t++)
            {
                TimeStamp[t] = TimeStamp[t - 1].AddMinutes(5);
                TravelTime[t] = -1; UpStreamVolume[t] = -1; DownStreamVolume[t] = -1;
                // determine weekday/weekend/holiday
                if (TimeStamp[t].DayOfWeek == DayOfWeek.Saturday || TimeStamp[t].DayOfWeek == DayOfWeek.Sunday)
                    day_of_week[t] = 1;
                if (Holiday.ContainsKey(TimeStamp[t].Date))
                    day_of_week[t] = 2;
            }

            // load speed data Inrix
            path = filepath + "Inrix_2010_110-04262.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            string[] speed_raw_data = new string[5];
            szSrcLine = nwsrInput.ReadLine();
            int time = -1;
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                time++;
                if (time >= DataSize)
                    break;
                speed_raw_data = szSrcLine.Split(',');
                while (TimeStamp[time] != Convert.ToDateTime(speed_raw_data[1]))
                {
                    time++;
                    if (time >= DataSize)
                        break;
                }
                if (Convert.ToDouble(speed_raw_data[2]) <= 0)
                    speed_raw_data[2] = "5";
                TravelTime[time] = link_length / Convert.ToDouble(speed_raw_data[2]) * 3600;
            }
            nwsrInput.Close();
            nwfsInput.Close();

            // fix Inrix missing data
            TravelTime = FixMissingDataDouble(TravelTime);

            // flow data
            speed_raw_data = new string[4];
            time = 0;
            DateTime flow_time = new DateTime();
            int a = 0, b = 0;
            for (int q = 1; q <= 5; q++)
            {
                if (q >= 5)
                {
                    path = filepath + "detector_2011_q1.csv";
                }
                else
                {
                    path = filepath + "detector_2010_q" + q + ".csv";
                }
                nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
                nwsrInput = new StreamReader(nwfsInput);
                szSrcLine = nwsrInput.ReadLine();
                while ((szSrcLine = nwsrInput.ReadLine()) != null)
                {
                    speed_raw_data = szSrcLine.Split(',');
                    if (speed_raw_data[1].Length > 19)
                        flow_time = Convert.ToDateTime(speed_raw_data[1].Substring(1, 19));
                    else
                        flow_time = Convert.ToDateTime(speed_raw_data[1]);
                    while (TimeStamp[time] != flow_time)
                    {
                        time++;
                        if (a < 5 || b < 4)
                        { a = 0; b = 0; }
                        a = 0; b = 0;
                        if (time >= DataSize)
                            break;
                    }
                    if (time >= DataSize)
                        break;
                    if (Convert.ToInt32(speed_raw_data[0]) >= 9224 && Convert.ToInt32(speed_raw_data[0]) <= 9228)
                    {
                        if (UpStreamVolume[time] == -1)
                            UpStreamVolume[time] = 0;
                        UpStreamVolume[time] += Convert.ToInt32(speed_raw_data[2]);
                        a++;
                    }
                    if (Convert.ToInt32(speed_raw_data[0]) >= 9329 && Convert.ToInt32(speed_raw_data[0]) <= 9332)
                    {
                        if (DownStreamVolume[time] == -1)
                            DownStreamVolume[time] = 0;
                        DownStreamVolume[time] += Convert.ToInt32(speed_raw_data[2]);
                        b++;
                    }
                }
                nwsrInput.Close();
                nwfsInput.Close();
            }
            // fix volume missing data
            UpStreamVolume = FixMissingDataInt(UpStreamVolume);
            DownStreamVolume = FixMissingDataInt(DownStreamVolume);

            // read incident data
            path = filepath + "incident_2010_new.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            speed_raw_data = new string[7];
            DateTime incident_start = new DateTime(), incident_end = new DateTime();
            szSrcLine = nwsrInput.ReadLine();
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                speed_raw_data = szSrcLine.Split(',');
                incident_start = Convert.ToDateTime(speed_raw_data[2]);
                incident_end = Convert.ToDateTime(speed_raw_data[3]);
                time = 0;
                for (time = 0; time < DataSize; time++)
                    if (TimeStamp[time] >= incident_start && TimeStamp[time] <= incident_end)
                    {
                        Incident[time] = 1;
                    }

            }
            nwsrInput.Close();
            nwfsInput.Close();

            // read weather data
            path = filepath + "Weather_2010_new.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            speed_raw_data = new string[15];
            DateTime weather_start = new DateTime(2010,1,1,0,0,0), weather_end = new DateTime();
            szSrcLine = nwsrInput.ReadLine();
            time = 0;
            System.Globalization.CultureInfo cultures = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                speed_raw_data = szSrcLine.Split(',');
                weather_end = Convert.ToDateTime(speed_raw_data[0], cultures);
                while (TimeStamp[time] >= weather_start && TimeStamp[time] < weather_end)
                {
                    if (Convert.ToDouble("0" + speed_raw_data[5]) >= 6)
                        WindSpeed[time] = 1;
                    switch (speed_raw_data[8])
                    {
                        case "Rain":
                            Precipitation[time] = 1;
                            break;
                        case "Snow":
                            Precipitation[time] = 2;
                            break;
                    }
                    switch (speed_raw_data[9])
                    {
                        case "Slight":
                            Intensity[time] = 1;
                            break;
                        case "Moderate":
                            Intensity[time] = 2;
                            break;
                        case "Heavy":
                            Intensity[time] = 3;
                            break;
                    }
                    if (speed_raw_data[12] != "" && Convert.ToDouble("0" + speed_raw_data[12]) <= 0.25)
                        Visibility[time] = 1;
                    time++;
                    if (time >= DataSize)
                        break;
                }
                if (time >= DataSize)
                    break;
                weather_start = weather_end;
            }
            nwsrInput.Close();
            nwfsInput.Close();

            // write data into new csv file, generate cluster code
            NewFile = new StreamWriter(filepath + "Data_110-04262_new.csv");
            NewFile.WriteLine("TimeStamp,TravelTime,UpStreamVolume,DownStreamVolume,DayOfWeek,Incident,Precipitation,Intensity,Visibility,WindSpeed,Code");
            for (time = 0; time < DataSize; time++ )
            {
                NewFile.WriteLine(TimeStamp[time].ToString("yyyy-MM-dd HH:mm:ss") + "," + TravelTime[time] + "," + UpStreamVolume[time] + "," +
                    DownStreamVolume[time] + "," + day_of_week[time] + "," + Incident[time] + "," + Precipitation[time] + "," + Intensity[time]
                    + "," + Visibility[time] + "," + WindSpeed[time] + "," + day_of_week[time] + Incident[time] + Precipitation[time] + Intensity[time]
                    + Visibility[time] + WindSpeed[time]);
            }
            
            NewFile.Close();

            return;
        }

        public void KNN_data_long()
        {
            string szSrcLine;
            string filepath = @"C:\Research\Nonparametric Prediction\Data\New data\";
            string path = filepath;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            StreamWriter NewFile;

            #region
            //// generate Inrix speed data into a single file            
            //NewFile = new StreamWriter(filepath + "Inrix_long_2010.csv");
            //NewFile.WriteLine("tmc_code,measurement_tstamp,speed");
            //DateTime tmc_date = new DateTime(2010, 1, 1);
            //string[] raw = new string[8];
            //for (int q = 0; q < 572; q++)
            //{
            //    path = filepath + "INRIX Readings\\" + tmc_date.ToString("yyyy-MM-dd") + " 0000 to " + tmc_date.AddDays(1).ToString("yyyy-MM-dd") + " 0000 - 1.csv"; // 2010-01-01 0000 to 2010-01-02 0000 - 1.csv
            //    nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //    nwsrInput = new StreamReader(nwfsInput);
            //    szSrcLine = nwsrInput.ReadLine();
            //    while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //    {
            //        raw = szSrcLine.Split(',');
            //        if (raw[2].Substring(1, 2) == "0E")
            //            raw[2] = "\"0.00000\"";
            //        NewFile.WriteLine(raw[0].Substring(1, 9) + "," + raw[1].Substring(1, 21) + "," + raw[2].Substring(1, 6));
            //    }
            //    nwsrInput.Close();
            //    nwfsInput.Close();
            //    tmc_date = tmc_date.AddDays(1);
            //}
            //NewFile.Close();            

            //// generate weather data into a single file
            //NewFile = new StreamWriter(filepath + "Weather_long_2010.csv");
            //NewFile.WriteLine("Time,Temp,Humidity,DewPointTemp,BarometricPressure,AveWindSpeed,WindGust,WindDir,Precipitation,PrecipIntensity,PrecipAccumulation,Rate,Visibility(miles),SurfTemp,PrecipTotal");
            //int line = 0, count = 0;
            //string[] raw = new string[1];
            //DateTime weather_date = new DateTime(2010, 1, 1);
            //for (int q = 0; q < 19; q++)
            //{
            //    path = filepath + "weather data\\" + weather_date.AddMonths(q).ToString("yyyy-MM") +"\\I-95_@_Howard_Co.csv";
            //    line = 0; count = 0;
            //    nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //    nwsrInput = new StreamReader(nwfsInput);
            //    while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //    {
            //        line++;
            //    }
            //    nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            //    nwsrInput = new StreamReader(nwfsInput);
            //    raw = new string[line];
            //    while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //    {
            //        raw[line - 1 - count] = szSrcLine;  
            //        count++;
            //    }
            //    for (int i = 0; i < line; i++)
            //    {
            //        NewFile.WriteLine(raw[i]);
            //    }

            //    nwsrInput.Close();
            //    nwfsInput.Close();
            //}
            //NewFile.Close();

           //////////////////////////////////////////
            #endregion


            int DataSize = 572 * 288;// until 2011-07-26 164736
            double[] link_length = new double[] { 1.966358, 0.870892, 1.339863, 0.923773, 1.053211, 0.912837, 2.336029, 0.247628 };
            int link_size = 8;
            DateTime[] TimeStamp = new DateTime[DataSize];
            double[] TravelTime = new double[DataSize];
            int[] Volume = new int[DataSize], day_of_week = new int[DataSize], Incident = new int[DataSize];
            int[] Precipitation = new int[DataSize], Intensity = new int[DataSize], Visibility = new int[DataSize], WindSpeed = new int[DataSize];

            double[][] link_spd = new double[link_size][];
            for (int l = 0; l < link_size; l++)
            {
                link_spd[l] = new double[DataSize];
            }

            TimeStamp[0] = new DateTime(2010, 1, 1, 0, 0, 0);
            TravelTime[0] = -1; Volume[0] = -1; day_of_week[0] = 2;

            // holidays            
            DateTime[] holidays = new DateTime[]{new DateTime(2010, 1, 1), new DateTime(2010, 1, 18), new DateTime(2010, 2, 15), 
                new DateTime(2010, 5, 31), new DateTime(2010, 7, 4), new DateTime(2010, 9, 6), new DateTime(2010, 10, 11), 
                new DateTime(2010, 11, 11), new DateTime(2010, 11, 25), new DateTime(2010, 12, 25), new DateTime(2010, 12, 31),
                new DateTime(2011, 1, 17), new DateTime(2011, 2, 21), new DateTime(2011, 5, 30), new DateTime(2011, 7, 4)};
            Dictionary<DateTime, int> Holiday = new Dictionary<DateTime, int>(15);
            for (int h = 0; h < 15; h++)
            {
                Holiday.Add(holidays[h], h);
            }
            // initial TimeStamp, values, and day of week
            for (int t = 1; t < DataSize; t++)
            {
                TimeStamp[t] = TimeStamp[t - 1].AddMinutes(5);
                TravelTime[t] = -1; Volume[t] = -1; 
                for (int l = 0; l < link_size; l++)
                {
                    link_spd[l][t] = -1;
                }
                // determine weekday/weekend/holiday
                if (TimeStamp[t].DayOfWeek == DayOfWeek.Saturday || TimeStamp[t].DayOfWeek == DayOfWeek.Sunday)
                    day_of_week[t] = 1;
                if (Holiday.ContainsKey(TimeStamp[t].Date))
                    day_of_week[t] = 2;
            }

            // load speed data Inrix
            path = filepath + "Inrix_long_2010.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            string[] raw_data = new string[3];
            szSrcLine = nwsrInput.ReadLine();
            int time = 0;
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                if (time >= DataSize)
                    break;
                raw_data = szSrcLine.Split(',');
                while (TimeStamp[time] != Convert.ToDateTime(raw_data[1]))
                {
                    time++;
                    if (time >= DataSize)
                        break;
                }
                if (Convert.ToDouble(raw_data[2]) <= 0)
                    raw_data[2] = "-1";
                switch (raw_data[0])
                {
                    case "110+04419":
                        link_spd[0][time] = Convert.ToDouble(raw_data[2]);
                        break;
                    case "110P04419":
                        link_spd[1][time] = Convert.ToDouble(raw_data[2]);
                        break;
                    case "110+04420":
                        link_spd[2][time] = Convert.ToDouble(raw_data[2]);
                        break;
                    case "110P04420":
                        link_spd[3][time] = Convert.ToDouble(raw_data[2]);
                        break;
                    case "110+04421":
                        link_spd[4][time] = Convert.ToDouble(raw_data[2]);
                        break;
                    case "110P04421":
                        link_spd[5][time] = Convert.ToDouble(raw_data[2]);
                        break;
                    case "110+04422":
                        link_spd[6][time] = Convert.ToDouble(raw_data[2]);
                        break;
                    case "110P04422":
                        link_spd[7][time] = Convert.ToDouble(raw_data[2]);
                        break;
                }
            }
            nwsrInput.Close();
            nwfsInput.Close();
            
            // fix Inrix missing data
            for (int l = 0; l < link_size; l++)
                link_spd[l] = FixMissingDataDouble(link_spd[l]);

            // calculate path travel time
            double link_tt = 0;
            for (int t = 0; t < DataSize; t++ )
            {
                time = t;
                for (int l = link_size - 1; l >= 0; l--)
                {
                    link_tt = link_length[l] / link_spd[l][time] * 60; // path travel time is in min
                    // if travel time on this link is larger than 5 min, we first add 5 min to the path travel time 
                    // and then check the travel time of this link on previous time interval
                    while (link_tt >= 5)
                    {
                        TravelTime[t] += 5;
                        time = time - 1;
                        if (time < 0)
                            time = 0;
                        link_tt = link_length[l] / link_spd[l][time] * 60;
                    }
                    TravelTime[t] += link_tt;
                    time = time - (int)(TravelTime[t]) / 5;
                    if (time < 0)
                        time = 0;
                }
            }
            TravelTime = FixMissingDataDouble(TravelTime);

            //// generate new file for Inrix speed: one time interval each column
            //NewFile = new StreamWriter(filepath + "Inrix_long_2010_path.csv");
            //NewFile.WriteLine("time_stamp,spd_110+04419(mph),spd_110P04419,spd_110+04420,spd_110P04420,spd_110+04421,spd_110P04421,spd_110+04422,spd_110P04422,tt_110+04419(min),tt_110P04419,tt_110+04420,tt_110P04420,tt_110+04421,tt_110P04421,tt_110+04422,tt_110P04422");
            //string write = "";
            //for (int t = 0; t < DataSize; t++)
            //{
            //    write = TimeStamp[t].ToString("yyyy-MM-dd HH:mm:ss");
            //    for (int l = 0; l < link_size; l++)
            //    {
            //        write += "," + link_spd[l][t].ToString();
            //    }
            //    for (int l = 0; l < link_size; l++)
            //    {
            //        write += "," + link_length[l] / link_spd[l][t] * 60;
            //    }
            //    NewFile.WriteLine(write);
            //}
            //NewFile.Close();

            // flow data
            raw_data = new string[4];
            time = 0;
            DateTime flow_time = new DateTime();
            int a = 0, b = 0;
            path = filepath + "detector.csv";            
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            string[] raw_flow = new string[4];
            szSrcLine = nwsrInput.ReadLine();
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                raw_flow = szSrcLine.Split(',');
                if (raw_flow[1].Length > 19)
                    flow_time = Convert.ToDateTime(raw_flow[1].Substring(1, 19));
                else
                    flow_time = Convert.ToDateTime(raw_flow[1]);
                while (TimeStamp[time] != flow_time)
                {
                    if (Volume[time] != -1)
                        Volume[time] = Volume[time] / a * 33 / 8;
                    time++;
                    //if (a < 33)
                    //{ a = 0;}
                    a = 0;
                    if (time >= DataSize)
                        break;
                }
                if (time >= DataSize)
                    break;

                if (Volume[time] == -1)
                    Volume[time] = 0;
                Volume[time] += Convert.ToInt32(raw_flow[2]);
                a++;
            }
            nwsrInput.Close();
            nwfsInput.Close();

            // fix volume missing data
            Volume = FixMissingDataInt(Volume);

            // read incident data
            path = filepath + "incident_long_severe_2010.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            raw_data = new string[15];
            DateTime incident_start = new DateTime(), incident_end = new DateTime();
            szSrcLine = nwsrInput.ReadLine();
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                raw_data = szSrcLine.Split(',');
                incident_start = Convert.ToDateTime(raw_data[2]);
                incident_end = Convert.ToDateTime(raw_data[3]);
                time = 0;
                for (time = 0; time < DataSize; time++)
                {
                    if (TimeStamp[time] >= incident_start && TimeStamp[time] <= incident_end)
                    {
                        Incident[time] = 1;
                    }
                    if (TimeStamp[time] > incident_end)
                        break;
                }

            }
            nwsrInput.Close();
            nwfsInput.Close();

            // read weather data
            path = filepath + "Weather_long_2010.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            raw_data = new string[15];
            DateTime weather_start = new DateTime(2010, 1, 1, 0, 0, 0), weather_end = new DateTime();
            szSrcLine = nwsrInput.ReadLine();
            time = 0;
            System.Globalization.CultureInfo cultures = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                raw_data = szSrcLine.Split(',');
                weather_end = Convert.ToDateTime(raw_data[0], cultures);
                while (TimeStamp[time] >= weather_start && TimeStamp[time] < weather_end)
                {
                    if (Convert.ToDouble("0" + raw_data[5]) >= 6)
                        WindSpeed[time] = 1;
                    switch (raw_data[8])
                    {
                        case "Rain":
                            Precipitation[time] = 1;
                            break;
                        case "Snow":
                            Precipitation[time] = 2;
                            break;
                    }
                    switch (raw_data[9])
                    {
                        case "Slight":
                            Intensity[time] = 1;
                            break;
                        case "Moderate":
                            Intensity[time] = 2;
                            break;
                        case "Heavy":
                            Intensity[time] = 3;
                            break;
                    }
                    if (raw_data[12] != "" && Convert.ToDouble("0" + raw_data[12]) <= 0.25)
                        Visibility[time] = 1;
                    time++;
                    if (time >= DataSize)
                        break;
                }
                if (time >= DataSize)
                    break;
                weather_start = weather_end;
            }
            nwsrInput.Close();
            nwfsInput.Close();

            // write data into new csv file, generate cluster code
            NewFile = new StreamWriter(filepath + "Data_long_path.csv");
            NewFile.WriteLine("TimeStamp,TravelTime,UpStreamVolume,DownStreamVolume,DayOfWeek,Incident,Precipitation,Intensity,Visibility,WindSpeed,Code");
            for (time = 0; time < DataSize; time++)
            {
                NewFile.WriteLine(TimeStamp[time].ToString("yyyy-MM-dd HH:mm:ss") + "," + TravelTime[time] + "," + Volume[time] + "," +
                    Volume[time] + "," + day_of_week[time] + "," + Incident[time] + "," + Precipitation[time] + "," + Intensity[time]
                    + "," + Visibility[time] + "," + WindSpeed[time] + "," + day_of_week[time] + Incident[time] + Precipitation[time] + Intensity[time]
                    + Visibility[time] + WindSpeed[time]);
            }

            NewFile.Close();

            return;
        }


        private double[] FixMissingDataDouble(double[] data)
        {
            int flag = 0, time = 0, DataSize = data.Length;
            double post_data = 0, pre_data = 0;

            // in case first data is -1
            if (data[0] == -1)
            {
                time = 1;
                while (data[time] == -1)
                {
                    time = time + 1;
                    if (time >= DataSize)
                        break;
                }
                data[0] = data[time];
            }
            // in case last data is -1
            if (data[DataSize - 1] == -1)
            {
                time = 2;
                while (data[DataSize - time] == -1)
                {
                    time = time + 1;
                    if (time > DataSize)
                        break;
                }
                data[DataSize - 1] = data[DataSize - time];
            }
            // remove -1
            for (int i = 0; i < DataSize; i++)
            {
                if (data[i] == -1)
                {
                    flag = flag + 1;
                }
                if (data[i] != -1 && flag > 0)
                {
                    post_data = data[i];
                    pre_data = data[i - flag - 1];
                    for (int j = 1; j <= flag; j++)
                        data[i - j] = post_data - (post_data - pre_data) / (flag + 1) * j;
                    flag = 0;
                }
            }
            return data;
        }

        private int[] FixMissingDataInt(int[] data)
        {
            int flag = 0, time = 0, DataSize = data.Length;
            double post_data = 0, pre_data = 0;

            // in case first data is -1
            if (data[0] == -1)
            {
                time = 1;
                while (data[time] == -1)
                {
                    time = time + 1;
                    if (time >= DataSize)
                        break;
                }
                data[0] = data[time];
            }
            // in case last data is -1
            if (data[DataSize - 1] == -1)
            {
                time = 2;
                while (data[DataSize - time] == -1)
                {
                    time = time + 1;
                    if (time > DataSize)
                        break;
                }
                data[DataSize - 1] = data[DataSize - time];
            }
            // remove -1
            for (int i = 0; i < DataSize; i++)
            {
                if (data[i] == -1)
                {
                    flag = flag + 1;
                }
                if (data[i] != -1 && flag > 0)
                {
                    post_data = data[i];
                    pre_data = data[i - flag - 1];
                    for (int j = 1; j <= flag; j++)
                        data[i - j] = (int)(post_data - (post_data - pre_data) / (flag + 1) * j);
                    flag = 0;
                }
            }
            return data;
        }

        public bool LoadShapeID(string filepath)
        {
            string szSrcLine, subStr;
            int index, subLength;
            int shapeID = -1, linkIndex = 0;
            long linkID = 0;
            DirectionalID linkPlus = new DirectionalID(), linkMinus = new DirectionalID();
            string path = filepath + "LinkSeq.csv";
            FileStream nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                for (int i = 0; i < 5; i++)
                {
                    szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf(",");
                    if (index <= 0)
                    {
                        break;
                    }
                    else
                    {
                        subStr = szSrcLine.Substring(0, index);
                    }

                    switch (i)
                    {
                        case 3:
                            shapeID = int.Parse(subStr);
                            break;
                        case 4:
                            linkID = long.Parse(subStr);
                            linkPlus = new DirectionalID(linkID, true);
                            linkMinus = new DirectionalID(linkID, false);
                            break;
                    }
                    subLength = szSrcLine.Length;
                    szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                }
                if (m_LinkIDtoIndex.ContainsKey(linkPlus))
                {
                    linkIndex = m_LinkIDtoIndex[linkPlus];
                    aryCLink[linkIndex].ShapeID = shapeID;
                    aryCLink[linkIndex].ShapeDir = true;
                }
                if (m_LinkIDtoIndex.ContainsKey(linkMinus))
                {
                    linkIndex = m_LinkIDtoIndex[linkMinus];
                    aryCLink[linkIndex].ShapeID = shapeID;
                    aryCLink[linkIndex].ShapeDir = false;
                }
                shapeID = -1; linkID = 0; linkPlus = new DirectionalID(); linkMinus = new DirectionalID();
            }
            nwsrInput.Close();
            nwfsInput.Close();

            return true;
        }

        //public void LoadShapePoints_GEO(string filepath, string city)
        //{
        //    CShape Shape;
        //    int ShapeSize = 164315; // TODO: change size
        //    aryCShape = new CShape[ShapeSize];
        //    //read Shape_point.geo
        //    string szSrcLine, subStr;
        //    int index, subLength;
        //    long line = 0;
        //    ShapeIDtoIndex = new Dictionary<int, long>();
        //    Dictionary<int, long> ShapeIDtoIndex_Raw = new Dictionary<int, long>();
        //    int ShapeSize_Raw = 313557;
        //    string[] aryShapeString = new string[ShapeSize_Raw];
        //    string shapeString = "";
        //    int[] aryShapeSize = new int[ShapeSize_Raw];
        //    int shapeID = -1, shape_size = 0;
        //    double shape_long = 0, shape_lat = 0;
        //    //string filepath = @"E:\DATA\CA\";
        //    string path = filepath + "Shape_point_" + city + ".geo";
        //    // shape_point.geo data format: shapeID,shapSize,long,lat,long,lat... 
        //    // shapeSize == 2 means no shape points (just OD points)
        //    FileStream nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
        //    StreamReader nwsrInput = new StreamReader(nwfsInput);
        //    while ((szSrcLine = nwsrInput.ReadLine()) != null)
        //    {
        //        for (int i = 0; i < 3; i++)
        //        {
        //            szSrcLine = szSrcLine.Trim();
        //            index = szSrcLine.IndexOf(",");
        //            if (index <= 0)
        //            {
        //                break;
        //            }
        //            else
        //            {
        //                subStr = szSrcLine.Substring(0, index);
        //            }

        //            switch (i)
        //            {
        //                case 0:
        //                    shapeID = int.Parse(subStr);
        //                    break;
        //                case 1:
        //                    shape_size = int.Parse(subStr);
        //                    break;
        //                case 2:
        //                    shapeString = szSrcLine;
        //                    break;
        //            }
        //            subLength = szSrcLine.Length;
        //            szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
        //        }
        //        // if shape size  larger than 2, add shape to aryCShape
        //        if (shape_size > 2)
        //        {
        //            for (int i = 0; i < shape_size; i++)
        //            {
        //                shapeString = shapeString.Trim();
        //                index = shapeString.IndexOf(",");
        //                if (index <= 0)
        //                {
        //                    break;
        //                }
        //                else
        //                {
        //                    subStr = shapeString.Substring(0, index);
        //                }

        //            }
        //            if (shapeString != "")
        //            {
        //                // add last lat
        //            }
        //            // add ShapeIDtoIndex
        //            // adjust link.IsShape
        //            // warning if shape and link OD not match

        //        }

        //        shapeID = -1; shape_size = 0; shapeString = "";

        //    }

        //    int l = 0;
        //    int k = 0;
        //    line = 0;
        //    for (int j = 0; j < m_LinkSize; j++)
        //    {
        //        if (aryCLink[j].IsShape == true && ShapeIDtoIndex_Raw.ContainsKey(aryCLink[j].ShapeID))
        //        {
        //            k = (int)ShapeIDtoIndex_Raw[aryCLink[j].ShapeID];
        //            szSrcLine = aryShapeString[k];

        //            //read first point
        //            index = szSrcLine.IndexOf(",");
        //            subStr = szSrcLine.Substring(0, index);
        //            shape_long = double.Parse(subStr);
        //            subLength = szSrcLine.Length;
        //            szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
        //            index = szSrcLine.IndexOf(",");
        //            subStr = szSrcLine.Substring(0, index);
        //            shape_lat = double.Parse(subStr);
        //            subLength = szSrcLine.Length;
        //            szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);

        //            if (aryCNode[m_NodeIDtoIndex[aryCLink[j].FromID]].Node_Long == shape_long && aryCNode[m_NodeIDtoIndex[aryCLink[j].FromID]].Node_Lat == shape_lat)
        //            {
        //                if (ShapeIDtoIndex.ContainsKey(aryCLink[j].ShapeID))
        //                {
        //                    aryCLink[j].ShapeDir = true;
        //                }
        //                else
        //                {
        //                    aryCLink[j].ShapeDir = true;
        //                    ShapeIDtoIndex.Add(aryCLink[j].ShapeID, line);
        //                    for (l = 0; l < aryShapeSize[k] - 2; l++)
        //                    {
        //                        index = szSrcLine.IndexOf(",");
        //                        subStr = szSrcLine.Substring(0, index);
        //                        shape_long = double.Parse(subStr);
        //                        subLength = szSrcLine.Length;
        //                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
        //                        index = szSrcLine.IndexOf(",");
        //                        subStr = szSrcLine.Substring(0, index);
        //                        shape_lat = double.Parse(subStr);
        //                        subLength = szSrcLine.Length;
        //                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);

        //                        Shape = new CShape(aryCLink[j].ShapeID, l, shape_lat, shape_long);
        //                        aryCShape[line] = Shape;
        //                        line++;
        //                    }
        //                }
        //            }
        //            else if (aryCNode[m_NodeIDtoIndex[aryCLink[j].ToID]].Node_Long == shape_long && aryCNode[m_NodeIDtoIndex[aryCLink[j].ToID]].Node_Lat == shape_lat)
        //            {
        //                if (ShapeIDtoIndex.ContainsKey(aryCLink[j].ShapeID))
        //                {
        //                    aryCLink[j].ShapeDir = false;
        //                }
        //                else
        //                {
        //                    ShapeIDtoIndex.Add(aryCLink[j].ShapeID, line);
        //                    aryCLink[j].ShapeDir = false;
        //                    line = line + aryShapeSize[k] - 3;
        //                    for (l = aryShapeSize[k] - 3; l >= 0; l--)
        //                    {
        //                        index = szSrcLine.IndexOf(",");
        //                        subStr = szSrcLine.Substring(0, index);
        //                        shape_long = double.Parse(subStr);
        //                        subLength = szSrcLine.Length;
        //                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
        //                        index = szSrcLine.IndexOf(",");
        //                        subStr = szSrcLine.Substring(0, index);
        //                        shape_lat = double.Parse(subStr);
        //                        subLength = szSrcLine.Length;
        //                        szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);

        //                        Shape = new CShape(aryCLink[j].ShapeID, l, shape_lat, shape_long);
        //                        aryCShape[line] = Shape;
        //                        line--;
        //                    }
        //                    line = line + aryShapeSize[k] - 1;
        //                }
        //            }
        //        }
        //    }

        //    ShapeIDtoIndex_Raw.Clear();

        //    nwsrInput.Close();
        //    nwfsInput.Close();
        //}

        public void LoadRealTimeData_XML(string filepath)
        {
            //Decompress from gzip file and read xml file
            int max_size = 3516;
            string city = "7";
            string Element_Name = null;
            Stream fs, ms, gs, fs2;
            int size;
            byte[] tempb = new byte[100];
            byte[] resultb;
            XmlTextReader reader;
            int TMCIndex = 0;
            string lane = null, curr = null, dir = null;
            int ii = 0, error_count = 0;
            Dictionary<long, double> LinkID_Spd = new Dictionary<long, double>();
            string curr_TMC = null;
            double spd = 0;
            float[][] RealTimeData = new float[m_TimeIntervalSize][];
            TMCIndextoID = new string[max_size];
            TMCwithRealData = new Dictionary<string, int>();

            for (int i = 0; i < m_TimeIntervalSize; i++)
            {
                ii = (i + 176) % (m_TimeIntervalSize); //start from zero time interval
                // unzip file
                fs = new FileStream(filepath + "RealtimeFlow" + city + "_" + Convert.ToString(ii) + ".xml.gz", FileMode.Open);
                ms = new MemoryStream();
                gs = new GZipStream(fs, CompressionMode.Decompress, true);
                while (true)
                {
                    size = gs.Read(tempb, 0, 100);
                    if (size > 0)
                        ms.Write(tempb, 0, size);
                    else
                        break;
                }
                resultb = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(resultb, 0, (int)ms.Length);

                fs2 = new FileStream(filepath + "RealtimeFlow" + city + "_" + Convert.ToString(i) + ".xml", FileMode.Create, FileAccess.Write);
                fs2.Write(resultb, 0, resultb.Length - 1);
                fs2.Close();
                fs.Close();
                ms.Close();
                gs.Close();

                reader = new XmlTextReader(filepath + "RealtimeFlow" + city + "_" + Convert.ToString(i) + ".xml");
                if (!reader.Read())
                {
                    error_count++;
                    break;
                }
                //////////////
                RealTimeData[i] = new float[max_size];


                while (reader.Read())
                {
                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Element: // element.
                            Element_Name = reader.Name;
                            if (Element_Name == "LANE_TYPE")
                            {
                                lane = reader.GetAttribute("TYPE");
                            }
                            if (Element_Name == "TRAVEL_TIME")
                            {
                                curr = reader.GetAttribute("TYPE");
                            }
                            if (Element_Name == "FLOW_ITEMS")
                            {
                                dir = reader.GetAttribute("DIRECTION");
                            }
                            break;

                        case XmlNodeType.Text:
                            switch (Element_Name)
                            {
                                case "ID":
                                    curr_TMC = dir + reader.Value;
                                    if (!TMCwithRealData.ContainsKey(curr_TMC))
                                    {
                                        TMCwithRealData.Add(curr_TMC, TMCIndex);
                                        TMCIndextoID[TMCIndex] = curr_TMC;
                                        TMCIndex++;
                                    }
                                    break;

                                case "AVERAGE_SPEED":
                                    if (lane == "THRU" && curr == "current")
                                    {
                                        spd = double.Parse(reader.Value);
                                        RealTimeData[i][TMCwithRealData[curr_TMC]] = (float)spd;
                                        break;
                                    }
                                    else
                                    {
                                        break;
                                    }

                            }
                            break;

                    }

                }
                reader.Close();

            }
            // generate single XML file
            XmlTextWriter textWriter = new XmlTextWriter(filepath + "RealSpeedData_11_10_2008_288.xml", null);
            textWriter.WriteStartDocument();
            textWriter.WriteStartElement("Records");
            textWriter.WriteStartElement("NumberofRecords");
            textWriter.WriteString(Convert.ToString(max_size));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("Unit");
            textWriter.WriteString("mph");
            textWriter.WriteEndElement();
            for (int j = 0; j < max_size; j++)
            {
                textWriter.WriteStartElement("TMC");
                textWriter.WriteString(TMCIndextoID[j]);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("TravelTimeRecords");
                for (int k = 0; k < m_TimeIntervalSize; k++)
                {
                    textWriter.WriteStartElement("TI");
                    textWriter.WriteString(Convert.ToString(k));
                    textWriter.WriteEndElement();
                    textWriter.WriteStartElement("Spd");
                    textWriter.WriteString(Convert.ToString(RealTimeData[k][j]));
                    textWriter.WriteEndElement();
                }
                textWriter.WriteEndElement();
            }

            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();


        }

        public bool LoadRealTimeData_SingleXML(string filepath, string filename)
        {
            string Element_Name = null;
            int TMCSize, TMCIndex = 0, curr_TMCIndex = 0, curr_TI = 0;
            double[][] RealTimeData = new double[0][];
            string path = filepath + filename;
            XmlTextReader reader = new XmlTextReader(path);
            TMCwithRealData = new Dictionary<string, int>();

            if (!reader.Read())
                return false;

            double spd;
            string curr_TMC = null;

            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // element.
                        Element_Name = reader.Name;
                        break;
                    case XmlNodeType.Text:
                        switch (Element_Name)
                        {
                            case "NumberofRecords":
                                TMCSize = int.Parse(reader.Value);
                                RealTimeData = new double[TMCSize][];
                                TMCIndextoID = new string[TMCSize];
                                break;
                            case "TMC":
                                curr_TMC = reader.Value;
                                curr_TMCIndex = TMCIndex;
                                if (!TMCwithRealData.ContainsKey(curr_TMC))
                                {
                                    TMCwithRealData.Add(curr_TMC, TMCIndex);
                                    TMCIndextoID[TMCIndex] = curr_TMC;
                                    RealTimeData[TMCIndex] = new double[m_TimeIntervalSize];
                                    TMCIndex++;
                                }
                                break;
                            case "TI":
                                curr_TI = int.Parse(reader.Value);
                                break;
                            case "Spd":
                                spd = double.Parse(reader.Value);
                                RealTimeData[curr_TMCIndex][curr_TI] = spd;
                                break;
                        }
                        break;
                }

            }
            reader.Close();
            // update link cost on LinkCost_TimeD and LinkCost_TimeD_Penalty and LinkCost_TimeD_Transit
            int count = 0;
            for (int i = 0; i < m_LinkSize; i++)
            {
                if (aryCLink[i].TMC != null)
                {
                    if (TMCwithRealData.ContainsKey(aryCLink[i].TMC))
                    {
                        for (int j = 0; j < m_TimeIntervalSize; j++)
                        {
                            spd = RealTimeData[TMCwithRealData[aryCLink[i].TMC]][j];
                            if (spd <= 0)
                            {
                                if (j != 0)
                                {
                                    LinkCost_TimeD[i, j] = LinkCost_TimeD[i, j - 1];
                                    LinkCost_TimeD_Penalty[i, j] = LinkCost_TimeD_Penalty[i, j - 1];
                                    if (LinkCost_TimeD_Transit != null)
                                    {
                                        for (int k = 0; k < m_TimeInterval / m_TimeIntervalTransit; k++)
                                        {
                                            LinkCost_TimeD_Transit[i, j * (m_TimeInterval / m_TimeIntervalTransit) + k] = LinkCost_TimeD_Transit[i, (j - 1) * (m_TimeInterval / m_TimeIntervalTransit)];
                                        }
                                    }
                                }
                            }
                            else
                            {
                                LinkCost_TimeD[i, j] = aryCLink[i].Link_Length / spd * 60;
                                LinkCost_TimeD_Penalty[i, j] = aryCLink[i].Link_Length / spd * 60;
                                if (LinkCost_TimeD_Transit != null)
                                {
                                    for (int k = 0; k < m_TimeInterval / m_TimeIntervalTransit; k++)
                                    {
                                        LinkCost_TimeD_Transit[i, j * (m_TimeInterval / m_TimeIntervalTransit) + k] = aryCLink[i].Link_Length / spd * 60;
                                    }
                                }
                            }
                        }
                        count++;
                    }
                }
            }

            return true;
        }

        /*public void ImportTMC(string filepath)
        {
            int TMC_Raw_Size = 251805;
            string[] aryTMC_Raw = new string[TMC_Raw_Size];
            double[] aryTMC_Lat = new double[TMC_Raw_Size];
            double[] aryTMC_Long = new double[TMC_Raw_Size];
            double[] aryTMC_UTM_Easting = new double[TMC_Raw_Size];
            double[] aryTMC_UTM_Northing = new double[TMC_Raw_Size];
            int[] aryTMC_UTM_Zone = new int[TMC_Raw_Size];
            string path;
            FileStream nwfsInput;
            StreamReader nwsrInput;

            //int nodeID = -1, node_UTM_zone = 0;
            //double node_long = 0, node_lat = 0, node_easting = 0, node_northing = 0;
            //string node_name = null;
            //CNode node;

            //////////////////////////////////////////////////////////////////////////////////////////
            //read raw TMC table
            int line = 0;

            path = filepath + "TMC_table.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine, subStr;
            int index, subLength;
            LatLongValue nval;

            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                index = szSrcLine.IndexOf("\",\"");
                subStr = szSrcLine.Substring(1, index - 1);
                subStr = subStr.Trim();
                aryTMC_Raw[line] = subStr;
                subLength = szSrcLine.Length;
                szSrcLine = szSrcLine.Substring(index + 3, subLength - index - 3);

                index = szSrcLine.IndexOf("\",\"");
                subStr = szSrcLine.Substring(0, index);
                aryTMC_Long[line] = double.Parse(subStr);

                subLength = szSrcLine.Length;
                szSrcLine = szSrcLine.Substring(index + 3, subLength - index - 3);
                index = szSrcLine.IndexOf("\"");
                subStr = szSrcLine.Substring(0, index);
                aryTMC_Lat[line] = double.Parse(subStr);

                nval = new LatLongValue();
                nval = LatLongValue.LatLongToUTM(aryTMC_Lat[line], aryTMC_Long[line]);
                aryTMC_UTM_Easting[line] = nval.utmEx;
                aryTMC_UTM_Northing[line] = nval.utmNy;
                aryTMC_UTM_Zone[line] = nval.zone;

                line++;
            }
            double dist = 0, min_dist = 0;
            double nlat = 0, nlong = 0, n2lat = 0, n2long = 0;
            //double easting1, easting2, northing1, northing2;
            //int zone1, zone2;
            string curr_TMC = null;
            int curr_j = 0, k = 0;

            for (int i = 0; i < m_LinkSize; i++)
            {

                //find out closest link based on Lat/Long
                nlat = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_FromID]].Node_Lat;
                nlong = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_FromID]].Node_Long;
                n2lat = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_ToID]].Node_Lat;
                n2long = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_ToID]].Node_Long;

                min_dist = Math.Pow(nlat - aryTMC_Lat[0], 2) + Math.Pow(nlong - aryTMC_Long[0], 2);

                //first find out the closest node
                for (int j = 0; j < TMC_Raw_Size; j++)
                {
                    dist = Math.Pow(nlat - aryTMC_Lat[j], 2) + Math.Pow(nlong - aryTMC_Long[j], 2);
                    if (dist < min_dist)
                    {
                        curr_TMC = aryTMC_Raw[j];
                        curr_j = j;
                        min_dist = dist;
                    }
                }
                //second test the angle
                if (aryTMC_Raw[curr_j + 1] == aryTMC_Raw[curr_j])
                {
                    if (Math.Abs(Math.Atan((n2lat - nlat) / (n2long - nlong)) - Math.Atan((aryTMC_Lat[curr_j + 1] - aryTMC_Lat[curr_j]) / (aryTMC_Long[curr_j + 1] - aryTMC_Long[curr_j]))) < 3.14 / 4)
                    {
                        aryCLink[i].Link_TMC = curr_TMC;
                        k++;
                    }
                }
                else
                {
                    if (Math.Abs(Math.Atan((n2lat - nlat) / (n2long - nlong)) - Math.Atan((aryTMC_Lat[curr_j] - aryTMC_Lat[curr_j - 1]) / (aryTMC_Long[curr_j] - aryTMC_Long[curr_j - 1]))) < 3.14 / 4)
                    {
                        aryCLink[i].Link_TMC = curr_TMC;
                        k++;
                    }
                }

                ////find out closest link based on UTM
                //easting1 = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_FromID]].Node_UTM_Easting;
                //easting2 = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_ToID]].Node_UTM_Easting;
                //northing1 = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_FromID]].Node_UTM_Northing;
                //northing2 = aryCNode[m_NodeIDtoIndex[aryCLink[i].Link_ToID]].Node_UTM_Northing;

                //min_dist = Math.Pow(easting1 - aryTMC_UTM_Easting[0], 2) + Math.Pow(northing1 - aryTMC_UTM_Northing[0], 2);

                ////first find out the closest node
                //for (int j = 0; j < TMC_Raw_Size; j++)
                //{
                //    dist = Math.Pow(easting1 - aryTMC_UTM_Easting[j], 2) + Math.Pow(northing1 - aryTMC_UTM_Northing[j], 2);
                //    if (dist < min_dist)
                //    {
                //        curr_TMC = aryTMC_Raw[j];
                //        curr_j = j;
                //        min_dist = dist;
                //    }
                //}
                ////second test the angle
                //if (aryTMC_Raw[curr_j + 1] == aryTMC_Raw[curr_j])
                //{
                //    if (Math.Abs(Math.Atan((northing2 - northing1) / (easting2 - easting1)) - Math.Atan((aryTMC_UTM_Northing[curr_j + 1] - aryTMC_UTM_Northing[curr_j]) / (aryTMC_UTM_Easting[curr_j + 1] - aryTMC_UTM_Easting[curr_j]))) < 3.14 / 4)
                //    {
                //        aryCLink[i].Link_TMC = curr_TMC;
                //        k++;
                //    }
                //}
                //else
                //{
                //    if (Math.Abs(Math.Atan((northing2 - northing1) / (easting2 - easting1)) - Math.Atan((aryTMC_UTM_Northing[curr_j] - aryTMC_UTM_Northing[curr_j - 1]) / (aryTMC_UTM_Easting[curr_j] - aryTMC_UTM_Easting[curr_j - 1]))) < 3.14 / 4)
                //    {
                //        aryCLink[i].Link_TMC = curr_TMC;
                //        k++;
                //    }
                //}
                

            }

        }*/

        /*public void ImportTMC_CSV(string filepath)
        {
            FileStream nwfsInput;
            StreamReader nwsrInput;
            int line = 0;
            //string filepath = @"E:\DATA\CA\";
            string path = filepath + "san_fran_bay_edge2tmc.csv";
            nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine, subStr;
            int index, subLength;
            LinkID2TMC = new Dictionary<long, string>();
            long link_id = 0;
            string road_dir, tmc;
            int kk = 0;
            string insert = "0", a, b;

            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                index = szSrcLine.IndexOf(",");
                subStr = szSrcLine.Substring(0, index);
                subStr = subStr.Trim();
                link_id = int.Parse(subStr);
                subLength = szSrcLine.Length;
                szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);

                subStr = szSrcLine.Substring(0, 1);
                road_dir = subStr;

                index = szSrcLine.IndexOf(",");
                subStr = szSrcLine.Substring(1, index - 1);
                tmc = subStr;
                if (tmc.Length < 9)
                {
                    a = tmc.Substring(0, 4);
                    b = tmc.Substring(4, 4);
                    tmc = a + insert + b;
                    kk++;
                }

                switch (LinkID2TMC.ContainsKey(link_id))
                {
                    case true:
                        LinkID2TMC.Remove(link_id);
                        break;
                    case false:
                        LinkID2TMC.Add(link_id, tmc);
                        break;
                }


                line++;
            }
            int k = 0;
            for (int i = 0; i < m_LinkSize; i++)
            {
                if (LinkID2TMC.ContainsKey(aryCLink[i].Link_ID))
                {
                    aryCLink[i].Link_TMC = LinkID2TMC[aryCLink[i].Link_ID];
                    k++;
                }
                else
                {
                    aryCLink[i].Link_TMC = null;
                }
            }

        }*/


        /*public bool ImportHistIncidentData(string filepath, bool real) //import safety data
        {

            CLink link = new CLink();
            int count = 0;
            int line = 0;
            long link_id = 0;
            int link_index;
            int raw = 0, I_count = 0, N_count = 0;
            //string filepath = @"E:\DATA\CA\";
            string path = null;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            string szSrcLine, subStr;
            string szSrcLine_backup;
            int index, subLength;
            int flag = 0;
            int link_count = 0;
            DirectionalID DirLinkPlus = new DirectionalID(), DirLinkMinus = new DirectionalID();
            if (real == true)
            {
                for (int l = 0; l < 2; l++)
                {
                    switch (l)
                    {
                        case 0:
                            path = filepath + "280_Hwy_Col_XY.csv";
                            I_count = 0; N_count = 0; line = 0; raw = 0;
                            break;
                        case 1:
                            path = filepath + "280_Ramp_Col_XY.csv";
                            I_count = 0; N_count = 0; line = 0; raw = 0;
                            break;
                    }
                    nwfsInput = new FileStream(path, FileMode.Open, FileAccess.Read);
                    nwsrInput = new StreamReader(nwfsInput);

                    while ((szSrcLine = nwsrInput.ReadLine()) != null)
                    {
                        flag = 0;
                        for (int i = 0; i < 7; i++)
                        {
                            szSrcLine = szSrcLine.Trim();
                            index = szSrcLine.IndexOf(",");
                            subStr = szSrcLine.Substring(0, index);
                            switch (i)
                            {
                                case 6:
                                    link_id = long.Parse(subStr);
                                    DirLinkPlus = new DirectionalID(link_id, true);
                                    DirLinkMinus = new DirectionalID(link_id, false);
                                    if (m_LinkIDtoIndex.ContainsKey(DirLinkPlus) || m_LinkIDtoIndex.ContainsKey(DirLinkMinus))
                                    {
                                        link = m_LinkIDtoIndex[link_id];
                                        if (aryCLink[link_index].Link_Name == "I-280" || aryCLink[link_index].Link_Name == null || aryCLink[link_index].Link_Name == "I-680")
                                        {
                                            flag = 1;
                                            aryCLink[link_index].Link_Safety++;
                                            count++;
                                            raw++;
                                        }
                                    }

                                    break;

                            }
                            subLength = szSrcLine.Length;
                            szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                        }
                        szSrcLine = szSrcLine.Trim();//last element
                        szSrcLine_backup = szSrcLine;

                        //test name I-280
                        if (flag != 1)
                        {
                            while (szSrcLine.IndexOf(" ") != -1)
                            {
                                szSrcLine = szSrcLine.Trim();
                                index = szSrcLine.IndexOf(" ");
                                subStr = szSrcLine.Substring(0, index);

                                link_id = long.Parse(subStr);
                                if (m_LinkIDtoIndex.ContainsKey(link_id))
                                {
                                    link_index = m_LinkIDtoIndex[link_id];
                                    if (aryCLink[link_index].Link_Name == "I-280" || aryCLink[link_index].Link_Name == "I-680")
                                    {
                                        flag = 1;
                                        aryCLink[link_index].Link_Safety++;
                                        count++;
                                        I_count++;
                                        break;
                                    }
                                }
                                subLength = szSrcLine.Length;
                                szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                            }
                            if (flag != 1 && szSrcLine.Length != 0) // && 
                            {
                                szSrcLine = szSrcLine.Trim();//last element
                                link_id = long.Parse(szSrcLine);
                                if (m_LinkIDtoIndex.ContainsKey(link_id))
                                {
                                    link_index = m_LinkIDtoIndex[link_id];
                                    if (aryCLink[link_index].Link_Name == "I-280" || aryCLink[link_index].Link_Name == "I-680")
                                    {
                                        flag = 1;
                                        aryCLink[link_index].Link_Safety++;
                                        count++;
                                        I_count++;
                                    }
                                }
                            }
                        }

                        //test name ==null
                        szSrcLine = szSrcLine_backup;
                        if (flag != 1)
                        {
                            while (szSrcLine.IndexOf(" ") != -1)
                            {
                                szSrcLine = szSrcLine.Trim();
                                index = szSrcLine.IndexOf(" ");
                                subStr = szSrcLine.Substring(0, index);

                                link_id = long.Parse(subStr);
                                if (m_LinkIDtoIndex.ContainsKey(link_id))
                                {
                                    link_index = m_LinkIDtoIndex[link_id];
                                    if (aryCLink[link_index].Link_Name == null)
                                    {
                                        flag = 1;
                                        aryCLink[link_index].Link_Safety++;
                                        count++;
                                        N_count++;
                                        break;
                                    }
                                }
                                subLength = szSrcLine.Length;
                                szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);
                            }
                            if (flag != 1 && szSrcLine.Length != 0) // && 
                            {
                                szSrcLine = szSrcLine.Trim();//last element
                                link_id = long.Parse(szSrcLine);
                                if (m_LinkIDtoIndex.ContainsKey(link_id))
                                {
                                    link_index = m_LinkIDtoIndex[link_id];
                                    if (aryCLink[link_index].Link_Name == null)
                                    {
                                        flag = 1;
                                        aryCLink[link_index].Link_Safety++;
                                        count++;
                                        N_count++;
                                    }
                                }
                            }
                        }

                        if (flag == 0)
                            flag = 0;

                        line++;
                    }
                    //clean

                }
                link_count = 0;
                for (int a = 0; a < m_LinkSize; a++)
                {
                    if (aryCLink[a].Link_Safety != 0)
                    {
                        aryCLink[a].Link_Safety = aryCLink[a].Link_Safety / (13 * 24 * 4500) * 1.5;
                        link_count++;
                    }
                }
            }

            //set initial values for no-data links
            double rate = 0;
            if (link_count == 0)
            {
                rate = 80; //default incident rate
            }
            else
            {
                rate = (double)count / (double)link_count;
            }
            for (int a = 0; a < m_LinkSize; a++)
            {
                if (aryCLink[a].Link_Safety == 0)
                {
                    aryCLink[a].Link_Safety = rate / (13 * 24 * 4500) * 1.5;
                }
            }

            return true;

        }*/


        public void Create_SPTree_XML(int[] PredAry, int destination)
        {

            //convert PredAry from node index to node id
            int[] PredAryID = new int[m_NodeSize];
            for (int i = 0; i < m_NodeSize; i++)
            {
                if (PredAry[i] == -1)
                    PredAryID[i] = PredAry[i];
                else
                    PredAryID[i] = m_NodeIndextoID[PredAry[i]];
            }
            int destination_index = m_NodeIDtoIndex[destination];
            ///////////////////////////////

            string path = @"C:\works\VII\Test\2008.00.00.Tao.Routing_Engine\Data\";
            //string a = "<?echo \"<?xml version=\\\"1.0\\\" ?>\";?>";
            //int time;
            XmlTextWriter textWriter = new XmlTextWriter(path + "SPT" + Convert.ToString(destination) + ".xml", null);
            textWriter.WriteStartDocument();

            //textWriter.WriteDocType("echo", null, null, "<?xml version=\\\"1.0\\\" ?>");
            textWriter.WriteStartElement("SPT");
            textWriter.WriteStartElement("DNode");
            //textWriter.WriteStartElement("N");
            textWriter.WriteString(Convert.ToString(destination));
            textWriter.WriteEndElement();
            /*textWriter.WriteStartElement("node_ID_X");
            textWriter.WriteString(Convert.ToString(aryCNode[destination_index].Node_Long));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("node_ID_Y");
            textWriter.WriteString(Convert.ToString(aryCNode[destination_index].Node_Lat));
            textWriter.WriteEndElement();
            textWriter.WriteEndElement();*/

            //textWriter.WriteStartElement("Time");
            //textWriter.WriteString(time.ToString);
            //textWriter.WriteEndElement();

            /*for (int i = 0; i < m_NodeSize; i++)
            {
                textWriter.WriteStartElement("N");
                textWriter.WriteAttributeString("ID", Convert.ToString(m_NodeIndextoID[i]));
                textWriter.WriteAttributeString("pred", Convert.ToString(PredAryID[i]));
                //textWriter.WriteAttributeString("node_ID_X", Convert.ToString(aryCNode[i].Node_Long));
                //textWriter.WriteAttributeString("node_ID_Y", Convert.ToString(aryCNode[i].Node_Lat));
                //textWriter.WriteString(PredAry[i].ToString);
                textWriter.WriteEndElement();
            }*/

            for (int i = 0; i < m_NodeSize; i++)
            {
                textWriter.WriteStartElement("N");
                textWriter.WriteStartElement("ID");
                textWriter.WriteString(Convert.ToString(m_NodeIndextoID[i]));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("P");
                textWriter.WriteString(Convert.ToString(PredAryID[i]));
                textWriter.WriteEndElement();
                /*textWriter.WriteStartElement("node_ID_X");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_X));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("node_ID_Y");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_Y));
                textWriter.WriteEndElement();*/
                textWriter.WriteEndElement();
            }

            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();
        }


        public void SubNetworkGenerator(string filepath, string filename)
        {
            List<int> Sub_node_ID = new List<int>();
            List<int> Sub_link_index = new List<int>();
            int node_id = -1;
            for (int l = 0; l < m_LinkSize; l++)
            {
                if (aryCLink[l].Link_Type <= 2)
                {
                    Sub_link_index.Add(l);
                    node_id = aryCLink[l].FromID;
                    if (!Sub_node_ID.Contains(node_id))
                        Sub_node_ID.Add(node_id);
                    node_id = aryCLink[l].ToID;
                    if (!Sub_node_ID.Contains(node_id))
                        Sub_node_ID.Add(node_id);
                }
            }

            int[] Ary_Sub_node_index = new int[Sub_node_ID.Count];
            for(int n = 0; n < Sub_node_ID.Count; n++)
            {
                Ary_Sub_node_index[n] = m_NodeIDtoIndex[Sub_node_ID[n]];
            }
            int[] Ary_Sub_link_index = Sub_link_index.ToArray();

            CreateSubNetwork_XML(filepath, filename, Ary_Sub_node_index, Ary_Sub_link_index);
        }


        public void CreateSubNetwork_XML(string filepath, string filename, int[] sub_node_index, int[] sub_link_index)
        {
            //string path = @"C:\works\VII\Test\2008.00.00.Tao.Routing_Engine\Data\";

            XmlTextWriter textWriter = new XmlTextWriter(filepath + "NetworkSize_" + filename + ".xml", null);
            textWriter.WriteStartDocument();

            textWriter.WriteStartElement("NetworkSize");
            textWriter.WriteStartElement("NumOfRecords_Nodes");
            textWriter.WriteString(Convert.ToString(sub_node_index.Length));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("NumOfRecords_Links");
            textWriter.WriteString(Convert.ToString(sub_link_index.Length));
            textWriter.WriteEndElement();

            //bounds of network: put 0 if not sure
            textWriter.WriteStartElement("RECT");
            textWriter.WriteStartElement("LEFT");
            textWriter.WriteString(Convert.ToString(left));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("RIGHT");
            textWriter.WriteString(Convert.ToString(right));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("UP");
            textWriter.WriteString(Convert.ToString(up));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("LOW");
            textWriter.WriteString(Convert.ToString(low));
            textWriter.WriteEndElement();
            textWriter.WriteEndElement();
            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();


            textWriter = new XmlTextWriter(filepath + "Nodes_" + filename + ".xml", null);
            textWriter.WriteStartDocument();

            textWriter.WriteStartElement("Nodes");
            textWriter.WriteStartElement("NumOfRecords");
            textWriter.WriteString(Convert.ToString(sub_node_index.Length));
            textWriter.WriteEndElement();
            for (int i = 0; i < sub_node_index.Length; i++)
            {
                textWriter.WriteStartElement("Node");

                textWriter.WriteStartElement("NodeID");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_ID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("AreaID");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_AreaID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NodeName");
                textWriter.WriteString(aryCNode[sub_node_index[i]].Node_Name);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LNG");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_Long));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LAT");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_Lat));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("UTMEasting");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_UTM_Easting));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("UTMNorthing");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_UTM_Northing));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("UTMZone");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_UTM_Zone));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("MapLevel");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_MapLevel));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NodeControlType");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_ControlType));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NodeType");
                textWriter.WriteString(Convert.ToString(aryCNode[sub_node_index[i]].Node_Type));
                textWriter.WriteEndElement();

                textWriter.WriteEndElement();

            }

            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();


            textWriter = new XmlTextWriter(filepath + "Links_" + filename + ".xml", null);
            textWriter.WriteStartDocument();

            textWriter.WriteStartElement("Links");
            textWriter.WriteStartElement("NumOfRecords");
            textWriter.WriteString(Convert.ToString(sub_link_index.Length));
            textWriter.WriteEndElement();
            for (int i = 0; i < sub_link_index.Length; i++)
            {
                textWriter.WriteStartElement("Link");

                textWriter.WriteStartElement("LinkID");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].ID.ID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkDir");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].ID.Dir));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("AreaID");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].AreaID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkName");
                textWriter.WriteString(aryCLink[sub_link_index[i]].Link_Name);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("FromNodeID");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].FromID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("ToNodeID");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].ToID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("MapLevel");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].MapLevel));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("ModeFlag");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].ModeFlag));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkLength");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].Link_Length));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NumberOfLanes");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].LaneSize));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("SpeedLimit");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].SpeedLimit));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("FFTT");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].TravelTime));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkType");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].Link_Type));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("IsShape");
                if (aryCLink[sub_link_index[i]].IsShape)
                    textWriter.WriteString(Convert.ToString(1));
                else
                    textWriter.WriteString(Convert.ToString(0));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("ShapeID");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].ShapeID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("TMC");
                textWriter.WriteString(aryCLink[sub_link_index[i]].TMC);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("RealData");
                textWriter.WriteString(Convert.ToString(aryCLink[sub_link_index[i]].RealData));
                textWriter.WriteEndElement();

                textWriter.WriteEndElement();

            }

            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();
        }

        // file output functions

        public void CreateNetwork_XML(string filepath, string filename)
        {
            //string path = @"C:\works\VII\Test\2008.00.00.Tao.Routing_Engine\Data\";

            XmlTextWriter textWriter = new XmlTextWriter(filepath + "NetworkSize_" + filename + ".xml", null);
            textWriter.WriteStartDocument();

            textWriter.WriteStartElement("NetworkSize");
            textWriter.WriteStartElement("NumOfRecords_Nodes");
            textWriter.WriteString(Convert.ToString(m_NodeSize));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("NumOfRecords_Links");
            textWriter.WriteString(Convert.ToString(m_LinkSize));
            textWriter.WriteEndElement();

            //bounds of network: put 0 if not sure
            textWriter.WriteStartElement("RECT");
            textWriter.WriteStartElement("LEFT");
            textWriter.WriteString(Convert.ToString(left));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("RIGHT");
            textWriter.WriteString(Convert.ToString(right));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("UP");
            textWriter.WriteString(Convert.ToString(up));
            textWriter.WriteEndElement();
            textWriter.WriteStartElement("LOW");
            textWriter.WriteString(Convert.ToString(low));
            textWriter.WriteEndElement();
            textWriter.WriteEndElement();
            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();


            textWriter = new XmlTextWriter(filepath + "Nodes_" + filename + ".xml", null);
            textWriter.WriteStartDocument();

            textWriter.WriteStartElement("Nodes");
            textWriter.WriteStartElement("NumOfRecords");
            textWriter.WriteString(Convert.ToString(m_NodeSize));
            textWriter.WriteEndElement();
            for (int i = 0; i < m_NodeSize; i++)
            {
                textWriter.WriteStartElement("Node");

                textWriter.WriteStartElement("NodeID");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_ID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("AreaID");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_AreaID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NodeName");
                textWriter.WriteString(aryCNode[i].Node_Name);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LNG");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_Long));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LAT");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_Lat));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("UTMEasting");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_UTM_Easting));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("UTMNorthing");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_UTM_Northing));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("UTMZone");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_UTM_Zone));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("MapLevel");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_MapLevel));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NodeControlType");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_ControlType));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NodeType");
                textWriter.WriteString(Convert.ToString(aryCNode[i].Node_Type));
                textWriter.WriteEndElement();

                textWriter.WriteEndElement();

            }

            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();


            textWriter = new XmlTextWriter(filepath + "Links_" + filename + ".xml", null);
            textWriter.WriteStartDocument();

            textWriter.WriteStartElement("Links");
            textWriter.WriteStartElement("NumOfRecords");
            textWriter.WriteString(Convert.ToString(m_LinkSize));
            textWriter.WriteEndElement();
            for (int i = 0; i < m_LinkSize; i++)
            {
                textWriter.WriteStartElement("Link");

                textWriter.WriteStartElement("LinkID");
                textWriter.WriteString(Convert.ToString(aryCLink[i].ID.ID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkDir");
                textWriter.WriteString(Convert.ToString(aryCLink[i].ID.Dir));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("AreaID");
                textWriter.WriteString(Convert.ToString(aryCLink[i].AreaID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkName");
                textWriter.WriteString(aryCLink[i].Link_Name);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("FromNodeID");
                textWriter.WriteString(Convert.ToString(aryCLink[i].FromID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("ToNodeID");
                textWriter.WriteString(Convert.ToString(aryCLink[i].ToID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("MapLevel");
                textWriter.WriteString(Convert.ToString(aryCLink[i].MapLevel));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("ModeFlag");
                textWriter.WriteString(Convert.ToString(aryCLink[i].ModeFlag));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkLength");
                textWriter.WriteString(Convert.ToString(aryCLink[i].Link_Length));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("NumberOfLanes");
                textWriter.WriteString(Convert.ToString(aryCLink[i].LaneSize));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("SpeedLimit");
                textWriter.WriteString(Convert.ToString(aryCLink[i].SpeedLimit));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("FFTT");
                textWriter.WriteString(Convert.ToString(aryCLink[i].TravelTime));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("LinkType");
                textWriter.WriteString(Convert.ToString(aryCLink[i].Link_Type));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("IsShape");
                if (aryCLink[i].IsShape)
                    textWriter.WriteString(Convert.ToString(1));
                else
                    textWriter.WriteString(Convert.ToString(0));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("ShapeID");
                textWriter.WriteString(Convert.ToString(aryCLink[i].ShapeID));
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("TMC");
                textWriter.WriteString(aryCLink[i].TMC);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("RealData");
                textWriter.WriteString(Convert.ToString(aryCLink[i].RealData));
                textWriter.WriteEndElement();

                textWriter.WriteEndElement();

            }

            textWriter.WriteEndElement();
            textWriter.WriteEndDocument();
            textWriter.Close();
        }

        /// <summary>
        /// Generate csv files of links and nodes for DTALite and new version NEXTA
        /// </summary>
        /// <param name="filepath">output path</param>
        /// <param name="project_name">the name used for the folder of the new project</param>
        /// <returns></returns>
        public bool Generate_DTALite_Input(string filepath, string project_name)
        {
            // generate a new folder for the project
            string Project_Path = System.IO.Path.Combine(filepath, project_name);
            System.IO.Directory.CreateDirectory(Project_Path);

            //generate node.csv file
            StreamWriter node_file = new StreamWriter(Project_Path + "/" + "input_node.csv");
            node_file.WriteLine("node_id, X, Y, name");
            for (int n = 0; n < m_NodeSize; n++)
            {
                node_file.WriteLine(aryCNode[n].Node_ID + "," + aryCNode[n].Node_Long + "," + aryCNode[n].Node_Lat + "," + aryCNode[n].Node_Name);
            }
            node_file.Close();

            // generate link.csv file
            int count = 0;
            bool dup_link = false;
            StreamWriter link_file = new StreamWriter(Project_Path + "/" + "input_link.csv");
            link_file.WriteLine("from_node_id, to_node_id, direction, length, number_of_lanes, speed_limit, lane_capacity_in_vhc_per_hour," +  
                "link_type, name, BPR_alpha_term, BPR_beta_term, transit_transfer_time_in_min, transit_waiting_time_in_min, transit_fare");

            for (int l = 0; l < m_LinkSize; l++)
            {
                // check links with same OD
                dup_link = false;
                for (int exist_l = 0; exist_l < l; exist_l++)
                {
                    if (aryCLink[exist_l].FromID == aryCLink[l].FromID && aryCLink[exist_l].ToID == aryCLink[l].ToID)
                    {
                        count++;
                        dup_link = true;
                        break;
                    }
                }

                if (!dup_link)
                {
                    // Default values: Direction=1, aryCLink[l].LaneSize=2, lane_capacity_in_vhc_per_hour=2000, aryCLink[l].Link_Name=""
                    // Default none: BPR_alpha_term, BPR_beta_term, transit_transfer_time_in_min, transit_waiting_time_in_min, transit_fare
                    link_file.WriteLine(aryCLink[l].FromID + "," + aryCLink[l].ToID + ",1," + aryCLink[l].Link_Length + "," + 2 + "," +
                        aryCLink[l].SpeedLimit + "," + 2000 + "," + aryCLink[l].Link_Type + ",,,,,,");
                }
            }

            link_file.Close();

            return true;
        }

        public bool Generate_NEXTA_Input(string filepath, string filename)
        {
            //generate .dws file
            StreamWriter file = new StreamWriter(filepath + filename + ".dws");
            file.WriteLine("Version=\"2.0\"");
            file.WriteLine("Origin=\"bottom_left\"");
            file.WriteLine("coordinate=\"feet\"");
            file.WriteLine("start_time=\"0\"");
            file.Close();
            //generate xy.dat
            file = new StreamWriter(filepath + "xy.dat");
            for (int n = 0; n < m_NodeSize; n++)
            {
                file.WriteLine("\t" + aryCNode[n].Node_ID + "\t" + aryCNode[n].Node_Long + "\t" + aryCNode[n].Node_Lat);
            }
            file.Close();
            //generate network.dat
            file = new StreamWriter(filepath + "network.dat");
            file.WriteLine("\t" + 1 + "\t" + m_NodeSize + "\t" + m_LinkSize + "\t" + 0 + "\t" + 0);
            for (int n = 0; n < m_NodeSize; n++)
            {
                file.WriteLine("\t" + aryCNode[n].Node_ID + "\t" + 0);
            }
            for (int l = 0; l < m_LinkSize; l++)
            {
                file.WriteLine("\t" + aryCLink[l].FromID + "\t" + aryCLink[l].ToID + "\t" + 0 + "\t" + 0 + "\t" + (int)Math.Floor(aryCLink[l].Link_Length * 1000 + 0.5)
                     + "\t" + aryCLink[l].LaneSize + "\t" + 1 + "\t+0\t" + aryCLink[l].SpeedLimit + "\t" + "2000  1800  5  +0");
            }
            file.Close();

            return true;
        }


    }
}
