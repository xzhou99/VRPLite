﻿//  Copyright 2008-2010 Tao Xing, Xuesong Zhou @ University of Utah
//  tao.xing@utah.edu
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.


using System;
using System.Data;
using System.Configuration;
using System.Text;

using System.Drawing;
using System.Drawing.Imaging;

using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;

using System.Xml;
using System.Net;
using winServerSVN;

namespace Acceleration
{
    public class CAcceleration
    {
        public double AcceDriving, AcceGravity, AcceRight;
        public double AcceDirection;

        public CAcceleration()
        {
            AcceDriving = 0;
            AcceGravity = 0;
            AcceRight = 0;
            AcceDirection = 0;
        }
        public CAcceleration(double _AcceDriving, double _AcceGravity, double _AcceRight)
        {
            AcceDriving = _AcceDriving;
            AcceGravity = _AcceGravity;
            AcceRight = _AcceRight;
            AcceDirection = Math.Sqrt(_AcceDriving * _AcceDriving + _AcceRight * _AcceRight);
        }
    }

    public class Acceleration
    {
        public static double m_Gravity = 9.8;
        public double[][] m_xyz;

        public Acceleration()
        {
        }

        public bool CoordinateConvertXYZToDriving(string GravityDirection, string DrivingDirection, double[] xyz, out CAcceleration DrivingAcce)
        {
            if (xyz.Length != 3)
            {
                DrivingAcce = null;
                return false;
            }
            double G_sign = 0, D_sign = 0, R_sign = 0;
            //switch (GravityDirection)
            //{
            //    case "-x":
            //        G_sign = -1;
            //        DrivingAcce.AcceGravity = G_sign * xyz[0];
            //        break;
            //    case "-z":



            //}
            DrivingAcce = null;
            return true;
        }



    }


}