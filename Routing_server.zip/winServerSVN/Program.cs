//  Copyright 2008-2010 Tao Xing, Xuesong Zhou @ University of Utah
//  tao.xing@utah.edu
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using NetworkManager;
using DemoCode;
using System.Threading;
using MySQL;
using System.Windows.Forms;
using System.Net;
using System.IO.Compression;

namespace winServerSVN
{
    static class Program
    {
        static TextWriter m_fileWriter;
        static bool m_running = true;
        static AccelerationForm m_AcceForm;
        #region Server Request Handlers

        static void mobileRequestHandler()
        {
            char[] chbuffer = new char[2200];
            NetworkManager.NetManager nm = new NetworkManager.NetManager();
            TransNetwork slc = new TransNetwork("SLC");
            TransNetwork ca = new TransNetwork("CA");
            RouteParams rpm;
            
            try
            {
                //nm.createServer(9200, "155.98.4.160", 10);
                //nm.createServer(9200, "127.0.0.1", 10);
                nm.createServer(9200, "192.168.0.100", 10);

            }
            catch (Exception e)
            {
                return;
            }
            int con = 10000;
            double time = 0;
            DateTime LocalTime;
            while (m_running)
            {
                try
                {
                    nm.serverAccept();
                    con++;
                    bzero(chbuffer, 2200);
                    nm.readClientData(chbuffer, 2200);
                    LocalTime = DateTime.Now;
                    Console.WriteLine("Mobile Client" + con + ": " + LocalTime.Month + "/" + LocalTime.Day + "/" +
                        LocalTime.Year + " " + LocalTime.Hour + ":" + LocalTime.Minute + ":" + LocalTime.Second + "\r\n");
                    m_fileWriter.WriteLine("Mobile Client" + con + ": " + LocalTime.Month + "/" + LocalTime.Day + "/" +
                        LocalTime.Year + " " + LocalTime.Hour + ":" + LocalTime.Minute + ":" + LocalTime.Second + "\r\n");
                    Console.WriteLine("url:" + new string(chbuffer) + "\r\nIP:" + nm.SZClientIP + "\r\n");
                    m_fileWriter.WriteLine("url:" + new string(chbuffer));
                    m_fileWriter.WriteLine("IP:" + nm.SZClientIP + "\r\n");
                    if ((new string(chbuffer)).Contains("SYNACC"))
                    {
                        m_AcceForm = new AccelerationForm();
                        m_AcceForm.Cleanup();
                        string ack = "ACK";
                        char[] ccbuff = new char[ack.Length];
                        bzero(ccbuff, ack.Length);
                        ack.CopyTo(0, ccbuff, 0, ack.Length);
                        nm.sendClientData(ccbuff, ack.Length);
                        continue;
                    }
                    if ((new string(chbuffer)).Contains("SYN"))
                    {
                        string ack = "ACK";
                        char[] ccbuff = new char[ack.Length];
                        bzero(ccbuff, ack.Length);
                        ack.CopyTo(0, ccbuff, 0, ack.Length);
                        nm.sendClientData(ccbuff, ack.Length);
                        continue;
                    }
                    if ((new string(chbuffer)).Contains("ACCL"))
                    {
                        if (m_AcceForm == null)
                        {
                            m_AcceForm = new AccelerationForm();
                        }
                        m_AcceForm.ReceiveAcceData(new string(chbuffer));
                        continue;
                    }
                    if ((new string(chbuffer)).Contains("GET"))
                    {
                        rpm = slc.GetLatLong(new string(chbuffer) + " HTTP/1.0\r\n\r\n");
                        if (slc.LocateCity(rpm.Data[0], rpm.Data[1], rpm.Data[2], rpm.Data[3]))
                        {
                            Console.WriteLine("Routing request for Salt Lake City.\n");
                            m_fileWriter.WriteLine("Routing request for Salt Lake City.\n");
                            int CandidateSize = 9;
                            int RouteSize = 5;
                            time = 0;
                            string str = slc.GetShrtPath(rpm.Data[0], rpm.Data[1], rpm.Data[2],
                                                        rpm.Data[3], rpm.StrTime, rpm.IsRealTime,
                                                        rpm.WithTrafficColor, con, RouteSize, CandidateSize, out time) + "EOF";
                            if (str == "rgbky#NONEEOF")
                            {
                                Console.WriteLine("No route calculated.\n");
                                m_fileWriter.WriteLine("No route calculated.\n");
                            }
                            else
                            {
                                Console.WriteLine("Routing time used: " + time.ToString() + "seconds \n");
                                m_fileWriter.WriteLine("Routing time used: " + time.ToString() + "seconds \n");
                            }
                            char[] ccbuff = new char[str.Length];
                            bzero(ccbuff, str.Length);
                            str.CopyTo(0, ccbuff, 0, str.Length);
                            nm.sendClientData(ccbuff, str.Length);
                        }
                        else if (ca.LocateCity(rpm.Data[0], rpm.Data[1], rpm.Data[2], rpm.Data[3]))
                        {
                            Console.WriteLine("Routing request for Bay Area.\n");
                            m_fileWriter.WriteLine("Routing request for Bay Area.\n");
                            int CandidateSize = 5;
                            int RouteSize = 2;
                            time = 0;
                            string str = ca.GetShrtPath(rpm.Data[0], rpm.Data[1], rpm.Data[2],
                                                        rpm.Data[3], rpm.StrTime, rpm.IsRealTime,
                                                        rpm.WithTrafficColor, con, RouteSize, CandidateSize, out time) + "EOF";
                            if (str == "rgbky#NONEEOF")
                            {
                                Console.WriteLine("No route calculated.\n");
                                m_fileWriter.WriteLine("No route calculated.\n");
                            }
                            else
                            {
                                Console.WriteLine("Routing time used: " + time.ToString() + "seconds \n");
                                m_fileWriter.WriteLine("Routing time used: " + time.ToString() + "seconds \n");
                            }
                            char[] ccbuff = new char[str.Length];
                            bzero(ccbuff, str.Length);
                            str.CopyTo(0, ccbuff, 0, str.Length);
                            nm.sendClientData(ccbuff, str.Length);
                        }
                        else
                        {
                            string str = "rgbky#" + "NONE" + "EOF";
                            Console.WriteLine("No route calculated.\n");
                            m_fileWriter.WriteLine("No route calculated.\n");
                            char[] ccbuff = new char[str.Length];
                            bzero(ccbuff, str.Length);
                            str.CopyTo(0, ccbuff, 0, str.Length);
                            nm.sendClientData(ccbuff, str.Length);
                        }
                        continue;
                    }
                }
                catch (Exception e)
                {
                    m_fileWriter.WriteLine(e.Message);
                    Console.Out.WriteLine(e.Message);
                }
            }
            nm.closeServer();
        }

        
        static void gpsmobileRequestHandler()
        {
            char[] chbuffer = new char[144];
            NetworkManager.NetManager nm = new NetworkManager.NetManager();
            TransNetwork dm = new TransNetwork("SLC");
            nm.createServer(9400, "155.98.4.160", 10);
            int con = 0;
            while (m_running)
            {
                try
                {
                    nm.serverAccept();
                    con++;
                    bzero(chbuffer, 144);
                    nm.readClientData(chbuffer, 144);
                    Console.WriteLine("Mobile gps Client" + con + "\nurl:" + new string(chbuffer));
                    parseData(new string(chbuffer));
                    string str = dm.GetGPSTrace("?uid=1&did=1") + "EOF";
                    //Console.WriteLine("Server response:" + str);
                    char[] ccbuff = new char[str.Length];
                    bzero(ccbuff, str.Length);
                    str.CopyTo(0, ccbuff, 0, str.Length);
                    nm.sendClientData(ccbuff, str.Length);
                }
                catch (Exception e)
                {
                    Console.Out.WriteLine(e.Message);
                    m_fileWriter.WriteLine(e.Message);
                }
            }
            nm.closeServer();
        }

        
        static void webRequestHandler()
        {
            char[] chbuffer = new char[144];
            int requestnumber = 0;
            NetworkManager.NetManager nm = new NetworkManager.NetManager();
            //TransNetwork slc = new TransNetwork("SLC");
            //slc.m_network.draw();
            TransNetwork ca = new TransNetwork("CA");
            //TransNetwork ca = new TransNetwork("CA_HWY");
            //ca.m_network.Generate_DTALite_Input(@"netdata/", "CA_HWY");
            //ca.m_network.LinkPile(37.407477, -122.065905, 37.361664, -121.879299);
            //ca.m_network.PathEnumeration(37.6446846, -122.0934677, 37.0749019, -121.5966797); //(37.0749019, -121.5966797, 38.1669548, -122.5772095);
            //ca.m_network.SensorLocator(true);
            //ca.m_network.SubNetworkGenerator(@"netdata/", "CA_HWY");
            //ca.m_network.draw();
            //ca.m_network.ReliablePath_Sampling(1000, 2000);
            //ca.m_network.ReliablePathEvaluation();
            //ca.m_network.ReliablePath(1000, 2000);
            //TransNetwork demo = new TransNetwork("newDEMO");
            //demo.m_network.ReliablePath_Sampling_Single(0, 1, 20);
            //TransNetwork M1 = new TransNetwork("M1");
            //M1.m_network.ReliablePath(0, 1);
            /*System.Runtime.("cd C:\\inetpub\\wwwroot\\map\\images\\Contour\\");
            System("del *");*/
            RouteParams rpm;
            nm.createServer(9000, "127.0.0.1", 10);
            int con = 0;
            double time = 0;
            //test map-matching
            //string mmch = ca.GetMapMatching(ca.GetMapMatchingRequestSQL());
            //string mmch = ca.GetMapMatching(ca.GetMapMatchingRequestString("mm"));
            //while (m_running)
            //{
            //    try
            //    {
            //        nm.serverAccept();
            //        con++;
            //        requestnumber++;
            //        bzero(chbuffer, 144);
            //        nm.readClientData(chbuffer, 144);
            //        Console.WriteLine("Web Client" + con + "\nurl:" + new string(chbuffer) + "\nIP:" + nm.SZClientIP + "\n");                    

            //        rpm = slc.GetLatLong(new string(chbuffer));
            //        time = 0;
            //        string str = slc.GetShrtPath(rpm.Data[0], rpm.Data[1], rpm.Data[2], rpm.Data[3],
            //                                    rpm.StrTime, rpm.IsRealTime, false, requestnumber, 5, 9, out time);
            //        //Console.WriteLine("Server response:" + str);
            //        Console.WriteLine("Routing time used: " + time.ToString() + "seconds \n");
            //        str = requestnumber + "$" + str;
            //        char[] ccbuff = new char[str.Length];
            //        bzero(ccbuff, str.Length);
            //        str.CopyTo(0, ccbuff, 0, str.Length);
            //        nm.sendClientData(ccbuff, str.Length);
            //    }
            //    catch (Exception e)
            //    {
            //        Console.Out.WriteLine(e.Message);
            //        m_fileWriter.WriteLine(e.Message);
            //    }
            //}
            nm.closeServer();
        }

        static void pingRequestHandler()
        {
            char[] chbuffer = new char[144];
            NetworkManager.NetManager nm = new NetworkManager.NetManager();
            nm.createServer(9999, "155.98.4.160", 10);
            int con = 0;
            while (m_running)
            {
                try
                {
                    nm.serverAccept();
                    con++;
                    bzero(chbuffer, 144);
                    nm.readClientData(chbuffer, 144);
                    Console.WriteLine("Ping Client" + con + "\nurl:" + new string(chbuffer) + "\nIP:" + nm.SZClientIP + "\n");
                    string str = "ACK";
                    string req = new string(chbuffer);
                    if (req.Substring(0, 3).Equals((string)"SYN"))
                    {
                        str = "ACK";
                    }
                    else
                    {
                        str = "NACK";
                    }
                    char[] ccbuff = new char[str.Length];
                    bzero(ccbuff, str.Length);
                    str.CopyTo(0, ccbuff, 0, str.Length);
                    nm.sendClientData(ccbuff, str.Length);
                }
                catch (Exception e)
                {
                    Console.Out.WriteLine(e.Message);
                    m_fileWriter.WriteLine(e.Message);
                }
            }
            nm.closeServer();
        }
        #endregion

        static void AccelForm()
        {
            Application.Run(new AccelerationForm());
        }

        static void Main(string[] args)
        {
            DateTime current = DateTime.Now;
            m_fileWriter = new StreamWriter("log"+current.Day + current.Month+current.Year+current.Hour+current.Minute+".txt");
            m_fileWriter.WriteLine("New Log File");

            Thread web = new Thread(webRequestHandler);
            web.Start();            

            //Thread mobile = new Thread(mobileRequestHandler);
            //mobile.Start();

            //Thread accel = new Thread(AccelForm);
            //accel.Start();

            //Thread gpsmobile = new Thread(gpsmobileRequestHandler);
            //gpsmobile.Start();

            //Thread ping = new Thread(pingRequestHandler);
            //ping.Start();

            Console.Out.WriteLine("Press q key to seal the log file");
            m_fileWriter.WriteLine("Date: " + current.Day +"/" + current.Month + "/" + current.Year + "   " + current.Hour + ":" + current.Minute + "\n");
            char ch = 'l';
            
            while (ch != 'q')
                ch = (char)Console.Read();
            m_fileWriter.Close();
        }

        #region Helper methods
        /// <summary>
        /// This method fills the character buffer with ilength 0's
        /// </summary>
        /// <param name="chbuffer">buffer to fill</param>
        /// <param name="ilength">number of 0s to place</param>
        public static void bzero(char[] chbuffer, int ilength)
        {
            for (int i = 0; i < ilength; i++)
            {
                chbuffer[i] = '\0';
            }
        }

        /// <summary>
        /// Inserts the given string data into the mySql server.
        /// </summary>
        /// <param name="str">Data to insert</param>
        static void parseData(string str)
        {
            string temp = str;
            try
            {
                double lat = double.Parse(temp.Substring(temp.IndexOf("lat=") + 4, temp.IndexOf("&") - temp.IndexOf("lat=") - 4));
                temp = temp.Substring(temp.IndexOf("&") + 1);
                double lon = double.Parse(temp.Substring(temp.IndexOf("lon=") + 4, temp.IndexOf("&") - temp.IndexOf("lon=") - 4));
                temp = temp.Substring(temp.IndexOf("&") + 1);
                double mph = double.Parse(temp.Substring(temp.IndexOf("mph=") + 4, temp.IndexOf("&") - temp.IndexOf("mph=") - 4));
                temp = temp.Substring(temp.IndexOf("&") + 1);
                double dir = double.Parse(temp.Substring(temp.IndexOf("dir=") + 4, temp.IndexOf("&") - temp.IndexOf("dir=") - 4));
                temp = temp.Substring(temp.IndexOf("&") + 1);
                string dtt = temp.Substring(temp.IndexOf("dt=") + 3, temp.IndexOf("&") - temp.IndexOf("dt=") - 3);
                temp = temp.Substring(temp.IndexOf("&") + 1);
                string did = temp.Substring(temp.IndexOf("did=") + 4, temp.IndexOf(" H") - temp.IndexOf("did=") - 4);

                try
                {
                    MySQL.connectDB cdb = new connectDB();
                    string dquery = "insert into rawprobedataslc (TimeStamp,DeviceID,Latitude,Longitude,Speed,Bearing) values(" + "\'" + dtt + "\'" + "," + did + "," + lat + "," + lon + "," + mph + "," + dir + ")";
                    //cdb.ExecuteQuery(dquery);
                }
                catch (Exception ez)
                {
                    Console.WriteLine("Error:" + ez.Message);
                }
            }
            catch (System.Exception ee)
            { }

        }
        #endregion
    }
}
