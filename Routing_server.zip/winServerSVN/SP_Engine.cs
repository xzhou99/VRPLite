//  Copyright 2008-2010 Tao Xing, Xuesong Zhou @ University of Utah
//  tao.xing@utah.edu
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Data;
using System.Configuration;
using System.Text;

using System.Drawing;
using System.Drawing.Imaging;

using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;

using System.Xml;
using System.Net;

using UTMconv;
using MathNet.Numerics.LinearAlgebra.Double;

//using MySql.Data.MySqlClient;

namespace Routing_Engine
{




    //Node class
    public class CNode
    {
        public int Node_ID, Node_AreaID;
        public double Node_Long, Node_Lat, Node_UTM_Easting, Node_UTM_Northing;
        public int Node_UTM_Zone, Node_MapLevel, Node_ControlType, Node_Type;
        public string Node_Name;

        //constructor
        public CNode()
        {
            Node_ID = 0;
            Node_AreaID = 0;
            Node_Long = 0;
            Node_Lat = 0;
            Node_UTM_Easting = 0;
            Node_UTM_Northing = 0;
            Node_UTM_Zone = 0;
            Node_MapLevel = 0;
            Node_ControlType = 0;
            Node_Type = 0;
            Node_Name = null;
        }
        //overloading constructor
        public CNode(int _Node_ID, int _Node_AreaID, double _Node_Long, double _Node_Lat, double _Node_UTM_Easting, double _Node_UTM_Northing, int _Node_UTM_Zone,
            int _Node_MapLevel, int _Node_ControlType, int _Node_Type, string _Node_Name)
        {
            Node_ID = _Node_ID;
            Node_AreaID = _Node_AreaID;
            Node_Long = _Node_Long;
            Node_Lat = _Node_Lat;
            Node_UTM_Easting = _Node_UTM_Easting;
            Node_UTM_Northing = _Node_UTM_Northing;
            Node_UTM_Zone = _Node_UTM_Zone;
            Node_MapLevel = _Node_MapLevel;
            Node_ControlType = _Node_ControlType;
            Node_Type = _Node_Type;
            Node_Name = _Node_Name;
        }

    }

    //Link class
    public class CLink
    {
        public DirectionalID ID;
        public int AreaID, FromID, ToID, MapLevel, ModeFlag, LaneSize, Link_Type, ShapeID, Capacity, SensorID;
        public double Link_Length, SpeedLimit, TravelTime, Safety, TTVariance;//unit
        public string Link_Name, TMC;
        private double Feet2Mile = 0.1894F; //1 foot = 0.0001894 mile
        public bool ShapeDir, IsShape, RealData; //direction of shape point stored in the aryCShape
        // Link_Type == 2: free way; Link_Type > 2 arterial

        //constructor
        public CLink()
        {
            ID = new DirectionalID();//
            AreaID = 0;//
            Link_Name = null;
            FromID = 0;//
            ToID = 0;//
            MapLevel = 0;//
            ModeFlag = 0;//
            Capacity = 0;
            Link_Length = 0;// mile
            LaneSize = 0;//
            SpeedLimit = 0;// mph
            TravelTime = 0;// min
            Link_Type = 0;//
            IsShape = false;
            RealData = false;
            ShapeID = 0;
            ShapeDir = true;
            TMC = null;
            SensorID = 0;
            Safety = 0;
            TTVariance = 0;
        }

        //overloading constructor
        public CLink(DirectionalID _Link_ID, int _Link_AreaID, string _Link_Name, int _Link_FromID, int _Link_ToID, int _Link_MapLevel, int _Link_ModeFlag,
                     string _Link_Length_Unit, int _Link_Capacity, double _Link_Length, int _Link_LaneSize, double _Link_SpeedLimit, int _Link_Type, bool _Link_IsShape,
                     int _Link_ShapeID, bool _Link_ShapeDir, double _Link_Safety, bool _Link_RealData, int _SensorID)
        {
            ID = _Link_ID;
            AreaID = _Link_AreaID;
            Link_Name = _Link_Name;
            FromID = _Link_FromID;
            ToID = _Link_ToID;
            MapLevel = _Link_MapLevel;
            ModeFlag = _Link_ModeFlag;
            Capacity = _Link_Capacity;
            if (_Link_Length_Unit == "feet")
            {
                Link_Length = _Link_Length / 1000 * Feet2Mile;
            }
            if (_Link_Length_Unit == "mile")
            {
                Link_Length = _Link_Length;
            }
            LaneSize = _Link_LaneSize;
            SpeedLimit = _Link_SpeedLimit;//unit: mph
            TravelTime = Link_Length / SpeedLimit * 60;
            Link_Type = _Link_Type;
            IsShape = _Link_IsShape;
            ShapeID = _Link_ShapeID;
            ShapeDir = _Link_ShapeDir;
            TMC = null;
            SensorID = _SensorID;
            Safety = _Link_Safety;
            TTVariance = 0;
            RealData = _Link_RealData;
        }

    }

    public class CSensor
    {
        public int sensorID;
        public int sensor_type;
        // sensor type: 0: loop detector, 1: AVI, 2: probe(GPS)
        /// <summary>
        /// constructor
        /// </summary>
        public CSensor()
        {
            sensorID = 0;
            sensor_type = 0;
        }

        /// <summary>
        /// Overloading constructor
        /// </summary>
        /// <param name="_ID">ID</param>
        /// <param name="_Dir">Direction</param>
        public CSensor(int _sensorID, int _sensor_type)
        {
            sensorID = _sensorID;
            sensor_type = _sensor_type;
        }
    }

    public class DirectionalID
    {
        public long ID;
        public bool Dir;

        /// <summary>
        /// constructor
        /// </summary>
        public DirectionalID()
        {
            ID = 0;
            Dir = true;
        }

        /// <summary>
        /// Overloading constructor
        /// </summary>
        /// <param name="_ID">ID</param>
        /// <param name="_Dir">Direction</param>
        public DirectionalID(long _ID, bool _Dir)
        {
            ID = _ID;
            Dir = _Dir;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is DirectionalID))
                return false;
            DirectionalID other = (DirectionalID)obj;
            return other.ID == ID && other.Dir == Dir;
        }

        public bool Equals(DirectionalID id)
        {
            return id.ID == ID && id.Dir == Dir;
        }

        public override int GetHashCode()
        {
            return (int)(ID + ((Dir) ? 1 : 0));
        }
    }

    public class CRoute
    {
        public int[] PathAry; //array contains a list of nodes in index
        public int[] LinkSeq; //array contains a list of links in index
        public int[] TrafficColor;
        public double PathTime, PathDist, PathSafety, PathCost;

        /// <summary>
        /// constructor
        /// </summary>
        public CRoute()
        {
            PathAry = null;
            LinkSeq = null;
            TrafficColor = null;
            PathTime = 0;
            PathDist = 0;
            PathSafety = 1;
            PathCost = 0;
        }

        /// <summary>
        /// Overloading constructor
        /// </summary>
        /// <param name="_PathAry">array contains a list of nodes in index</param>
        /// <param name="_LinkSeq">array contains a list of links in index</param>
        /// <param name="_TrafficColor">array contains a list of traffic color code</param>
        /// <param name="_PathTime">travel time in minute</param>
        /// <param name="_PathDist">distance in mile</param>
        /// <param name="_PathSafety">safety factor in percentage</param>
        /// <param name="_PathCost">cost in dollar</param>
        public CRoute(int[] _PathAry, int[] _LinkSeq, int[] _TrafficColor, double _PathTime, double _PathDist, double _PathSafety, double _PathCost)
        {
            PathAry = _PathAry;
            LinkSeq = _LinkSeq;
            TrafficColor = _TrafficColor;
            PathTime = _PathTime;
            PathDist = _PathDist;
            PathSafety = _PathSafety;
            PathCost = _PathCost;
        }

        //TODO: override function equals
    }

    public class CBound
    {
        public double up, low, left, right;
        public CBound()
        {
            up = 0;
            low = 0;
            left = 0;
            right = 0;
        }
        public CBound(double _up, double _low, double _left, double _right)
        {
            up = _up;
            low = _low;
            left = _left;
            right = _right;
        }
    }

    //Shape class
    public class CShape
    {
        public int Shape_ID, Shape_Length;
        public double[] Shape_Long, Shape_Lat;

        //constructor
        public CShape()
        {
            Shape_ID = 0;
            Shape_Length = 0;
            Shape_Lat = null;
            Shape_Long = null;
        }

        //overloading constructor
        public CShape(int _Shape_ID, int _Shape_Length, double[] _Shape_Lat, double[] _Shape_Long)
        {
            Shape_ID = _Shape_ID;
            Shape_Length = _Shape_Length;
            Shape_Lat = _Shape_Lat;
            Shape_Long = _Shape_Long;
        }

    }

    //TODO: add CRoutingRequest class
    //TODO: add Traffic class

    public class CgpsTrace
    {
        public string MetaUserId;
        public int MetaTraceId;
        public DateTime MetaInsertDate;
        public double Lat, Long, Speed, Heading, RelativeTime, SeaLevelAlt;
        public double east, north;
        public int utm_zone, NumOfSat;
        public string GpsTime;

        public CgpsTrace()
        {
            MetaUserId = "";
            MetaTraceId = 0;
            MetaInsertDate = new DateTime();
            Lat = 0;
            Long = 0;
            east = 0;
            north = 0;
            utm_zone = 0;
            Speed = 0;
            Heading = 0;
            RelativeTime = 0;
            SeaLevelAlt = 0;
            NumOfSat = 0;
            GpsTime = "";
        }

        public CgpsTrace(string _MetaUserId, int _MetaTraceId, DateTime _MetaInsertDate, double _lat, double _long, double _Speed, double _Heading,
                            double _RelativeTime, double _SeaLevelAlt, int _NumOfSat, string _GpsTime)
        {
            MetaUserId = _MetaUserId;
            MetaTraceId = _MetaTraceId;
            MetaInsertDate = _MetaInsertDate;
            Lat = _lat;
            Long = _long;
            east = LatLongValue.LatLongToUTM(_lat, _long).utmEx;
            north = LatLongValue.LatLongToUTM(_lat, _long).utmNy;
            utm_zone = LatLongValue.LatLongToUTM(_lat, _long).zone;
            Speed = _Speed;
            Heading = _Heading;
            RelativeTime = _RelativeTime;
            SeaLevelAlt = _SeaLevelAlt;
            NumOfSat = _NumOfSat;
            GpsTime = _GpsTime;
        }

        public CgpsTrace(CgpsTrace gt)
        {
            MetaUserId = gt.MetaUserId;
            MetaTraceId = gt.MetaTraceId;
            MetaInsertDate = gt.MetaInsertDate;
            Lat = gt.Lat;
            Long = gt.Long;
            east = gt.east;
            north = gt.north;
            utm_zone = gt.utm_zone;
            Speed = gt.Speed;
            Heading = gt.Heading;
            RelativeTime = gt.RelativeTime;
            SeaLevelAlt = gt.SeaLevelAlt;
            NumOfSat = gt.NumOfSat;
            GpsTime = gt.GpsTime;
        }
    }

    public class Gaussian
    {
        private Random r;
        private bool use_last_result = false; // flag for NextGaussian3()
        private double y2 = 0.0;  // secondary result for NextGaussian3()

        public Gaussian()
        {
            r = new Random();
        }

        public Gaussian(int seed)
        {
            r = new Random(seed);
        }

        public double NextGaussian3(double mean, double sd) // most efficient
        {
            double x1, x2, w, y1 = 0.0;

            if (use_last_result) // use answer from previous call?
            {
                y1 = y2;
                use_last_result = false;
            }
            else
            {
                do
                {
                    x1 = 2.0 * r.NextDouble() - 1.0;
                    x2 = 2.0 * r.NextDouble() - 1.0;
                    w = (x1 * x1) + (x2 * x2);
                }
                while (w >= 1.0); // are x1 and x2 inside unit circle?

                w = Math.Sqrt((-2.0 * Math.Log(w)) / w);
                y1 = x1 * w;
                y2 = x2 * w;
                use_last_result = true;
            }

            return mean + y1 * sd;
        }
    }


    public partial class CNetwork
    {
        //public static int m_NodeSize = 500, m_LinkSize = 500;
        public int m_TimeInterval = 5, m_TimeIntervalSize = 288;//take 5min as a time interval, from 0 to 1440, total 288 intervals
        public double m_WalkingSpeed = 2.0; // 2mph
        public int m_TimeIntervalTransit = 1, m_TimeIntervalTransitSize = 1440; // public int TimeIntervalAllDay = 1, TimeIntervalAllDaySize = 1440;
        public static int m_MAX_KSP_SIZE = 9;
        public int m_NodeSize, m_LinkSize, m_TransitSize, m_SensorSize;
        public CNode[] aryCNode;
        public CLink[] aryCLink;
        public CShape[] aryCShape;
        public int[,] LinkList;
        public double[] LinkCost;
        public double[] LinkCost_min;
        public double[] LinkCost_max;
        public double[] LinkCost_Penalty;
        public double[] LinkCost_Fuel; // fuel cost in dollar
        public double Fuel_Rate = 0.15; // 0.15 dollar per mile
        public double Transit_Cost = 2.0; // 2 dollar for transit
        public double[][] LinkCost_DayD;
        public double[,] LinkCost_TimeD;
        public double[,] LinkCost_TimeD_Penalty;
        public double[,] LinkCost_TimeD_Transit;
        public Dictionary<int, int> m_NodeIDtoIndex;
        public Dictionary<DirectionalID, int> m_LinkIDtoIndex;
        public Dictionary<int, long> ShapeIDtoIndex;
        public Dictionary<string, int[]> TMCIDtoLink;
        public Dictionary<string, int> TMCwithRealData;
        public string[] TMCIndextoID;
        public Dictionary<int, int> m_SensorIDtoIndex;
        public int[] m_NodeIndextoID;
        public double up, low, left, right;//boundary
        public string city = "";
        public int Global_origin = 0, Global_destination = 0;

        public double[,] TMCHistSpd; // historical speed data for every TMC ID

        //constructor
        public CNetwork()
        {
            m_NodeSize = 0;// m_NodeSize;
            m_LinkSize = 0;// m_LinkSize;
            //CNode[] aryCNode; //aryCNode = new CNode[m_NodeSize];
            //CLink[] aryCLink; //aryCLink = new CLink[m_LinkSize];
        }

        public int[,] InboundLinkAry;
        public int[] InboundLinkSize;
        public int[,] OutgoingLinkAry;
        public int[] OutgoingLinkSize;



        public bool Analysis_Network(string city)
        {
            //generate InboundLinkAry and InboundLinkSize
            int MaxInboundLink = 15;
            InboundLinkAry = new int[m_NodeSize, MaxInboundLink];
            InboundLinkSize = new int[m_NodeSize];
            //generate OutgoingLinkAry and OutgoingLinkSize
            int MaxOutgoingLink = 15;
            OutgoingLinkAry = new int[m_NodeSize, MaxOutgoingLink];
            OutgoingLinkSize = new int[m_NodeSize];
            int l, node_index;
            //first generate link list based on node index
            LinkList = new int[m_LinkSize, 2];// To node, from node
            LinkCost = new double[m_LinkSize];// cost
            LinkCost_Fuel = new double[m_LinkSize]; // fuel cost in dollar
            LinkCost_TimeD = new double[m_LinkSize, m_TimeIntervalSize];
            LinkCost_Penalty = new double[m_LinkSize];//cost with penalty
            LinkCost_TimeD_Penalty = new double[m_LinkSize, m_TimeIntervalSize];
            TMCIDtoLink = new Dictionary<string, int[]>();
            for (l = 0; l < m_LinkSize; l++)
            {
                // link cost table
                LinkCost[l] = aryCLink[l].TravelTime;
                for (int i = 0; i < m_TimeIntervalSize; i++)
                {
                    LinkCost_TimeD[l, i] = aryCLink[l].TravelTime; //take FFTT as the initial values for all time intervals in LinkCost_TimeD
                    LinkCost_TimeD_Penalty[l, i] = aryCLink[l].TravelTime;
                }
                LinkCost_Penalty[l] = aryCLink[l].TravelTime;
                LinkList[l, 0] = m_NodeIDtoIndex[aryCLink[l].ToID];
                LinkList[l, 1] = m_NodeIDtoIndex[aryCLink[l].FromID];
                if (aryCLink[l].Link_Type < 9)
                    LinkCost_Fuel[l] = aryCLink[l].Link_Length * Fuel_Rate;

                //second generate inbound link array by scanning LinkList, ***based on link index***
                node_index = LinkList[l, 0];
                InboundLinkAry[node_index, InboundLinkSize[node_index]] = l;
                InboundLinkSize[node_index]++;

                //generate outgoing link array by scanning LinkList, ***based on link index***
                node_index = LinkList[l, 1];
                OutgoingLinkAry[node_index, OutgoingLinkSize[node_index]] = l;
                OutgoingLinkSize[node_index]++;

                // generate TMC_code-to-link_index table
                if (aryCLink[l].TMC != null)
                {
                    if (TMCIDtoLink.ContainsKey(aryCLink[l].TMC))
                    {
                        TMCIDtoLink[aryCLink[l].TMC][0]++;
                        TMCIDtoLink[aryCLink[l].TMC][TMCIDtoLink[aryCLink[l].TMC][0]] = l;
                    }
                    else
                    {
                        TMCIDtoLink.Add(aryCLink[l].TMC, new int[70]);
                        TMCIDtoLink[aryCLink[l].TMC][0]++;
                        TMCIDtoLink[aryCLink[l].TMC][TMCIDtoLink[aryCLink[l].TMC][0]] = l;
                    }
                }
            }
            //// load New York Toll information /////////////////////////////
            //if (city == "NY")
            //{
            //    long[] toll500 = { 21638802, 119955172, 119955177, 31118198, 733067099, 21564515, 21564516, 21564517, 21564518, 119953399, 119953388 };
            //    long[] toll250 = { 21552614, 21552615, 31118346, 31118348, 744672547, 744672549, 21607636, 216076360, 21470277, 214702770 };
            //    long[] toll275 = { 24890284 };
            //    for (int i = 0; i < toll250.Length; i++)
            //        LinkCost_Fuel[m_LinkIDtoIndex[toll250[i]]] += 2.5;
            //    for (int i = 0; i < toll500.Length; i++)
            //        LinkCost_Fuel[m_LinkIDtoIndex[toll500[i]]] += 5.0;
            //    for (int i = 0; i < toll275.Length; i++)
            //        LinkCost_Fuel[m_LinkIDtoIndex[toll275[i]]] += 2.75;
            //}
            /////////////////////////////////////////////////////////////////

            int k = 0;
            //find out isolated nodes
            for (l = 0; l < m_NodeSize; l++)
            {
                if (InboundLinkSize[l] == 0 && OutgoingLinkSize[l] == 0)
                    k++;
            }

            //find out the boundary of network               
            up = aryCNode[0].Node_Lat;
            low = aryCNode[0].Node_Lat;
            left = aryCNode[0].Node_Long;
            right = aryCNode[0].Node_Long;
            double[,] NodeCoordinate = new double[m_NodeSize, 2];
            for (int n = 0; n < m_NodeSize; n++)
            {
                NodeCoordinate[n, 0] = aryCNode[n].Node_Long;
                NodeCoordinate[n, 1] = aryCNode[n].Node_Lat;
                if (NodeCoordinate[n, 0] < left)
                    left = NodeCoordinate[n, 0];
                if (NodeCoordinate[n, 0] > right)
                    right = NodeCoordinate[n, 0];
                if (NodeCoordinate[n, 1] < low)
                    low = NodeCoordinate[n, 1];
                if (NodeCoordinate[n, 1] > up)
                    up = NodeCoordinate[n, 1];
            }

            return true;

        }


        public int[] SEList;
        public int SEList_front, SEList_end;

        public bool ShortestPath_Destination(int destination_index, out int[] PredAry)
        {
            SEList = new int[m_LinkSize];
            int n;
            // test destination index
            if (destination_index >= m_NodeSize)
            {
                PredAry = null;
                return false;
            }
            //
            double[] LabelAry = new double[m_NodeSize];
            double INFINITE = 999999;
            int[] NodeUpdateStatus = new int[m_NodeSize];//0 not updated; 1 updated
            int[] LinkUpdateStatus = new int[m_LinkSize];//0 not in SEList; 1 in SEList
            PredAry = new int[m_NodeSize];
            for (n = 0; n < m_NodeSize; n++)
            {
                LabelAry[n] = INFINITE;
                //NodeUpdateStatus[n] = 0;
                PredAry[n] = -1;
            }

            int node_index, link_index, curr_SEList_front;
            bool curr_Update = false;
            SEList_clear();
            //first push back
            for (n = 0; n < InboundLinkSize[destination_index]; n++)
            {
                link_index = InboundLinkAry[destination_index, n];//inbound link
                NodeUpdateStatus[LinkList[link_index, 1]] = 0;//
                SEList_push_back(link_index);
                LinkUpdateStatus[link_index] = 1;
            }
            LabelAry[destination_index] = 0;
            bool negative_flag = false, loop_flag = false;
            int count = 0;

            while (SEList_front != -1)
            {
                curr_SEList_front = SEList_front;
                node_index = LinkList[SEList_front, 1];
                curr_Update = false;
                loop_flag = false;
                //update label
                if (LinkCost_Penalty[SEList_front] < 0) // detect if negative link cost exists
                {
                    negative_flag = true;
                    //PredAry = null;
                    //return false;
                }
                if (negative_flag)   // prevent loop
                {
                    // detect if current node is on the path from potential Pred node to destination 
                    int nd = LinkList[SEList_front, 0];
                    while (PredAry[nd] != -1)
                    {
                        nd = PredAry[nd];
                        if (nd == node_index)
                        {
                            loop_flag = true;
                            break;
                        }
                    }
                }
                if (LinkCost_Penalty[SEList_front] + LabelAry[LinkList[SEList_front, 0]] < LabelAry[node_index] && !loop_flag)
                {
                    LabelAry[node_index] = LinkCost_Penalty[SEList_front] + LabelAry[LinkList[SEList_front, 0]];
                    PredAry[node_index] = LinkList[SEList_front, 0];
                    curr_Update = true;
                }
                //pop front
                SEList_pop_front();
                LinkUpdateStatus[curr_SEList_front] = 0;
                NodeUpdateStatus[node_index] = 1;
                //push in inbound links of SEList_front to SEList
                if (curr_Update)
                {
                    for (n = 0; n < InboundLinkSize[node_index]; n++)
                    {
                        link_index = InboundLinkAry[node_index, n];//inbound link
                        //if (LinkList[link_index, 1] != LinkList[curr_SEList_front, 0])//do not include the opposite link in direction
                        //{                            
                        if (NodeUpdateStatus[LinkList[link_index, 1]] == 0)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_back(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }
                        if (NodeUpdateStatus[LinkList[link_index, 1]] == 1)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_front(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }
                        //}
                    }
                }
                //count++;
                //if (count > m_LinkSize * 100)
                //    return false;
            }
            return true;

        }

        /// <summary>
        /// origin based shortest path calculation
        /// </summary>
        /// <param name="origin">origin node ID</param>
        /// <param name="Ref_initial">manually set up an initial value for node label</param>
        /// <param name="PredAry">output: predecessor array</param>
        /// <returns>boolean value indicates if the calculation returns a valid value</returns>
        public bool ShortestPath_Origin(int origin_index, double Ref_initial, out int[] PredAry)
        {
            SEList = new int[m_LinkSize];
            int n;
            //test origin index
            if (origin_index >= m_NodeSize)
            {
                PredAry = null;
                return false;
            }
            //
            double[] LabelAry = new double[m_NodeSize];
            double INFINITE = 999999;
            int[] NodeUpdateStatus = new int[m_NodeSize];//0 not updated; 1 updated
            int[] LinkUpdateStatus = new int[m_LinkSize];//0 not in SEList; 1 in SEList
            PredAry = new int[m_NodeSize];
            for (n = 0; n < m_NodeSize; n++)
            {
                LabelAry[n] = Ref_initial;
                //NodeUpdateStatus[n] = 0;
                PredAry[n] = -1;
            }

            int node_index, link_index, curr_SEList_front;
            bool curr_Update = false;
            SEList_clear();
            //first push back
            for (n = 0; n < OutgoingLinkSize[origin_index]; n++)
            {
                link_index = OutgoingLinkAry[origin_index, n];//outgoing link
                NodeUpdateStatus[LinkList[link_index, 0]] = 0;//
                SEList_push_back(link_index);
                LinkUpdateStatus[link_index] = 1;
            }
            LabelAry[origin_index] = 0;


            while (SEList_front != -1)
            {
                curr_SEList_front = SEList_front;
                node_index = LinkList[SEList_front, 0];
                curr_Update = false;
                //update label
                if (LinkCost_Penalty[SEList_front] < 0)
                {
                    PredAry = null;
                    return false;
                }
                if (LinkCost_Penalty[SEList_front] + LabelAry[LinkList[SEList_front, 1]] < LabelAry[node_index])
                {
                    LabelAry[node_index] = LinkCost_Penalty[SEList_front] + LabelAry[LinkList[SEList_front, 1]];
                    PredAry[node_index] = LinkList[SEList_front, 1];
                    curr_Update = true;
                }
                //pop front
                SEList_pop_front();
                LinkUpdateStatus[curr_SEList_front] = 0;
                NodeUpdateStatus[node_index] = 1;
                //push in outgoing links of SEList_front to SEList
                if (curr_Update)
                {
                    for (n = 0; n < OutgoingLinkSize[node_index]; n++)
                    {
                        link_index = OutgoingLinkAry[node_index, n];//outgoing link
                        //if (LinkList[link_index, 1] != LinkList[curr_SEList_front, 0])//do not include the opposite link in direction
                        //{                            
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 0)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_back(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 1)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_front(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }

                        //}
                    }
                }
            }
            return true;
        }

        public bool ShortestPath_TimeD(int origin, int destination, int DepartureTimeInterval, double VoT, out CRoute route)
        {
            SEList = new int[m_LinkSize];
            int n;
            //mapping origin and destination from ID to index
            int origin_index = 0;
            int destination_index = 0;
            if (!m_NodeIDtoIndex.TryGetValue(origin, out origin_index) || !m_NodeIDtoIndex.TryGetValue(destination, out destination_index))
            {
                route = null;
                return false;
            }
            //test departure time
            if (DepartureTimeInterval < 0 || DepartureTimeInterval >= m_TimeIntervalSize)
            {
                route = null;
                return false;
            }

            //time-dependent SP
            double[,] LabelAry = new double[m_NodeSize, 2]; //Label: arrival time + cost
            double INFINITE = 999999;
            int curr_time_interval;
            double curr_time;
            int[] NodeUpdateStatus = new int[m_NodeSize];//0 not updated; 1 updated
            int[] LinkUpdateStatus = new int[m_LinkSize];//0 not in SEList; 1 in SEList
            int[] PredAry = new int[m_NodeSize];
            for (n = 0; n < m_NodeSize; n++)
            {
                LabelAry[n, 1] = INFINITE; //initial infinite cost
                LabelAry[n, 0] = INFINITE;
                PredAry[n] = -1;
            }

            int To_node_index, From_node_index, link_index, curr_SEList_front;
            bool curr_Update = false;
            SEList_clear();
            //first push back
            for (n = 0; n < OutgoingLinkSize[origin_index]; n++)
            {
                link_index = OutgoingLinkAry[origin_index, n];//outgoing link
                NodeUpdateStatus[LinkList[link_index, 0]] = 0;//
                SEList_push_back(link_index);
                LinkUpdateStatus[link_index] = 1;
            }
            LabelAry[origin_index, 0] = DepartureTimeInterval * m_TimeInterval;
            LabelAry[origin_index, 1] = 0;
            //double err;

            while (SEList_front != -1) //Label: arrival time based
            {
                curr_SEList_front = SEList_front;
                To_node_index = LinkList[SEList_front, 0];
                From_node_index = LinkList[SEList_front, 1];
                curr_Update = false;
                curr_time = LabelAry[From_node_index, 0];
                curr_time_interval = ((int)(Math.Floor(curr_time / m_TimeInterval))) % m_TimeIntervalSize;
                //update label
                if (LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] < 0)
                {
                    route = null;
                    return false;
                }
                if (LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] + LabelAry[From_node_index, 1] < LabelAry[To_node_index, 1])
                {
                    LabelAry[To_node_index, 1] = LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] + LabelAry[From_node_index, 1];
                    LabelAry[To_node_index, 0] = LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] + curr_time;
                    PredAry[To_node_index] = From_node_index;
                    curr_Update = true;
                }
                //pop front
                SEList_pop_front();
                LinkUpdateStatus[curr_SEList_front] = 0;
                NodeUpdateStatus[To_node_index] = 1;
                //push in outgoing links of SEList_front to SEList
                if (curr_Update)
                {
                    for (n = 0; n < OutgoingLinkSize[To_node_index]; n++)
                    {
                        link_index = OutgoingLinkAry[To_node_index, n];//outgoing link
                        //if (LinkList[link_index, 1] != LinkList[curr_SEList_front, 0])//do not include the opposite link in direction
                        //{                            
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 0)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_back(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 1)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_front(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }

                        //}
                    }
                }
            }

            if (!GetRoute(false, origin_index, destination_index, PredAry, VoT, true, DepartureTimeInterval, out route))
            {
                route = null;
                return false;
            }

            return true;
        }




        private void SEList_clear()
        {
            SEList_front = -1;
            SEList_end = -1;
        }

        private void SEList_push_back(int link)
        {
            if (SEList_front == -1)
            {
                SEList[link] = -1;
                SEList_front = link;
                SEList_end = link;
            }
            else
            {
                SEList[link] = -1;
                SEList[SEList_end] = link;
                SEList_end = link;
            }
        }

        private void SEList_push_front(int link)
        {
            if (SEList_front == -1)
            {
                SEList[link] = -1;
                SEList_front = link;
                SEList_end = link;
            }
            else
            {
                SEList[link] = SEList_front;
                SEList_front = link;
            }
        }

        private void SEList_pop_front()
        {
            int temp_front = SEList_front;
            SEList_front = SEList[temp_front];
            SEList[temp_front] = -1;
            if (SEList_front == -1)
                SEList_end = -1;
        }


        public int K_ShortestPath_Unsorted(int originID, int destinationID, double VoT, int RequestK, out CRoute[] K_routes)//return PathAry and number of K
        {
            //clean LinkCost_penalty
            for (int l = 0; l < m_LinkSize; l++)
            {
                LinkCost_Penalty[l] = LinkCost[l];
            }

            int origin_index = m_NodeIDtoIndex[originID], destination_index = m_NodeIDtoIndex[destinationID];
            int node_index = origin_index;

            int PA = 0, PB = 8, PC = 4, PD = 2, PE = 6, PF = 1, PG = 3, PH = 5, PI = 7;
            K_routes = new CRoute[m_MAX_KSP_SIZE];
            int[][] PredAry = new int[m_MAX_KSP_SIZE][];
            int[] PathAry = new int[m_NodeSize];
            double[] OverlappingFactor = new double[m_MAX_KSP_SIZE];
            bool SP_Cal_Direction = true, real = false;
            OverlappingFactor[PA] = 1;
            int k = 0;
            //A path: shortest path/////////////////////////////////////
            ShortestPath_Destination(destination_index, out PredAry[PA]);
            if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PA], VoT, real, 0, out K_routes[PA]))
                return k;
            k++;
            if (RequestK == k)
                return k;

            //B path: non-overlapping path////////////////////////////
            double VOO = 1000000;
            UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
            ShortestPath_Destination(destination_index, out PredAry[PB]);
            if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PB], VoT, real, 0, out K_routes[PB]))
                return k;

            //find out overlapping factor
            OverlappingFactor[PB] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PB].LinkSeq);
            if (OverlappingFactor[PB] > 0.95)
            {
                K_routes[PB] = null;
                return k;
            }
            k++;
            if (RequestK == k)
                return k;

            //C path: between A and B///////////////////////////////////////////
            VOO = (K_routes[PB].PathTime - K_routes[PA].PathTime) / (OverlappingFactor[PA] - OverlappingFactor[PB]);
            UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);

            ShortestPath_Destination(destination_index, out PredAry[PC]);
            if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PC], VoT, real, 0, out K_routes[PC]))
                return k;

            OverlappingFactor[PC] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PC].LinkSeq);
            //find out if path C is same with path A or B
            if (OverlappingFactor[PC] > 0.95
                || GetOverlappingFactor(K_routes[PB].LinkSeq, K_routes[PB].PathTime, K_routes[PC].LinkSeq) > 0.95)
            {
                K_routes[PC] = null;
                return k;
            }
            k++;
            if (RequestK == k)
                return k;

            //D path: between A and C///////////////////////////////////////////
            VOO = (K_routes[PC].PathTime - K_routes[PA].PathTime) / (OverlappingFactor[PA] - OverlappingFactor[PC]);
            UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);

            ShortestPath_Destination(destination_index, out PredAry[PD]);
            if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PD], VoT, real, 0, out K_routes[PD]))
                return k;

            OverlappingFactor[PD] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PD].LinkSeq);
            k++; //without D, E is still posible
            //find out if path D is same with path A or C
            if (OverlappingFactor[PD] > 0.95
                || GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PD].LinkSeq) > 0.95)
            {
                K_routes[PD] = null;
                OverlappingFactor[PD] = -1;
                k--;
            }
            if (RequestK == k)
                return k;

            //E path: between C and B///////////////////////////////////////////
            VOO = (K_routes[PB].PathTime - K_routes[PC].PathTime) / (OverlappingFactor[PC] - OverlappingFactor[PB]);
            UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);

            ShortestPath_Destination(destination_index, out PredAry[PE]);
            if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PE], VoT, real, 0, out K_routes[PE]))
                return k;

            OverlappingFactor[PE] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PE].LinkSeq);
            k++;
            //find out if path E is same with path C or B
            if (GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PE].LinkSeq) > 0.95
                || GetOverlappingFactor(K_routes[PB].LinkSeq, K_routes[PB].PathTime, K_routes[PE].LinkSeq) > 0.95)
            {
                K_routes[PE] = null;
                OverlappingFactor[PE] = -1;
                k--;
            }
            if (RequestK == k)
                return k;

            //F and G path///////////////////////////////////////////////////////////////////////////////////////////           
            if (K_routes[PD] != null)
            {
                //F path: between A and D///////////////////////////////////////////
                VOO = (K_routes[PD].PathTime - K_routes[PA].PathTime) / (OverlappingFactor[PA] - OverlappingFactor[PD]);
                UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                ShortestPath_Destination(destination_index, out PredAry[PF]);
                if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PF], VoT, real, 0, out K_routes[PF]))
                    return k;
                OverlappingFactor[PF] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PF].LinkSeq);
                k++;
                if (OverlappingFactor[PF] > 0.95
                    || GetOverlappingFactor(K_routes[PD].LinkSeq, K_routes[PD].PathTime, K_routes[PF].LinkSeq) > 0.95)
                {
                    K_routes[PF] = null;
                    OverlappingFactor[PF] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;

                //G path: between D and C///////////////////////////////////////////
                VOO = (K_routes[PC].PathTime - K_routes[PD].PathTime) / (OverlappingFactor[PD] - OverlappingFactor[PC]);
                UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                ShortestPath_Destination(destination_index, out PredAry[PG]);
                if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PG], VoT, real, 0, out K_routes[PG]))
                    return k;
                OverlappingFactor[PG] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PG].LinkSeq);
                k++;
                if (GetOverlappingFactor(K_routes[PD].LinkSeq, K_routes[PD].PathTime, K_routes[PG].LinkSeq) > 0.95
                    || GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PG].LinkSeq) > 0.95)
                {
                    K_routes[PG] = null;
                    OverlappingFactor[PG] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;
            }


            //H and I path///////////////////////////////////////////////////////////////////////////////////////////           
            if (K_routes[PE] != null)
            {
                //H path: between C and E///////////////////////////////////////////
                VOO = (K_routes[PE].PathTime - K_routes[PC].PathTime) / (OverlappingFactor[PC] - OverlappingFactor[PE]);
                UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                ShortestPath_Destination(destination_index, out PredAry[PH]);
                if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PH], VoT, real, 0, out K_routes[PH]))
                    return k;
                OverlappingFactor[PH] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PH].LinkSeq);
                k++;
                if (GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PH].LinkSeq) > 0.95
                    || GetOverlappingFactor(K_routes[PE].LinkSeq, K_routes[PE].PathTime, K_routes[PH].LinkSeq) > 0.95)
                {
                    K_routes[PH] = null;
                    OverlappingFactor[PH] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;

                //I path: between E and B///////////////////////////////////////////
                VOO = (K_routes[PB].PathTime - K_routes[PE].PathTime) / (OverlappingFactor[PE] - OverlappingFactor[PB]);
                UpdateLinkCost_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                ShortestPath_Destination(destination_index, out PredAry[PI]);
                if (!GetRoute(SP_Cal_Direction, origin_index, destination_index, PredAry[PI], VoT, real, 0, out K_routes[PI]))
                    return k;
                OverlappingFactor[PI] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PI].LinkSeq);
                k++;
                if (GetOverlappingFactor(K_routes[PE].LinkSeq, K_routes[PE].PathTime, K_routes[PI].LinkSeq) > 0.95
                    || GetOverlappingFactor(K_routes[PB].LinkSeq, K_routes[PB].PathTime, K_routes[PI].LinkSeq) > 0.95)
                {
                    K_routes[PI] = null;
                    OverlappingFactor[PI] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;
            }

            return k;

        }


        public int K_ShortestPath_TimeD_Unsorted(int origin, int destination, int DepartureTimeInterval, double VoT, int RequestK, out CRoute[] K_routes)//return PathAry and number of K
        {
            //clean LinkCost_TimeD_penalty
            for (int i = 0; i < m_LinkSize; i++)
                for (int j = 0; j < m_TimeIntervalSize; j++)
                    LinkCost_TimeD_Penalty[i, j] = LinkCost_TimeD[i, j];


            int PA = 0, PB = 8, PC = 4, PD = 2, PE = 6, PF = 1, PG = 3, PH = 5, PI = 7;
            K_routes = new CRoute[m_MAX_KSP_SIZE];
            double[] OverlappingFactor = new double[m_MAX_KSP_SIZE];
            OverlappingFactor[PA] = 1;
            int k = 0;
            //A path: shortest path/////////////////////////////////////            
            if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PA]))
                return k;
            k++;
            if (RequestK == k)
                return k;

            //B path: non-overlapping path////////////////////////////
            double VOO = 1000000;
            UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
            if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PB]))
                return k;
            //find out overlapping factor
            OverlappingFactor[PB] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PB].LinkSeq);
            if (OverlappingFactor[PB] > 0.95)
            {
                K_routes[PB] = null;
                return k;
            }
            k++;
            if (RequestK == k)
                return k;

            //C path: between A and B///////////////////////////////////////////
            VOO = (K_routes[PB].PathTime - K_routes[PA].PathTime) / (OverlappingFactor[PA] - OverlappingFactor[PB]);
            UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
            if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PC]))
                return k;
            OverlappingFactor[PC] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PC].LinkSeq);
            //find out if path C is same with path A or B
            if (OverlappingFactor[PC] > 0.95
                || GetOverlappingFactor(K_routes[PB].LinkSeq, K_routes[PB].PathTime, K_routes[PC].LinkSeq) > 0.95)
            {
                K_routes[PC] = null;
                return k;
            }
            k++;
            if (RequestK == k)
                return k;

            //D path: between A and C///////////////////////////////////////////
            VOO = (K_routes[PC].PathTime - K_routes[PA].PathTime) / (OverlappingFactor[PA] - OverlappingFactor[PC]);
            UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
            if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PD]))
                return k;
            OverlappingFactor[PD] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PD].LinkSeq);
            k++; //without D, E is still posible
            //find out if path D is same with path A or C
            if (OverlappingFactor[PD] > 0.95
                || GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PD].LinkSeq) > 0.95)
            {
                K_routes[PD] = null;
                OverlappingFactor[PD] = -1;
                k--;
            }
            if (RequestK == k)
                return k;

            //E path: between C and B///////////////////////////////////////////
            VOO = (K_routes[PB].PathTime - K_routes[PC].PathTime) / (OverlappingFactor[PC] - OverlappingFactor[PB]);
            UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
            if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PE]))
                return k;
            OverlappingFactor[PE] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PE].LinkSeq);
            k++;
            //find out if path E is same with path C or B
            if (GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PE].LinkSeq) > 0.95
                || GetOverlappingFactor(K_routes[PB].LinkSeq, K_routes[PB].PathTime, K_routes[PE].LinkSeq) > 0.95)
            {
                K_routes[PE] = null;
                OverlappingFactor[PE] = -1;
                k--;
            }
            if (RequestK == k)
                return k;

            //F and G path///////////////////////////////////////////////////////////////////////////////////////////           
            if (K_routes[PD] != null)
            {
                //F path: between A and D///////////////////////////////////////////
                VOO = (K_routes[PD].PathTime - K_routes[PA].PathTime) / (OverlappingFactor[PA] - OverlappingFactor[PD]);
                UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PF]))
                    return k;
                OverlappingFactor[PF] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PF].LinkSeq);
                k++;
                if (OverlappingFactor[PF] > 0.95
                    || GetOverlappingFactor(K_routes[PD].LinkSeq, K_routes[PD].PathTime, K_routes[PF].LinkSeq) > 0.95)
                {
                    K_routes[PF] = null;
                    OverlappingFactor[PF] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;

                //G path: between D and C///////////////////////////////////////////
                VOO = (K_routes[PC].PathTime - K_routes[PD].PathTime) / (OverlappingFactor[PD] - OverlappingFactor[PC]);
                UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PG]))
                    return k;
                OverlappingFactor[PG] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PG].LinkSeq);
                k++;
                if (GetOverlappingFactor(K_routes[PD].LinkSeq, K_routes[PD].PathTime, K_routes[PG].LinkSeq) > 0.95
                    || GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PG].LinkSeq) > 0.95)
                {
                    K_routes[PG] = null;
                    OverlappingFactor[PG] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;
            }

            //H and I path///////////////////////////////////////////////////////////////////////////////////////////           
            if (K_routes[PE] != null)
            {
                //H path: between C and E///////////////////////////////////////////
                VOO = (K_routes[PE].PathTime - K_routes[PC].PathTime) / (OverlappingFactor[PC] - OverlappingFactor[PE]);
                UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PH]))
                    return k;
                OverlappingFactor[PH] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PH].LinkSeq);
                k++;
                if (GetOverlappingFactor(K_routes[PC].LinkSeq, K_routes[PC].PathTime, K_routes[PH].LinkSeq) > 0.95
                    || GetOverlappingFactor(K_routes[PE].LinkSeq, K_routes[PE].PathTime, K_routes[PH].LinkSeq) > 0.95)
                {
                    K_routes[PH] = null;
                    OverlappingFactor[PH] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;

                //I path: between E and B///////////////////////////////////////////
                VOO = (K_routes[PB].PathTime - K_routes[PE].PathTime) / (OverlappingFactor[PE] - OverlappingFactor[PB]);
                UpdateLinkCost_TimeD_Penalty(K_routes[PA].LinkSeq, VOO, K_routes[PA].PathTime);
                if (!ShortestPath_TimeD(origin, destination, DepartureTimeInterval, VoT, out K_routes[PI]))
                    return k;
                OverlappingFactor[PI] = GetOverlappingFactor(K_routes[PA].LinkSeq, K_routes[PA].PathTime, K_routes[PI].LinkSeq);
                k++;
                if (GetOverlappingFactor(K_routes[PE].LinkSeq, K_routes[PE].PathTime, K_routes[PI].LinkSeq) > 0.95
                    || GetOverlappingFactor(K_routes[PB].LinkSeq, K_routes[PB].PathTime, K_routes[PI].LinkSeq) > 0.95)
                {
                    K_routes[PI] = null;
                    OverlappingFactor[PI] = -1;
                    k--;
                }
                if (RequestK == k)
                    return k;
            }

            return k;

        }

        /// <summary>
        /// Sort a list of numbers in order, 
        /// return a integer list containing the original index of numbers, in a sorted order
        /// </summary>
        /// <param name="_ary">input: a list of number in double</param>
        /// <param name="direction">sorting direction: true - decreasing, false - increasing</param>
        /// <returns>the original index of numbers, in a sorted order</returns>
        public int[] SortingFunction(double[] _ary, bool direction)
        {
            //sorting: true - decreasing, false - increasing
            double[] ary = new double[_ary.Length];
            _ary.CopyTo(ary, 0);
            double temp_double;
            int temp_int;
            int[] sort_index = new int[ary.Length];
            for (int k = 0; k < ary.Length; k++)
            {
                sort_index[k] = k;
            }
            //true - decreasing
            if (direction == true)
            {
                for (int i = 0; i < ary.Length; i++)
                {
                    for (int j = i + 1; j < ary.Length; j++)
                    {
                        if (ary[i] < ary[j])
                        {
                            temp_double = ary[i];
                            temp_int = sort_index[i];
                            ary[i] = ary[j];
                            sort_index[i] = sort_index[j];
                            ary[j] = temp_double;
                            sort_index[j] = temp_int;
                        }
                    }
                }
            }
            //false - increasing
            if (direction == false)
            {
                for (int i = 0; i < ary.Length; i++)
                {
                    for (int j = i + 1; j < ary.Length; j++)
                    {
                        if (ary[i] > ary[j])
                        {
                            temp_double = ary[i];
                            temp_int = sort_index[i];
                            ary[i] = ary[j];
                            sort_index[i] = sort_index[j];
                            ary[j] = temp_double;
                            sort_index[j] = temp_int;
                        }
                    }
                }
            }
            return sort_index;
        }

        /*public bool MultiRouting(int origin, int destination, out int[][] MultiRoutes, out double[] Path_TT, out double[] Path_Distance, out string color)
        {
            MultiRoutes = new int[5][];
            double[] Path_TT_Raw;
            double[] Path_Distance_Raw;
            Path_TT = new double[5];
            Path_Distance = new double[5];

            int[][] K_PathAry;
            int[][] LinkSeq = new int[9][];

            color = null;
            string[] ary_color = new string[5] {"r", "g", "b", "k", "y" };
            double temp_TT, temp_Dis;
            int count = 0, detour = 0;


            int k = K_ShortestPath_Unsorted(origin, destination, out K_PathAry, out Path_TT_Raw, out Path_Distance_Raw);
            
            double min_TT = 0, min_Dstance = 0, max_Speed = 0;
            int min_TT_Path = 0, min_Dstance_Path = 0, max_Speed_Path = 1, safety_Path = 0;
            // find out winners
            min_TT = Path_TT_Raw[0]; min_Dstance = Path_Distance_Raw[0]; max_Speed = Path_Distance_Raw[0] / Path_TT_Raw[0];
            for (int i = 1; i < k; i++)
            {
                if (K_PathAry[i] != null)
                {
                    if (Path_TT_Raw[i] < min_TT)
                    {
                        min_TT = Path_TT_Raw[i];
                        min_TT_Path = i;
                    }
                    if (Path_Distance_Raw[i] < min_Dstance)
                    {
                        min_Dstance = Path_Distance_Raw[i];
                        min_Dstance_Path = i;
                    }
                    if (Path_Distance_Raw[i] / Path_TT_Raw[i] > max_Speed && Path_Distance_Raw[i] <= Path_Distance_Raw[0] * 1.5)
                    {
                        max_Speed = Path_Distance_Raw[i] / Path_TT_Raw[i];
                        max_Speed_Path = i;
                    }
                    GetRoute(K_PathAry[i], out LinkSeq[i], out temp_TT, out temp_Dis);
                    for (int j = 0; j < LinkSeq.Length; j++)
                    {
                        if (aryCLink[LinkSeq[i][j]].Link_TMC == null && aryCLink[LinkSeq[i][j]].Link_SpeedLimit >= 40)                           
                        {
                            count++;
                        }
                        else if (aryCLink[LinkSeq[i][j]].Link_TMC != null)
                        {
                            if (TMCIDtoIndex.ContainsKey(aryCLink[LinkSeq[i][j]].Link_TMC) && Live_Speed[10, TMCIDtoIndex[aryCLink[LinkSeq[i][j]].Link_TMC]] >= 40)
                            {
                                count++;
                            }
                            else if(!TMCIDtoIndex.ContainsKey(aryCLink[LinkSeq[i][j]].Link_TMC) && aryCLink[LinkSeq[i][j]].Link_SpeedLimit >= 40)
                            {
                                count++;
                            }
                        }
                    }
                    if (count == LinkSeq[i].Length)
                    {
                        safety_Path = i;
                    }
                    count = 0;
                    detour = i;
                }
            }

            if (Path_Distance_Raw[0] < Path_Distance_Raw[min_Dstance_Path])
            {
                min_Dstance_Path = 0;
            }
            //least time
            if (K_PathAry[min_TT_Path] != null)
            {
                MultiRoutes[0] = new int[K_PathAry[min_TT_Path].Length];
                K_PathAry[min_TT_Path].CopyTo(MultiRoutes[0], 0);
                Path_TT[0] = Path_TT_Raw[min_TT_Path];
                Path_Distance[0] = Path_Distance_Raw[min_TT_Path];
            }
            //shortest path
            if (K_PathAry[min_Dstance_Path] != null)
            {
                MultiRoutes[1] = new int[K_PathAry[min_Dstance_Path].Length];
                K_PathAry[min_Dstance_Path].CopyTo(MultiRoutes[1], 0);
                Path_TT[1] = Path_TT_Raw[min_Dstance_Path];
                Path_Distance[1] = Path_Distance_Raw[min_Dstance_Path];
            }
            //Eco
            if (K_PathAry[max_Speed_Path] != null)
            {
                MultiRoutes[2] = new int[K_PathAry[max_Speed_Path].Length];
                K_PathAry[max_Speed_Path].CopyTo(MultiRoutes[2], 0);
                Path_TT[2] = Path_TT_Raw[max_Speed_Path];
                Path_Distance[2] = Path_Distance_Raw[max_Speed_Path];
            }
            //Detour
            if (K_PathAry[detour] != null)
            {
                MultiRoutes[3] = new int[K_PathAry[detour].Length];
                K_PathAry[detour].CopyTo(MultiRoutes[3], 0);
                Path_TT[3] = Path_TT_Raw[detour];
                Path_Distance[3] = Path_Distance_Raw[detour];
            }
            //alt
            if (K_PathAry[3] != null)
            {
                MultiRoutes[4] = new int[K_PathAry[3].Length];
                K_PathAry[3].CopyTo(MultiRoutes[4], 0);
                Path_TT[4] = Path_TT_Raw[3];
                Path_Distance[4] = Path_Distance_Raw[3];
            }
            color = ary_color[0];
            int m = 0;
            for (int l = 1; l < 4; l++)
            {
                if (MultiRoutes[l] != MultiRoutes[l - 1])
                {
                    m++;
                    color += ary_color[m];                    
                }
                else
                {
                    color += ary_color[m];
                }
            }
            

            return true;

        }*/


        /// <summary>
        /// Function to get a route object from the result of shortest path calculation
        /// </summary>
        /// <param name="SP_CalculateDirection">determing which SP direction is used, true: destination based; false: origin based</param>
        /// <param name="origin_index">index number of origine node</param>
        /// <param name="destination_index">index number of destination node</param>
        /// <param name="PredAry">the result of SP calculation: a shortest path tree for a certain node</param>
        /// <param name="VoT">value of time</param>
        /// <param name="FlagRealTime">true if the calculation is based on real time travel time</param>
        /// <param name="DepartureTimeInterval">departure time interval</param>
        /// <param name="route">output a CRoute object</param>
        /// <returns>true if route is not empty</returns>
        public bool GetRoute(bool SP_CalculateDirection, int origin_index, int destination_index, int[] PredAry,
                                double VoT, bool FlagRealTime, int DepartureTimeInterval, out CRoute route)//true: destination based; false: origin based
        {
            route = new CRoute();
            //get PathAry
            int node_index = 0;
            int[] PathAryTemp = new int[m_NodeSize];
            int PathNodeSize = 0;

            if (SP_CalculateDirection)//destination based shortest path algorithm
            {
                if (PredAry[origin_index] == -1)
                {
                    route = null;
                    return false;
                }
                node_index = origin_index;
                while (node_index != destination_index)
                {
                    PathAryTemp[PathNodeSize] = node_index;
                    node_index = PredAry[node_index];
                    PathNodeSize++;
                    if (PathNodeSize >= m_NodeSize)
                    {
                        route = null;
                        return false;
                    }
                }
                PathAryTemp[PathNodeSize] = destination_index;
                PathNodeSize++;
                if (PathNodeSize < 2)
                {
                    route = null;
                    return false;
                }
                route.PathAry = new int[PathNodeSize];
                for (int i = 0; i < PathNodeSize; i++)
                {
                    route.PathAry[i] = PathAryTemp[i];
                }
            }
            else //origin based shortest path algorithm
            {
                if (PredAry[destination_index] == -1)
                {
                    route = null;
                    return false;
                }
                node_index = destination_index;
                while (node_index != origin_index)
                {
                    PathAryTemp[PathNodeSize] = node_index;
                    node_index = PredAry[node_index];
                    PathNodeSize++;
                    if (PathNodeSize >= m_NodeSize)
                    {
                        route = null;
                        return false;
                    }
                }
                PathAryTemp[PathNodeSize] = origin_index;
                PathNodeSize++;
                if (PathNodeSize < 2)
                {
                    route = null;
                    return false;
                }
                route.PathAry = new int[PathNodeSize];
                for (int i = 0; i < PathNodeSize; i++)
                {
                    route.PathAry[PathNodeSize - 1 - i] = PathAryTemp[i];
                }
            }


            //get LinkSeq
            int TempNodeID = 0;
            int link_size = 0;
            double temp_link_cost = 0;
            route.LinkSeq = new int[route.PathAry.Length - 1];
            for (int i = 0; i < route.LinkSeq.Length; i++)
            {
                temp_link_cost = 99999999;
                for (int l = 0; l < InboundLinkSize[route.PathAry[i + 1]]; l++)
                {
                    TempNodeID = aryCLink[InboundLinkAry[route.PathAry[i + 1], l]].FromID;
                    if (m_NodeIDtoIndex[TempNodeID] == route.PathAry[i])
                    {
                        link_size++;
                        if (LinkCost_Penalty[InboundLinkAry[route.PathAry[i + 1], l]] < temp_link_cost)
                        {
                            route.LinkSeq[i] = InboundLinkAry[route.PathAry[i + 1], l];
                            temp_link_cost = LinkCost_Penalty[InboundLinkAry[route.PathAry[i + 1], l]];
                        }

                    }
                }
            }
            //if (link_size != route.LinkSeq.Length)
            //{
            //    route = null;
            //    return false;
            //}

            //get travel time
            if (FlagRealTime)
            {
                if (DepartureTimeInterval < 0 || DepartureTimeInterval >= m_TimeIntervalSize)
                {
                    route = null;
                    return false;
                }
                double Departure_Time = DepartureTimeInterval * m_TimeInterval;
                double curr_Time = Departure_Time;
                int curr_Interval = 0;
                for (int j = 0; j < route.LinkSeq.Length; j++)
                {
                    curr_Interval = (int)Math.Floor(curr_Time / m_TimeInterval) % m_TimeIntervalSize;
                    route.PathTime += LinkCost_TimeD[route.LinkSeq[j], curr_Interval];
                    curr_Time += LinkCost_TimeD[route.LinkSeq[j], curr_Interval];
                }
                //TODO: use TrafficColorCode here
                TrafficColorCode(DepartureTimeInterval, route.LinkSeq, out route.TrafficColor);
            }
            else
            {
                for (int j = 0; j < route.LinkSeq.Length; j++)
                {
                    route.PathTime += LinkCost[route.LinkSeq[j]];
                }
                route.TrafficColor = new int[route.LinkSeq.Length];
            }

            //get distance 
            for (int l = 0; l < route.LinkSeq.Length; l++)
            {
                route.PathDist += aryCLink[route.LinkSeq[l]].Link_Length;
            }

            // get cost in dollar
            bool once = true;
            for (int l = 0; l < route.LinkSeq.Length; l++)
            {
                route.PathCost += LinkCost_Fuel[route.LinkSeq[l]];
                if (once == true && aryCLink[route.LinkSeq[l]].Link_Type == 9)
                {
                    route.PathCost += Transit_Cost;
                    once = false;
                }
            }
            route.PathCost += route.PathTime * VoT;

            //get safety factor
            for (int j = 0; j < route.LinkSeq.Length; j++)
            {
                route.PathSafety = route.PathSafety * (1 - aryCLink[route.LinkSeq[j]].Safety);
            }
            route.PathSafety = 1 - route.PathSafety;

            return true;
        }

        private bool UpdateLinkCost_Penalty(int[] LinkSeq, double VOO, double Path_FFTT)
        {
            if (LinkSeq == null)
                return false;
            for (int j = 0; j < LinkSeq.Length; j++)
            {
                LinkCost_Penalty[LinkSeq[j]] = LinkCost[LinkSeq[j]] + VOO * LinkCost[LinkSeq[j]] / Path_FFTT;
            }
            return true;
        }

        private bool UpdateLinkCost_TimeD_Penalty(int[] LinkSeq, double VOO, double Path_FFTT)
        {
            if (LinkSeq == null)
                return false;
            for (int j = 0; j < LinkSeq.Length; j++)
            {
                for (int i = 0; i < m_TimeIntervalSize; i++)
                    LinkCost_TimeD_Penalty[LinkSeq[j], i] = LinkCost_TimeD[LinkSeq[j], i] + VOO * LinkCost_TimeD[LinkSeq[j], i] / Path_FFTT;
            }
            return true;
        }

        private double GetOverlappingFactor(int[] LinkSeq_1, double Path_FFTT_1, int[] LinkSeq_2)
        {
            if (LinkSeq_1 == null || LinkSeq_2 == null)
                return -1;

            double Sum = 0;
            for (int i = 0; i < LinkSeq_2.Length; i++)
            {
                for (int l = 0; l < LinkSeq_1.Length; l++)
                {
                    if (LinkSeq_2[i] == LinkSeq_1[l])
                    {
                        Sum += LinkCost[LinkSeq_1[l]];
                        break;
                    }
                }
            }
            double OverlappingFactor = Sum / Path_FFTT_1;
            return OverlappingFactor;
        }

        //public void Load_TimeD_TT_Values()
        //{
        //    ///////////////////////////////////////////////Time-dependent link travel time data. ***TEST ONLY***
        //    int origin = 195, destination = 1480;//origin = 1, destination = 1480;//origin = 2306, destination = 2251;
        //    int origin_index = m_NodeIDtoIndex[origin], destination_index = m_NodeIDtoIndex[destination];
        //    int[] PredAry;
        //    int[] PathAry;
        //    int[] LinkSeq;
        //    double Path_FFTT, Path_Distance;
        //    ShortestPath_Origin(origin, out PredAry);
        //    GetPathAry(1, origin_index, destination_index, PredAry, out PathAry); //change travel time pattern for I-15
        //    GetRoute(PathAry, out LinkSeq, out Path_FFTT, out Path_Distance);

        //    for (int l = 0; l < LinkSeq.Length; l++)
        //    {
        //        for (int i = 60; i < 80; i++) //from 6AM to 10AM
        //            LinkCost_TimeD[LinkSeq[l], i] = LinkCost_TimeD[LinkSeq[l], i] * 3;
        //    }

        //    //////////////////////////////////////////////////////////////////////////////////////////////////
        //}



        public bool RealTrafficUpdate(string filepath, string filename)
        {

            // read TMC data from XML file and update LinkCost
            string Element_Name = null;
            string lane = null, curr = null, dir = null;
            string curr_TMC = null;
            double spd = 0;
            XmlTextReader reader;
            try
            {
                reader = new XmlTextReader(filepath + filename);
            }
            catch (Exception e)
            {
                return false;
            }

            if (!reader.Read())
            {
                return false;
            }

            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // element.
                        Element_Name = reader.Name;
                        if (Element_Name == "LANE_TYPE")
                        {
                            lane = reader.GetAttribute("TYPE");
                        }
                        if (Element_Name == "TRAVEL_TIME")
                        {
                            curr = reader.GetAttribute("TYPE");
                        }
                        if (Element_Name == "FLOW_ITEMS")
                        {
                            dir = reader.GetAttribute("DIRECTION");
                        }
                        break;

                    case XmlNodeType.Text:
                        switch (Element_Name)
                        {
                            case "ID":
                                curr_TMC = dir + reader.Value;
                                break;

                            case "AVERAGE_SPEED":
                                if (lane == "THRU" && curr == "current")
                                {
                                    spd = double.Parse(reader.Value);
                                    if (TMCIDtoLink.ContainsKey(curr_TMC))
                                    {
                                        for (int i = 1; i <= TMCIDtoLink[curr_TMC][0]; i++)
                                        {
                                            LinkCost[TMCIDtoLink[curr_TMC][i]] = aryCLink[TMCIDtoLink[curr_TMC][i]].Link_Length / spd * 60;
                                        }
                                    }
                                }
                                break;
                        }
                        break;
                }

            }
            reader.Close();
            return true;
        }



        public long[][] MappingTable;

        /*public void getTMC_MappingTable()
        {
            int max_size = 2384;
            string filepath = @"E:\DATA\Confidential\Traffic.com\";
            string file = "RealtimeFlow13_0.xml";
            XmlTextReader reader = new XmlTextReader(filepath + file);
            string[] Real_TMC = new string[max_size];
            string[] Road_Name = new string[max_size];
            //double[] Spd = new double[max_size];
            Dictionary<string, int> Real_TMC_STime = new Dictionary<string,int>();
            string curr_TMC = null, curr_Road_Name = null;
            int lineTMC = 0, lineSPD = 0;
            string Element_Name = null;
            string lane = null, curr = null;

            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // element.
                        Element_Name = reader.Name;
                        if (Element_Name == "LANE_TYPE")
                        {
                            lane = reader.GetAttribute("TYPE");
                        }
                        if (Element_Name == "TRAVEL_TIME")
                        {
                            curr = reader.GetAttribute("TYPE");
                        }
                        break;

                    case XmlNodeType.Text:
                        switch (Element_Name)
                        {
                            case "ID":
                                curr_TMC = reader.Value;
                                lineTMC++;
                                break;
                            case "DESCRIPTION":
                                curr_Road_Name = reader.Value;
                                break;

                            case "AVERAGE_SPEED":
                                if (lane == "THRU" && curr == "current")
                                {
                                    Real_TMC[lineSPD] = curr_TMC;
                                    Road_Name[lineSPD] = curr_Road_Name;
                                    //Spd[lineSPD] = float.Parse(reader.Value);
                                    switch (Real_TMC_STime.ContainsKey(curr_TMC))
                                    {
                                        case true:
                                            Real_TMC_STime[curr_TMC] = Real_TMC_STime[curr_TMC] + 1;
                                            break;
                                        case false:
                                            Real_TMC_STime.Add(curr_TMC, 0);
                                           break;
                                    }     
                                    lineSPD++;
                                    break;
                                }
                                else
                                {
                                    break;
                                }

                        }
                        break;

                }

            }
            //load network
            filepath = @"E:\DATA\Confidential\Navteq\bay_area\";
            LoadNetwork_XML(filepath, "Bay");
            //long[] Table_LinkID = new long[70000];
            //string[] Table_TMC = new string[70000];
            int count = 0;

            //load TMC2LinkID table 
            FileStream nwfsInput;
            StreamReader nwsrInput;
            int line = 0;
            filepath = @"E:\DATA\Confidential\Navteq\bay_area\";
            file = filepath + "san_fran_bay_edge2tmc.csv";
            nwfsInput = new FileStream(file, FileMode.Open, FileAccess.Read);
            nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine, subStr;
            int index, subLength;
            Dictionary<string, long[]> Table_TMC2ID = new Dictionary<string,long[]>();
            long link_id = 0;
            string road_dir, tmc;
            int kk = 0, link_index = 0;
            string insert = "0", a, b;            

            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                index = szSrcLine.IndexOf(",");
                subStr = szSrcLine.Substring(0, index);
                subStr = subStr.Trim();
                link_id = int.Parse(subStr);
                subLength = szSrcLine.Length;
                szSrcLine = szSrcLine.Substring(index + 1, subLength - index - 1);

                subStr = szSrcLine.Substring(0, 1);
                road_dir = subStr;

                index = szSrcLine.IndexOf(",");
                subStr = szSrcLine.Substring(1, index - 1);
                tmc = subStr;
                if (tmc.Length < 9)
                {
                    a = tmc.Substring(0, 4);
                    b = tmc.Substring(4, 4);
                    tmc = a + insert + b;
                    kk++;
                }
                if (m_LinkIDtoIndex.ContainsKey(link_id))
                {
                    switch (Table_TMC2ID.ContainsKey(tmc))
                    {
                        case true:
                            Table_TMC2ID[tmc][0] = Table_TMC2ID[tmc][0] + 1;
                            Table_TMC2ID[tmc][Table_TMC2ID[tmc][0]] = link_id;
                            break;
                        case false:
                            Table_TMC2ID.Add(tmc, new long[70]);
                            Table_TMC2ID[tmc][0] = Table_TMC2ID[tmc][0] + 1;
                            Table_TMC2ID[tmc][Table_TMC2ID[tmc][0]] = link_id;
                            break;
                    }
                }
                line++;
            }
            
            //MATCH
            int count_1 = 0, count_2 = 0, curr_flag = 0;
            MappingTable = new long[max_size][];
            for (int i = 0; i < max_size; i++)
            {
                if (Table_TMC2ID.ContainsKey(Real_TMC[i]) && Real_TMC_STime[Real_TMC[i]] == 0)
                {
                    MappingTable[i] = new long[70];
                    Table_TMC2ID[Real_TMC[i]].CopyTo(MappingTable[i], 0);
                }
                else if (Table_TMC2ID.ContainsKey(Real_TMC[i]) && Real_TMC_STime[Real_TMC[i]] == 1)
                {
                    for (int l = 1; l < 70; l++)
                    {
                        if (m_LinkIDtoIndex.TryGetValue(Table_TMC2ID[Real_TMC[i]][l], out link_index))
                        {
                            if (Road_Name[i] == aryCLink[m_LinkIDtoIndex[Table_TMC2ID[Real_TMC[i]][l]]].Link_Name)
                            {
                                MappingTable[i] = new long[70];
                                MappingTable[i][0] = MappingTable[i][0] + 1;
                                MappingTable[i][MappingTable[i][0]] = Table_TMC2ID[Real_TMC[i]][l];
                                count_1++;
                                curr_flag = 1;
                            }
                        }
                    }
                    if (curr_flag == 0)
                        count_2++;
                }
                else
                {
                    count++;
                }

            }

        }*/


        public void K_ShortestPath(int originID, int destinationID, bool real, int DepartureTimeInterval, double VoT, int RouteSizeRequest, int CandidateSizeRequest,
                                   out CRoute[] K_Sorted_Routes)
        {
            CRoute[] K_routes = new CRoute[m_MAX_KSP_SIZE];
            if (real == false)
            {
                K_ShortestPath_Unsorted(originID, destinationID, VoT, CandidateSizeRequest, out K_routes);
            }
            else
            {
                K_ShortestPath_TimeD_Unsorted(originID, destinationID, DepartureTimeInterval, VoT, CandidateSizeRequest, out K_routes);
            }

            int route_size = 6, p = 0;
            K_Sorted_Routes = new CRoute[route_size];
            int Quickest_Route, Shortest_Route, Eco_Route, Safe_Route, Detour, LeastCost_Route;
            double[] PathTime_Unsorted, Path_Distance_Unsorted, Safety_Factor_Unsorted, Path_Cost_Unsorted;
            PathTime_Unsorted = new double[m_MAX_KSP_SIZE];
            Path_Distance_Unsorted = new double[m_MAX_KSP_SIZE];
            Safety_Factor_Unsorted = new double[m_MAX_KSP_SIZE];
            Path_Cost_Unsorted = new double[m_MAX_KSP_SIZE];
            for (int i = 0; i < m_MAX_KSP_SIZE; i++)
            {
                if (K_routes[i] != null)
                {
                    PathTime_Unsorted[i] = K_routes[i].PathTime;
                    Path_Distance_Unsorted[i] = K_routes[i].PathDist;
                    Safety_Factor_Unsorted[i] = K_routes[i].PathSafety;
                    Path_Cost_Unsorted[i] = K_routes[i].PathCost;
                }
                else
                {
                    PathTime_Unsorted[i] = 0;
                    Path_Distance_Unsorted[i] = 0;
                    Safety_Factor_Unsorted[i] = 1;
                    Path_Cost_Unsorted[i] = 0;
                }
            }

            //fastest route
            p = 0;
            do
            {
                Quickest_Route = SortingFunction(PathTime_Unsorted, false)[p];
                p++;
            }
            while (PathTime_Unsorted[Quickest_Route] == 0 && p < 9);
            if (K_routes[Quickest_Route] != null)
            {
                K_Sorted_Routes[0] = K_routes[Quickest_Route];
            }

            if (RouteSizeRequest > 2)
            {
                //shortest route
                p = 0;
                do
                {
                    Shortest_Route = SortingFunction(Path_Distance_Unsorted, false)[p];
                    p++;
                }
                while (Path_Distance_Unsorted[Shortest_Route] == 0 && p < 9);
                if (K_routes[Shortest_Route] != null)
                {
                    K_Sorted_Routes[1] = K_routes[Shortest_Route];
                }
            }

            //Eco route
            double[] Eco_Factor = new double[m_MAX_KSP_SIZE];
            for (int i = 0; i < m_MAX_KSP_SIZE; i++)
            {
                if (PathTime_Unsorted[i] != 0)
                {
                    Eco_Factor[i] = Path_Distance_Unsorted[i] / PathTime_Unsorted[i];
                }
                else
                {
                    Eco_Factor[i] = 0;
                }
            }
            Eco_Route = SortingFunction(Eco_Factor, true)[0];
            if (K_routes[Eco_Route] != null)
            {
                K_Sorted_Routes[2] = K_routes[Eco_Route];
            }

            if (RouteSizeRequest > 3)
            {
                //safe route
                Safe_Route = SortingFunction(Safety_Factor_Unsorted, false)[0];
                if (K_routes[Safe_Route] != null)
                {
                    K_Sorted_Routes[3] = K_routes[Safe_Route];
                }

                //Detour
                Detour = m_MAX_KSP_SIZE - 1;
                if (K_routes[Detour] != null)
                {
                    K_Sorted_Routes[4] = K_routes[Detour];
                }

                if (RouteSizeRequest > 5)
                {
                    //Least cost route
                    p = 0;
                    do
                    {
                        LeastCost_Route = SortingFunction(Path_Cost_Unsorted, false)[p];
                        p++;
                    }
                    while (Path_Cost_Unsorted[LeastCost_Route] == 0 && p < 9);
                    if (K_routes[LeastCost_Route] != null)
                    {
                        K_Sorted_Routes[5] = K_routes[LeastCost_Route];
                    }
                }
            }

        }

        public void PathClustering(int[][] K_PathAry, out int[][] K_PathAry_shorter)
        {
            //try to reduce the nodes in a path by removing the middle points in the same direction (less than * degree)

            int curr_index, move, s = 0;
            double deg;
            int path_size = 5;
            int[][] temp = new int[path_size][]; ;
            K_PathAry_shorter = new int[path_size][];
            for (int i = 0; i < K_PathAry.Length; i++)
            {
                if (K_PathAry[i] != null)
                {
                    s = 0;
                    temp[i] = new int[K_PathAry[i].Length];
                    for (curr_index = 0; curr_index < K_PathAry[i].Length; curr_index = curr_index + move)
                    {
                        temp[i][s] = K_PathAry[i][curr_index];
                        move = 1;
                        deg = 0;
                        while (Math.Abs(deg) < Math.PI / 36) //less than 10 degree
                        {
                            move++;
                            if (curr_index + move < K_PathAry[i].Length)
                            {
                                deg = Math.Atan((aryCNode[K_PathAry[i][curr_index + move]].Node_UTM_Northing - aryCNode[K_PathAry[i][curr_index]].Node_UTM_Northing) / (aryCNode[K_PathAry[i][curr_index + move]].Node_UTM_Easting - aryCNode[K_PathAry[i][curr_index]].Node_UTM_Easting))
                                    - Math.Atan((aryCNode[K_PathAry[i][curr_index + 1]].Node_UTM_Northing - aryCNode[K_PathAry[i][curr_index]].Node_UTM_Northing) / (aryCNode[K_PathAry[i][curr_index + 1]].Node_UTM_Easting - aryCNode[K_PathAry[i][curr_index]].Node_UTM_Easting));
                            }
                            else
                                break;
                        }
                        move--;
                        s++;
                    }
                    K_PathAry_shorter[i] = new int[s];
                    for (int j = 0; j < s; j++)
                    {
                        K_PathAry_shorter[i][j] = temp[i][j];
                    }
                }
                else
                {
                    K_PathAry_shorter[i] = null;
                }

            }

        }

        public void PathClustering(int[] K_PathAry, out int[] K_PathAry_shorter)
        {
            //try to reduce the nodes in a path by removing the middle points in the same direction (less than * degree)

            int curr_index, move, s = 0;
            double deg;
            int[] temp;

            if (K_PathAry != null)
            {
                temp = new int[K_PathAry.Length];
                for (curr_index = 0; curr_index < K_PathAry.Length; curr_index = curr_index + move)
                {
                    temp[s] = K_PathAry[curr_index];
                    move = 1;
                    deg = 0;
                    while (Math.Abs(deg) < Math.PI / 36) //less than 10 degree
                    {
                        move++;
                        if (curr_index + move < K_PathAry.Length)
                        {
                            deg = Math.Atan((aryCNode[K_PathAry[curr_index + move]].Node_UTM_Northing - aryCNode[K_PathAry[curr_index]].Node_UTM_Northing) / (aryCNode[K_PathAry[curr_index + move]].Node_UTM_Easting - aryCNode[K_PathAry[curr_index]].Node_UTM_Easting))
                                - Math.Atan((aryCNode[K_PathAry[curr_index + 1]].Node_UTM_Northing - aryCNode[K_PathAry[curr_index]].Node_UTM_Northing) / (aryCNode[K_PathAry[curr_index + 1]].Node_UTM_Easting - aryCNode[K_PathAry[curr_index]].Node_UTM_Easting));
                        }
                        else
                            break;
                    }
                    move--;
                    s++;
                }
                K_PathAry_shorter = new int[s];
                for (int j = 0; j < s; j++)
                {
                    K_PathAry_shorter[j] = temp[j];
                }
            }
            else
            {
                K_PathAry_shorter = null;
            }

        }



        Dictionary<long, string> LinkID2TMC;



        public bool ConvertLatLong2Pix(double max_lat, double max_long, double min_lat, double min_long, double point_lat, double point_long, double pix_width, double pix_heigth, out double point_x, out double point_y)
        {
            if (max_long == min_long || max_lat == min_lat || pix_width == 0 || pix_heigth == 0)
            {
                point_x = -1;
                point_y = -1;
                return false;
            }

            if (point_long < min_long || point_long > max_long || point_lat < min_lat || point_lat > max_lat)
            {
                point_x = -1;
                point_y = -1;
                return false;
            }

            point_x = (point_long - min_long) / (max_long - min_long) * pix_width;
            point_y = (max_lat - point_lat) / (max_lat - min_lat) * pix_heigth;

            return true;

        }

        public int FindClosestNodeIndex(double Lat, double Long) //return node index
        {
            int node_index = -1;
            double dist = 0, max_dist = 1000;
            for (int l = 0; l < m_NodeSize; l++)
            {
                dist = Math.Pow(aryCNode[l].Node_Lat - Lat, 2) + Math.Pow(aryCNode[l].Node_Long - Long, 2);
                if (dist < max_dist && dist < 100)
                {
                    node_index = l;
                    max_dist = dist;
                }
            }
            return node_index;

        }


        //public 

        public bool TileGenerator(string filepath, string filename, string ouuputpath, string source, double link_id)
        {



            return true;
        }

        /*public bool AddTransitLayer_Demo(long[] BusStopLinkSeq, int node_count, int link_count, out int node_count_updtd, out int link_count_updtd) //(int[] LinkSeq, int[] bus_linkseq)
        {
            CNode node;
            CLink link;
            int node_id = 0, node_areaID = 0, node_maplevel = 0, node_controltype = 0, node_UTM_zone = 0, node_type = 1;
            double node_long = 0, node_lat = 0, node_UTM_easting = 0, node_UTM_northing = 0;
            string node_name = null;
            LatLongValue nval;
            int node_id_pre = 0;
            node_count_updtd = node_count;
            int link_index = 0;
            long link_id = 0;
            int link_areaID = 0, link_fromID = -1, link_toID = -1, link_maplevel = 0, link_modeflag = 0;
            int link_lanesize = 0, link_type = 0, link_isshape = 0, link_shapeID = -1;
            double link_length = 0, link_speedlimit = 0;
            string link_name = null;
            link_count_updtd = link_count;
            // add bus node and connector
            for (int i = 0; i < BusStopLinkSeq.Length; i++)
            {
                link_index = m_LinkIDtoIndex[BusStopLinkSeq[i]];
                // add bus node
                //node id
                while (m_NodeIDtoIndex.ContainsKey(node_id))
                {
                    node_id++;
                }
                //node long/lat                
                node_long = (aryCNode[m_NodeIDtoIndex[aryCLink[link_index].Link_FromID]].Node_Long + aryCNode[m_NodeIDtoIndex[aryCLink[link_index].Link_ToID]].Node_Long) / 2;
                node_lat = (aryCNode[m_NodeIDtoIndex[aryCLink[link_index].Link_FromID]].Node_Lat + aryCNode[m_NodeIDtoIndex[aryCLink[link_index].Link_ToID]].Node_Lat) / 2;
                //node UTM
                nval = new LatLongValue();
                nval = LatLongValue.LatLongToUTM(node_lat, node_long);
                node_UTM_easting = nval.utmEx;
                node_UTM_northing = nval.utmNy;
                node_UTM_zone = nval.zone;
                // add node to aryCNode
                node = new CNode(node_id, node_areaID, node_long, node_lat, node_UTM_easting, node_UTM_northing, node_UTM_zone,
                                node_maplevel, node_controltype, node_type, node_name);
                aryCNode[node_count_updtd] = node;
                m_NodeIDtoIndex.Add(node_id, node_count_updtd);
                m_NodeIndextoID[node_count_updtd] = node_id;
                node_count_updtd++;                
                node_areaID = 0; node_maplevel = 0; node_controltype = 0; node_UTM_zone = 0;
                node_long = 0; node_lat = 0; node_UTM_easting = 0; node_UTM_northing = 0;
                node_name = null;

                ///////////////////////////////////////////////////////////////////////////////////////////////////
                // add connector link_type = 10
                for (int c = 0; c < 4; c++)
                {
                    while (m_LinkIDtoIndex.ContainsKey(link_id))
                    {
                        link_id++;
                    }
                    link_length = aryCLink[link_index].Link_Length / 2;
                    link_speedlimit = m_WalkingSpeed;
                    link_type = 10;
                    switch (c) // add 4 connector for each bus stop
                    {
                        case 0:
                            link_fromID = aryCLink[link_index].Link_FromID;
                            link_toID = node_id;
                            break;
                        case 1:
                            link_fromID = node_id;
                            link_toID = aryCLink[link_index].Link_FromID;
                            break;
                        case 2:
                            link_fromID = node_id;
                            link_toID = aryCLink[link_index].Link_ToID;
                            break;
                        case 3:
                            link_fromID = aryCLink[link_index].Link_ToID;
                            link_toID = node_id;
                            break;
                    }
                    link = new CLink(link_id, link_areaID, link_name, link_fromID, link_toID, link_maplevel, link_modeflag,
                                    "mile", link_length, link_lanesize, link_speedlimit, link_type, link_isshape, link_shapeID, true, 0);
                    //link.Link_TMC = link_tmc;
                    aryCLink[link_count_updtd] = link;
                    m_LinkIDtoIndex.Add(link_id, link_count_updtd);
                    link_count_updtd++;
                    link_id++;
                    link_areaID = 0; link_fromID = -1; link_toID = -1; link_maplevel = 0; link_modeflag = 0;
                    link_lanesize = 0; link_speedlimit = 0; link_type = 10; link_isshape = 0; link_shapeID = -1;
                    link_length = 0;
                    link_name = null;
                }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                if (i > 0)
                {
                    // add bus link link_type = 9
                    while (m_LinkIDtoIndex.ContainsKey(link_id))
                    {
                        link_id++;
                    }
                    link_type = 9;
                    link_length = 100;
                    link_speedlimit = m_WalkingSpeed;
                    link_fromID = node_id_pre;
                    link_toID = node_id;

                    link = new CLink(link_id, link_areaID, link_name, link_fromID, link_toID, link_maplevel, link_modeflag,
                                        "mile", link_length, link_lanesize, link_speedlimit, link_type, link_isshape, link_shapeID, true, 0);
                    //link.Link_TMC = link_tmc;
                    aryCLink[link_count_updtd] = link;
                    m_LinkIDtoIndex.Add(link_id, link_count_updtd);
                    link_count_updtd++;
                    link_id++;
                    link_areaID = 0; link_fromID = -1; link_toID = -1; link_maplevel = 0; link_modeflag = 0;
                    link_lanesize = 0; link_speedlimit = 0; link_type = 9; link_isshape = 0; link_shapeID = -1;
                    link_length = 0;
                    link_name = null;
                }

                ////////////////////////////////////////////////////////////////////////////////////////////////////////////
                node_id_pre = node_id;
                node_id++; 

            }


            
            return true;

        }*/



        public bool Analysis_Network_withTransit(string filepath, string filename)
        {
            //generate InboundLinkAry and InboundLinkSize
            int MaxInboundLink = 12;
            int MaxOutgoingLink = 12;
            double MAX_COST = 9999999;
            InboundLinkAry = new int[m_NodeSize, MaxInboundLink];
            InboundLinkSize = new int[m_NodeSize];
            int l, node_index;
            //first generate link list based on node index
            LinkList = new int[m_LinkSize, 2];// To node, from node
            LinkCost = new double[m_LinkSize];// cost
            LinkCost_Penalty = new double[m_LinkSize];//cost with penalty
            LinkCost_Fuel = new double[m_LinkSize]; // fuel cost in dollar 
            LinkCost_TimeD = new double[m_LinkSize, m_TimeIntervalSize];
            LinkCost_TimeD_Penalty = new double[m_LinkSize, m_TimeIntervalSize];
            LinkCost_TimeD_Transit = new double[m_LinkSize, m_TimeIntervalTransitSize];
            /*/ For Demo Only //////////////////////////////////////////////////////////////////////
            const int stop_size = 5, time_size = 91;
            int[][] BusSchedule = new int[stop_size][];
            BusSchedule[0] = new int[time_size] { 324, 349, 374, 394, 412, 427, 439, 449, 459, 469, 479, 489, 497, 504, 510, 517, 524, 532, 540, 548, 556, 564, 572, 581, 591, 602, 612, 622, 632, 642, 653, 664, 675, 686, 697, 708, 719, 730, 741, 751, 762, 773, 784, 795, 806, 817, 828, 839, 850, 861, 872, 883, 894, 905, 916, 926, 937, 948, 959, 970, 981, 992, 1003, 1014, 1024, 1034, 1044, 1053, 1063, 1073, 1083, 1093, 1103, 1115, 1127, 1139, 1151, 1163, 1175, 1188, 1203, 1218, 1236, 1253, 1270, 1287, 1304, 1324, 1344, 1364, 1388 };
            BusSchedule[1] = new int[time_size] { 327, 354, 379, 399, 417, 432, 444, 454, 464, 474, 484, 494, 502, 509, 516, 523, 530, 538, 546, 554, 562, 570, 578, 587, 597, 608, 618, 628, 638, 648, 659, 670, 681, 692, 703, 714, 725, 736, 747, 759, 770, 781, 792, 803, 814, 825, 836, 847, 858, 869, 880, 891, 902, 913, 924, 934, 945, 956, 967, 978, 989, 1000, 1011, 1022, 1032, 1042, 1052, 1061, 1071, 1081, 1091, 1101, 1111, 1120, 1132, 1144, 1156, 1168, 1180, 1193, 1208, 1223, 1240, 1257, 1274, 1291, 1308, 1328, 1348, 1368, 1392 };
            BusSchedule[2] = new int[time_size] { 332, 360, 385, 405, 423, 441, 453, 463, 473, 483, 493, 503, 511, 519, 526, 533, 540, 548, 556, 564, 572, 580, 588, 597, 607, 617, 627, 637, 647, 657, 668, 679, 690, 701, 712, 723, 734, 745, 756, 769, 60, 791, 802, 813, 824, 835, 846, 857, 868, 879, 890, 901, 912, 923, 934, 945, 956, 967, 978, 989, 1000, 1011, 1022, 1033, 1043, 1053, 1061, 1070, 1080, 1090, 1100, 1110, 1119, 1128, 1140, 1152, 1164, 1176, 1188, 1201, 1216, 1231, 1246, 1263, 1280, 1297, 1314, 1334, 1354, 1374, 1398 };
            BusSchedule[3] = new int[time_size] { 338, 366, 391, 411, 431, 449, 461, 471, 481, 491, 501, 511, 519, 527, 534, 541, 548, 556, 564, 572, 580, 588, 596, 605, 615, 625, 635, 645, 655, 665, 676, 687, 698, 709, 720, 731, 742, 753, 764, 777, 68, 799, 810, 821, 832, 843, 854, 865, 876, 887, 898, 909, 920, 931, 943, 954, 965, 976, 987, 998, 1009, 1020, 1031, 1042, 1052, 1062, 1070, 1079, 1089, 1099, 1109, 1118, 1127, 1136, 1148, 1160, 1172, 1184, 1196, 1209, 1224, 1236, 1251, 1268, 1285, 1302, 1319, 1339, 1359, 1379, 1403 };
            BusSchedule[4] = new int[time_size] { 348, 376, 401, 421, 444, 462, 474, 484, 494, 504, 514, 524, 532, 540, 547, 554, 561, 569, 577, 585, 593, 601, 609, 618, 628, 638, 648, 658, 668, 678, 689, 700, 711, 722, 733, 744, 755, 765, 776, 69, 80, 811, 822, 833, 844, 855, 866, 877, 888, 899, 910, 921, 932, 943, 955, 966, 977, 988, 999, 1010, 1021, 1032, 1043, 1054, 1064, 1074, 1082, 1091, 1101, 1111, 1119, 1128, 1137, 1146, 1158, 1170, 1182, 1194, 1206, 1219, 1234, 1244, 1259, 1276, 1293, 1310, 1327, 1347, 1367, 1387, 1411 };
            ///////////////////////////////////////////////////////////////////////////////////////*/
            int[][] BusSchedule = new int[m_TransitSize][];
            // read transit file
            string transit_path = filepath + "Transit_" + filename + ".csv";
            FileStream nwfsInput = new FileStream(transit_path, FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            int bus_stop_size = 0, time_size = 0, stop_count = 0;
            string szSrcLine, subStr;
            int index;
            szSrcLine = nwsrInput.ReadLine();
            szSrcLine = szSrcLine.Trim();
            index = szSrcLine.IndexOf(",");
            int RouteSize = int.Parse(szSrcLine.Substring(index + 1));
            int[] aryStopSize = new int[RouteSize];
            int[] aryTimeSize = new int[RouteSize];
            int line = 0, s = 0, route_count = 0;
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                szSrcLine = szSrcLine.Trim();
                index = szSrcLine.IndexOf(",");
                if (index != -1 && szSrcLine.Substring(0, index) == "Route")
                {
                    stop_count += bus_stop_size;
                    szSrcLine = szSrcLine.Substring(index + 1);
                    szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf(",");
                    szSrcLine = szSrcLine.Substring(index + 1);
                    szSrcLine = szSrcLine.Trim();
                    index = szSrcLine.IndexOf(",");
                    subStr = szSrcLine.Substring(0, index);
                    bus_stop_size = int.Parse(subStr);
                    aryStopSize[route_count] = bus_stop_size;
                    szSrcLine = szSrcLine.Substring(index + 1);
                    time_size = int.Parse(szSrcLine);
                    aryTimeSize[route_count] = time_size;
                    for (int c = 0; c < bus_stop_size; c++)
                    {
                        BusSchedule[stop_count + c] = new int[time_size];
                    }
                    route_count++;
                    line = 0;
                }

                if (index != -1 && line > bus_stop_size) // begin to read schedule
                {
                    s = 0;
                    while (index != -1)
                    {
                        BusSchedule[stop_count + s][line - bus_stop_size - 1] = int.Parse(szSrcLine.Substring(0, index));
                        szSrcLine = szSrcLine.Substring(index + 1);
                        szSrcLine = szSrcLine.Trim();
                        index = szSrcLine.IndexOf(",");
                        s++;
                    }
                    BusSchedule[stop_count + s][line - bus_stop_size - 1] = int.Parse(szSrcLine);
                }

                line++;
            }
            nwsrInput.Close();
            nwfsInput.Close();



            stop_count = 0; route_count = 0; time_size = aryTimeSize[route_count];
            int time_count = 0, temp = aryStopSize[route_count];
            int depart_time = 0, arrival_time = 0;
            double infinit = 80;
            for (l = 0; l < m_LinkSize; l++)
            {
                LinkCost[l] = aryCLink[l].TravelTime;
                LinkCost_Penalty[l] = aryCLink[l].TravelTime;
                LinkList[l, 0] = m_NodeIDtoIndex[aryCLink[l].ToID];
                LinkList[l, 1] = m_NodeIDtoIndex[aryCLink[l].FromID];


                if (aryCLink[l].Link_Type < 9)
                {
                    LinkCost_Fuel[l] = aryCLink[l].Link_Length * Fuel_Rate;
                    for (int i = 0; i < m_TimeIntervalSize; i++)
                    {
                        LinkCost_TimeD[l, i] = aryCLink[l].TravelTime;
                        LinkCost_TimeD_Penalty[l, i] = aryCLink[l].TravelTime;
                    }
                }
                else
                {
                    for (int i = 0; i < m_TimeIntervalSize; i++)
                    {
                        LinkCost_TimeD[l, i] = MAX_COST;
                        LinkCost_TimeD_Penalty[l, i] = MAX_COST;
                    }
                }

                if (aryCLink[l].Link_Type != 9)
                {
                    for (int i = 0; i < m_TimeIntervalTransitSize; i++)
                    {
                        LinkCost_TimeD_Transit[l, i] = aryCLink[l].TravelTime; //take FFTT as the initial values for all time intervals in LinkCost_TimeD
                    }
                }
                else // bus route
                {
                    time_count = 0;
                    depart_time = BusSchedule[stop_count][time_count];
                    arrival_time = BusSchedule[stop_count + 1][time_count];
                    //double e = 0.0;
                    for (int i = 0; i < m_TimeIntervalTransitSize; i++)
                    {
                        if (i <= depart_time && depart_time >= 0 && arrival_time >= 0)
                        {
                            LinkCost_TimeD_Transit[l, i] = arrival_time - i;
                            if (arrival_time - i < 0)
                            {
                                LinkCost_TimeD_Transit[l, i] += m_TimeIntervalTransitSize;
                            }
                            if (i == depart_time)
                            {
                                time_count++;
                                while (time_count < time_size && depart_time == BusSchedule[stop_count][time_count])
                                    time_count++;
                                if (time_count < time_size)
                                {
                                    depart_time = BusSchedule[stop_count][time_count];
                                    arrival_time = BusSchedule[stop_count + 1][time_count];
                                }
                            }
                        }
                        else if (depart_time < 0 || arrival_time < 0)
                        {
                            time_count++;
                            if (time_count < time_size)
                            {
                                depart_time = BusSchedule[stop_count][time_count];
                                arrival_time = BusSchedule[stop_count + 1][time_count];
                            }
                        }
                        else
                        {
                            LinkCost_TimeD_Transit[l, i] = infinit;
                        }
                    }
                    if (stop_count == temp - 2 && route_count < RouteSize - 1)
                    {
                        route_count++;
                        temp += aryStopSize[route_count];
                        stop_count++;
                        time_size = aryTimeSize[route_count];
                    }
                    stop_count++;
                }
            }
            //// load New York Toll information /////////////////////////////
            //if (filename == "NY")
            //{
            //    long[] toll500 = { 21638802, 119955172, 119955177, 31118198, 733067099, 21564515, 21564516, 21564517, 21564518, 119953399, 119953388 };
            //    long[] toll250 = { 21552614, 21552615, 31118346, 31118348, 744672547, 744672549, 21607636, 216076360, 21470277, 214702770 };
            //    long[] toll275 = { 24890284 };
            //    for (int i = 0; i < toll250.Length; i++)
            //        LinkCost_Fuel[m_LinkIDtoIndex[toll250[i]]] += 2.5;
            //    for (int i = 0; i < toll500.Length; i++)
            //        LinkCost_Fuel[m_LinkIDtoIndex[toll500[i]]] += 5.0;
            //    for (int i = 0; i < toll275.Length; i++)
            //        LinkCost_Fuel[m_LinkIDtoIndex[toll275[i]]] += 2.75;
            //}
            /////////////////////////////////////////////////////////////////

            //second generate inbound link array by scanning LinkList, ***based on link index***
            for (l = 0; l < m_LinkSize; l++)
            {
                node_index = LinkList[l, 0];
                InboundLinkAry[node_index, InboundLinkSize[node_index]] = l;
                InboundLinkSize[node_index]++;
            }

            //generate OutgoingLinkAry and OutgoingLinkSize            
            OutgoingLinkAry = new int[m_NodeSize, MaxOutgoingLink];
            OutgoingLinkSize = new int[m_NodeSize];
            //generate outgoing link array by scanning LinkList, ***based on link index***
            for (l = 0; l < m_LinkSize; l++)
            {
                node_index = LinkList[l, 1];
                OutgoingLinkAry[node_index, OutgoingLinkSize[node_index]] = l;
                OutgoingLinkSize[node_index]++;
            }
            int k = 0;
            //find out isolated nodes
            for (l = 0; l < m_NodeSize; l++)
            {
                if (InboundLinkSize[l] == 0 && OutgoingLinkSize[l] == 0)
                    k++;
            }

            //find out the boundary of network                  
            up = aryCNode[0].Node_Lat;
            low = aryCNode[0].Node_Lat;
            left = aryCNode[0].Node_Long;
            right = aryCNode[0].Node_Long;
            double[,] NodeCoordinate = new double[m_NodeSize, 2];
            for (int n = 0; n < m_NodeSize; n++)
            {
                NodeCoordinate[n, 0] = aryCNode[n].Node_Long;
                NodeCoordinate[n, 1] = aryCNode[n].Node_Lat;
                if (NodeCoordinate[n, 0] < left)
                    left = NodeCoordinate[n, 0];
                if (NodeCoordinate[n, 0] > right)
                    right = NodeCoordinate[n, 0];
                if (NodeCoordinate[n, 1] < low)
                    low = NodeCoordinate[n, 1];
                if (NodeCoordinate[n, 1] > up)
                    up = NodeCoordinate[n, 1];
            }

            return true;
        }


        public bool ShortestPath_MultiMode(int mode, int origin, int destination, int DepartureTimeIntervalAllDay, out CRoute MultiModeRoute)
        {
            bool rt;
            double VoT = 0;

            if (mode == 0) //drive only
            {
                rt = ShortestPath_TimeD(origin, destination, DepartureTimeIntervalAllDay, VoT, out MultiModeRoute);
                return rt;
            }

            else if (mode == 1) //walk only
            {
                int[] PredAry;
                bool sp = ShortestPath_Destination(m_NodeIDtoIndex[destination], out PredAry);
                bool gr = GetRoute(true, m_NodeIDtoIndex[origin], m_NodeIDtoIndex[destination], PredAry, VoT, false, 0, out MultiModeRoute);
                MultiModeRoute.PathTime = MultiModeRoute.PathDist / m_WalkingSpeed * 60;
                rt = (sp && gr);
                return rt;
            }

            else if (mode == 2) //transit only
            {
                // walking link
                for (int i = 0; i < m_LinkSize; i++)
                {
                    if (aryCLink[i].Link_Type < 9) //if it's normal driving link, make it to be walking link
                    {
                        for (int j = 0; j < m_TimeIntervalTransitSize; j++)
                        {
                            LinkCost_TimeD_Transit[i, j] = aryCLink[i].TravelTime * 10000;
                        }
                    }
                }
                rt = ShortestPath_TimeD_ParkandRide(origin, destination, DepartureTimeIntervalAllDay, 0, out MultiModeRoute);
                // restore LinkCost_TimeD_Transit                
                for (int l = 0; l < m_LinkSize; l++)
                {
                    if (aryCLink[l].Link_Type < 9)
                    {
                        for (int i = 0; i < m_TimeIntervalTransitSize; i++)
                        {
                            LinkCost_TimeD_Transit[l, i] = aryCLink[l].TravelTime;
                        }
                    }
                }
                // calculate TT and Distance and cost
                MultiModeRoute.PathTime = 0;
                MultiModeRoute.PathDist = 0;
                MultiModeRoute.PathCost = Transit_Cost;
                MultiModeRoute.PathSafety = 1;
                //get travel time
                double Departure_Time = DepartureTimeIntervalAllDay * m_TimeIntervalTransit;
                double curr_Time = Departure_Time;
                int curr_Interval;
                for (int j = 0; j < MultiModeRoute.LinkSeq.Length; j++)
                {
                    curr_Interval = (int)Math.Floor(curr_Time / m_TimeIntervalTransit) % m_TimeIntervalTransitSize;
                    MultiModeRoute.PathTime += LinkCost_TimeD_Transit[MultiModeRoute.LinkSeq[j], curr_Interval];
                    curr_Time += LinkCost_TimeD_Transit[MultiModeRoute.LinkSeq[j], curr_Interval];
                }
                //get distance
                for (int l = 0; l < MultiModeRoute.LinkSeq.Length; l++)
                {
                    if (aryCLink[MultiModeRoute.LinkSeq[l]].Link_Type < 9)
                    {
                        MultiModeRoute.PathDist += aryCLink[MultiModeRoute.LinkSeq[l]].Link_Length;
                    }
                }
                //get safety factor                
                for (int j = 0; j < MultiModeRoute.LinkSeq.Length; j++)
                {
                    MultiModeRoute.PathSafety = MultiModeRoute.PathSafety * (1 - aryCLink[MultiModeRoute.LinkSeq[j]].Safety);
                }
                MultiModeRoute.PathSafety = 1 - MultiModeRoute.PathSafety;


                return rt;
            }

            else if (mode == 3) //Park and ride
            {
                // driving time * 50
                for (int i = 0; i < m_LinkSize; i++)
                {
                    if (aryCLink[i].Link_Type < 9) //if it's normal driving link, make it to be walking link
                    {
                        for (int j = 0; j < m_TimeIntervalTransitSize; j++)
                        {
                            LinkCost_TimeD_Transit[i, j] = aryCLink[i].TravelTime * 1000;
                        }
                    }
                }
                rt = ShortestPath_TimeD_ParkandRide(origin, destination, DepartureTimeIntervalAllDay, 0, out MultiModeRoute);
                // restore LinkCost_TimeD_Transit
                for (int l = 0; l < m_LinkSize; l++)
                {
                    if (aryCLink[l].Link_Type < 9)
                    {
                        for (int i = 0; i < m_TimeIntervalTransitSize; i++)
                        {
                            LinkCost_TimeD_Transit[l, i] = aryCLink[l].TravelTime;
                        }
                    }
                }
                if (rt == false)
                {
                    MultiModeRoute = null;
                    return rt;
                }

                // calculate TT and Distance and cost
                MultiModeRoute.PathTime = 0;
                MultiModeRoute.PathDist = 0;
                MultiModeRoute.PathCost = 0;
                MultiModeRoute.PathSafety = 1;
                //get travel time
                double Departure_Time = DepartureTimeIntervalAllDay * m_TimeIntervalTransit;
                double curr_Time = Departure_Time;
                int curr_Interval;
                for (int j = 0; j < MultiModeRoute.LinkSeq.Length; j++)
                {
                    curr_Interval = (int)Math.Floor(curr_Time / m_TimeIntervalTransit) % m_TimeIntervalTransitSize;
                    MultiModeRoute.PathTime += LinkCost_TimeD_Transit[MultiModeRoute.LinkSeq[j], curr_Interval];
                    curr_Time += LinkCost_TimeD_Transit[MultiModeRoute.LinkSeq[j], curr_Interval];
                }
                //get distance
                for (int l = 0; l < MultiModeRoute.LinkSeq.Length; l++)
                {
                    if (aryCLink[MultiModeRoute.LinkSeq[l]].Link_Type < 9)
                    {
                        MultiModeRoute.PathDist += aryCLink[MultiModeRoute.LinkSeq[l]].Link_Length;
                    }
                }
                //get safety factor                
                for (int j = 0; j < MultiModeRoute.LinkSeq.Length; j++)
                {
                    MultiModeRoute.PathSafety = MultiModeRoute.PathSafety * (1 - aryCLink[MultiModeRoute.LinkSeq[j]].Safety);
                }
                MultiModeRoute.PathSafety = 1 - MultiModeRoute.PathSafety;
                // get cost
                int a = 0;
                int type = aryCLink[MultiModeRoute.LinkSeq[a]].Link_Type;
                while (type != 10)
                {
                    MultiModeRoute.PathCost += LinkCost_Fuel[MultiModeRoute.LinkSeq[a]];
                    a++;
                    if (a >= MultiModeRoute.LinkSeq.Length)
                    {
                        MultiModeRoute = null;
                        return false;
                    }
                    type = aryCLink[MultiModeRoute.LinkSeq[a]].Link_Type;
                }
                MultiModeRoute.PathCost += Transit_Cost;


                return rt;

            }
            else
            {
                MultiModeRoute = null;
                return false;
            }

        }

        public bool ShortestPath_TimeD_ParkandRide(int origin, int destination, int DepartureTimeInterval, double VoT, out CRoute PR_route)
        {
            SEList = new int[m_LinkSize];
            int n;
            //mapping origin and destination from ID to index
            int origin_index = 0;
            int destination_index = 0;
            if (!m_NodeIDtoIndex.TryGetValue(origin, out origin_index) || !m_NodeIDtoIndex.TryGetValue(destination, out destination_index))
            {
                PR_route = null;
                return false;
            }
            //test departure time
            if (DepartureTimeInterval < 0 || DepartureTimeInterval >= m_TimeIntervalTransitSize)
            {
                PR_route = null;
                return false;
            }
            //
            double[,] LabelAry = new double[m_NodeSize, 2]; //Label: arrival time + cost
            double INFINITE = 999999;
            int curr_time_interval;
            double curr_time;
            int[] NodeUpdateStatus = new int[m_NodeSize];//0 not updated; 1 updated
            int[] LinkUpdateStatus = new int[m_LinkSize];//0 not in SEList; 1 in SEList
            int[] PredAry = new int[m_NodeSize];
            for (n = 0; n < m_NodeSize; n++)
            {
                LabelAry[n, 1] = INFINITE; //initial infinite cost
                LabelAry[n, 0] = INFINITE;
                PredAry[n] = -1;
            }

            int To_node_index, From_node_index, link_index, curr_SEList_front;
            bool curr_Update = false;
            SEList_clear();
            //first push back
            for (n = 0; n < OutgoingLinkSize[origin_index]; n++)
            {
                link_index = OutgoingLinkAry[origin_index, n];//outgoing link
                NodeUpdateStatus[LinkList[link_index, 0]] = 0;//
                SEList_push_back(link_index);
                LinkUpdateStatus[link_index] = 1;
            }
            LabelAry[origin_index, 0] = DepartureTimeInterval * m_TimeIntervalTransit;
            LabelAry[origin_index, 1] = 0;
            //double err;
            int[] connector_flag = new int[m_NodeSize];

            while (SEList_front != -1) //Label: arrival time based
            {
                curr_SEList_front = SEList_front;
                To_node_index = LinkList[SEList_front, 0];
                From_node_index = LinkList[SEList_front, 1];
                curr_Update = false;
                curr_time = LabelAry[From_node_index, 0];
                curr_time_interval = ((int)(Math.Floor(curr_time / m_TimeIntervalTransit))) % m_TimeIntervalTransitSize;
                //update label
                if (LinkCost_TimeD_Transit[SEList_front, curr_time_interval] < 0)
                {
                    PR_route = null;
                    return false;
                }
                if (connector_flag[From_node_index] >= 1 && aryCLink[SEList_front].Link_Type < 9) // if ride on bus, then we need change driving_link_cost to walking_link_cost
                {
                    LinkCost_TimeD_Transit[SEList_front, curr_time_interval] = aryCLink[SEList_front].Link_Length / m_WalkingSpeed * 60;
                }
                if (LinkCost_TimeD_Transit[SEList_front, curr_time_interval] + LabelAry[From_node_index, 1] < LabelAry[To_node_index, 1])
                {
                    LabelAry[To_node_index, 1] = LinkCost_TimeD_Transit[SEList_front, curr_time_interval] + LabelAry[From_node_index, 1];
                    LabelAry[To_node_index, 0] = LinkCost_TimeD_Transit[SEList_front, curr_time_interval] + curr_time;
                    PredAry[To_node_index] = From_node_index;
                    curr_Update = true;
                    if (aryCLink[SEList_front].Link_Type == 10) // it's a connector
                    {
                        connector_flag[To_node_index]++;
                    }
                }
                //pop front
                SEList_pop_front();
                LinkUpdateStatus[curr_SEList_front] = 0;
                NodeUpdateStatus[To_node_index] = 1;
                //push in outgoing links of SEList_front to SEList
                if (curr_Update)
                {
                    for (n = 0; n < OutgoingLinkSize[To_node_index]; n++)
                    {
                        link_index = OutgoingLinkAry[To_node_index, n];//outgoing link
                        //if (LinkList[link_index, 1] != LinkList[curr_SEList_front, 0])//do not include the opposite link in direction
                        //{                            
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 0)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_back(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 1)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_front(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }

                        //}
                    }
                }
            }
            if (!GetRoute(false, origin_index, destination_index, PredAry, VoT, true, DepartureTimeInterval, out PR_route))
            {
                PR_route = null;
                return false;
            }

            return true;
        }


        public bool ShortestPath_Pricing(int origin, int destination, double VoT, out CRoute Pricing_route)
        {
            SEList = new int[m_LinkSize];
            int n;
            //mapping origin and destination from ID to index
            int origin_index = 0;
            int destination_index = 0;
            if (!m_NodeIDtoIndex.TryGetValue(origin, out origin_index) || !m_NodeIDtoIndex.TryGetValue(destination, out destination_index))
            {
                Pricing_route = null;
                return false;
            }

            //

            double[] LabelAry = new double[m_NodeSize];
            double INFINITE = 999999;
            int[] NodeUpdateStatus = new int[m_NodeSize];//0 not updated; 1 updated
            int[] LinkUpdateStatus = new int[m_LinkSize];//0 not in SEList; 1 in SEList
            int[] PredAry = new int[m_NodeSize];
            for (n = 0; n < m_NodeSize; n++)
            {
                LabelAry[n] = INFINITE;
                //NodeUpdateStatus[n] = 0;
                PredAry[n] = -1;
            }

            int node_index, link_index, curr_SEList_front;
            bool curr_Update = false;
            SEList_clear();
            //first push back
            for (n = 0; n < OutgoingLinkSize[origin_index]; n++)
            {
                link_index = OutgoingLinkAry[origin_index, n];//outgoing link
                NodeUpdateStatus[LinkList[link_index, 0]] = 0;//
                SEList_push_back(link_index);
                LinkUpdateStatus[link_index] = 1;
            }
            LabelAry[origin_index] = 0;


            while (SEList_front != -1)
            {
                curr_SEList_front = SEList_front;
                node_index = LinkList[SEList_front, 0];
                curr_Update = false;
                //update label
                if (LinkCost_Fuel[SEList_front] < 0)
                {
                    Pricing_route = null;
                    return false;
                }
                if (LinkCost_Fuel[SEList_front] + LinkCost[SEList_front] * VoT + LabelAry[LinkList[SEList_front, 1]] < LabelAry[node_index])
                {
                    LabelAry[node_index] = LinkCost_Fuel[SEList_front] + LinkCost[SEList_front] * VoT + LabelAry[LinkList[SEList_front, 1]];
                    PredAry[node_index] = LinkList[SEList_front, 1];
                    curr_Update = true;
                }
                //pop front
                SEList_pop_front();
                LinkUpdateStatus[curr_SEList_front] = 0;
                NodeUpdateStatus[node_index] = 1;
                //push in outgoing links of SEList_front to SEList
                if (curr_Update)
                {
                    for (n = 0; n < OutgoingLinkSize[node_index]; n++)
                    {
                        link_index = OutgoingLinkAry[node_index, n];//outgoing link
                        //if (LinkList[link_index, 1] != LinkList[curr_SEList_front, 0])//do not include the opposite link in direction
                        //{                            
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 0)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_back(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 1)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_front(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }

                        //}
                    }
                }
            }
            if (!GetRoute(false, origin_index, destination_index, PredAry, VoT, false, 0, out Pricing_route))
            {
                Pricing_route = null;
                return false;
            }

            return true;
        }


        public bool ShortestPath_TimeD_Pricing(int origin, int destination, int DepartureTimeInterval, double VoT, out CRoute Pricing_route)
        {
            SEList = new int[m_LinkSize];
            int n;
            //mapping origin and destination from ID to index
            int origin_index = 0;
            int destination_index = 0;
            if (!m_NodeIDtoIndex.TryGetValue(origin, out origin_index) || !m_NodeIDtoIndex.TryGetValue(destination, out destination_index))
            {
                Pricing_route = null;
                return false;
            }
            //test departure time
            if (DepartureTimeInterval < 0 || DepartureTimeInterval >= m_TimeIntervalSize)
            {
                Pricing_route = null;
                return false;
            }
            //
            double[,] LabelAry = new double[m_NodeSize, 2]; //Label: arrival time + cost
            double INFINITE = 999999;
            int curr_time_interval;
            double curr_time;
            int[] NodeUpdateStatus = new int[m_NodeSize];//0 not updated; 1 updated
            int[] LinkUpdateStatus = new int[m_LinkSize];//0 not in SEList; 1 in SEList
            int[] PredAry = new int[m_NodeSize];
            for (n = 0; n < m_NodeSize; n++)
            {
                LabelAry[n, 1] = INFINITE; //initial infinite cost
                LabelAry[n, 0] = INFINITE;
                PredAry[n] = -1;
            }

            int To_node_index, From_node_index, link_index, curr_SEList_front;
            bool curr_Update = false;
            SEList_clear();
            //first push back
            for (n = 0; n < OutgoingLinkSize[origin_index]; n++)
            {
                link_index = OutgoingLinkAry[origin_index, n];//outgoing link
                NodeUpdateStatus[LinkList[link_index, 0]] = 0;//
                SEList_push_back(link_index);
                LinkUpdateStatus[link_index] = 1;
            }
            LabelAry[origin_index, 0] = DepartureTimeInterval * m_TimeInterval;
            LabelAry[origin_index, 1] = 0;
            //double err;

            while (SEList_front != -1) //Label: arrival time based
            {
                curr_SEList_front = SEList_front;
                To_node_index = LinkList[SEList_front, 0];
                From_node_index = LinkList[SEList_front, 1];
                curr_Update = false;
                curr_time = LabelAry[From_node_index, 0];
                curr_time_interval = ((int)(Math.Floor(curr_time / m_TimeInterval))) % m_TimeIntervalSize;
                //update label
                if (LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] < 0)
                {
                    Pricing_route = null;
                    return false;
                }
                if (LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] * VoT + LinkCost_Fuel[SEList_front] + LabelAry[From_node_index, 1] < LabelAry[To_node_index, 1])
                {
                    LabelAry[To_node_index, 1] = LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] * VoT + LinkCost_Fuel[SEList_front] + LabelAry[From_node_index, 1];
                    LabelAry[To_node_index, 0] = LinkCost_TimeD_Penalty[SEList_front, curr_time_interval] + curr_time;
                    PredAry[To_node_index] = From_node_index;
                    curr_Update = true;
                }
                //pop front
                SEList_pop_front();
                LinkUpdateStatus[curr_SEList_front] = 0;
                NodeUpdateStatus[To_node_index] = 1;
                //push in outgoing links of SEList_front to SEList
                if (curr_Update)
                {
                    for (n = 0; n < OutgoingLinkSize[To_node_index]; n++)
                    {
                        link_index = OutgoingLinkAry[To_node_index, n];//outgoing link
                        //if (LinkList[link_index, 1] != LinkList[curr_SEList_front, 0])//do not include the opposite link in direction
                        //{                            
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 0)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_back(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }
                        if (NodeUpdateStatus[LinkList[link_index, 0]] == 1)
                        {
                            if (LinkUpdateStatus[link_index] == 0)
                            {
                                SEList_push_front(link_index);
                                LinkUpdateStatus[link_index] = 1;
                            }
                        }

                        //}
                    }
                }
            }
            if (!GetRoute(false, origin_index, destination_index, PredAry, VoT, true, DepartureTimeInterval, out Pricing_route))
            {
                Pricing_route = null;
                return false;
            }

            return true;
        }




        // Map Matching Function
        //TODO: move the function to a seperated class
        public double m_GPSError = 0.093; //GPS error range is 0.093 mile = 150 meter

        /// <summary>
        /// map matching function
        /// </summary>
        /// <param name="mmrq">map matching request</param>
        /// <returns>map matching response</returns>
        public CMapMatchingResponse MapMatching(CMapMatchingRequest mmrq)
        {
            //time calculation
            DateTime[] TimeCalculate = new DateTime[4];
            TimeCalculate[0] = DateTime.Now;
            double time = 0;

            CMapMatchingResponse mmrp = new CMapMatchingResponse();
            Dictionary<int, int> node_list = new Dictionary<int, int>();
            Dictionary<int, int> link_list = new Dictionary<int, int>();
            double INFINITE = 9999;
            double link_range = 1;
            double temp = 0;
            int temp_link = 0;
            int count = 0;
            //generate base network//////////////////////
            //create a list of gps point every link_range miles
            int[] gps_milestone = new int[mmrq.gps_trace.Length];
            int gps_milestone_size = 0;
            gps_milestone[gps_milestone_size] = 0; //add the first gps point to the list
            gps_milestone_size++;
            for (int g = 1; g < mmrq.gps_trace.Length; g++)
            {
                if (GPSPointToPointDistPower(mmrq.gps_trace[gps_milestone[gps_milestone_size - 1]], mmrq.gps_trace[g]) >= Math.Pow(link_range, 2))
                {
                    gps_milestone[gps_milestone_size] = g;
                    gps_milestone_size++;
                }
            }
            // search nearby nodes for all points in the 5-mile-point list, when do long-distance map-matching            
            for (int n = 0; n < m_NodeSize; n++)
            {
                for (int g = 0; g < gps_milestone_size; g++)
                {
                    temp = PointToNodeDistPower(mmrq.gps_trace[gps_milestone[g]], n);
                    if (temp > 0 && temp < Math.Pow(link_range, 2)) //node should be within link_range mile distance 
                    {
                        node_list.Add(count, n);
                        count++;
                        break;
                    }
                }
            }
            /////////////////////////////////////////////
            if (node_list == null || node_list.Count == 0)
                return null;
            count = 0;
            for (int n = 0; n < node_list.Count; n++)
            {
                // Add links for nearby area: just outgoing links and no "Contain check"
                for (int i = 0; i < OutgoingLinkSize[node_list[n]]; i++)
                {
                    temp_link = OutgoingLinkAry[node_list[n], i];
                    link_list.Add(count, temp_link);
                    count++;
                }
            }
            // add all links longer than link_range to the list
            for (int l = 0; l < m_LinkSize; l++)
            {
                if (aryCLink[l].Link_Length > link_range)
                {
                    link_list.Add(count, l);
                    count++;
                }
            }
            if (link_list == null || link_list.Count == 0)
                return null;
            TimeCalculate[1] = DateTime.Now;
            time = TimeCalculate[1].TimeOfDay.TotalSeconds - TimeCalculate[0].TimeOfDay.TotalSeconds;
            //time = (double)(int)(time * 10) / 10;
            Console.WriteLine("network prepare time used: " + time.ToString() + "seconds \n");
            //update LinkCost_Penalty and find OD links
            int origin_link = -1, destination_link = -1;
            double origin_dist = 5, destination_dist = 5;

            for (int l = 0; l < m_LinkSize; l++)
                LinkCost_Penalty[l] = INFINITE * aryCLink[l].Link_Length;
            //METHOD ONE: curve-to-curve link cost
            double min_usn_dist, min_dsn_dist, min_link_dist;
            double temp_usn_dist, temp_dsn_dist, temp_link_dist;
            for (int l = 0; l < link_list.Count; l++)
            {
                min_usn_dist = 5; min_dsn_dist = 5; min_link_dist = 5;
                for (int g = 0; g < mmrq.gps_trace.Length; g++)
                {
                    temp_link_dist = PointToLinkDist(mmrq.gps_trace[g], link_list[l], out temp_usn_dist, out temp_dsn_dist);
                    if (temp_link_dist > 0 && temp_usn_dist > 0 && temp_dsn_dist > 0)
                    {
                        if (g == 0 && temp_link_dist < origin_dist)
                        {
                            double link_tan = Math.Atan((aryCNode[LinkList[link_list[l], 0]].Node_Lat - aryCNode[LinkList[link_list[l], 1]].Node_Lat) /
                                                            (aryCNode[LinkList[link_list[l], 0]].Node_Long - aryCNode[LinkList[link_list[l], 1]].Node_Long));
                            if (aryCNode[LinkList[link_list[l], 0]].Node_Long < aryCNode[LinkList[link_list[l], 1]].Node_Long)
                                link_tan += 3.14;
                            double gps_tan = Math.Atan((mmrq.gps_trace[4].Lat - mmrq.gps_trace[0].Lat) / (mmrq.gps_trace[4].Long - mmrq.gps_trace[0].Long));
                            if (mmrq.gps_trace[4].Long < mmrq.gps_trace[0].Long)
                                gps_tan += 3.14;

                            double angle_diff = Math.Abs(link_tan - gps_tan);
                            if (angle_diff < 3.14 / 2 && (temp_link_dist + angle_diff * 5) < origin_dist)
                            {
                                origin_dist = temp_link_dist;
                                origin_link = link_list[l];
                            }
                        }
                        if (g == mmrq.gps_trace.Length - 1 && temp_link_dist < destination_dist)
                        {
                            double link_tan = Math.Atan((aryCNode[LinkList[link_list[l], 0]].Node_Lat - aryCNode[LinkList[link_list[l], 1]].Node_Lat) /
                                                            (aryCNode[LinkList[link_list[l], 0]].Node_Long - aryCNode[LinkList[link_list[l], 1]].Node_Long));
                            if (aryCNode[LinkList[link_list[l], 0]].Node_Long < aryCNode[LinkList[link_list[l], 1]].Node_Long)
                                link_tan += 3.14;
                            double gps_tan = Math.Atan((mmrq.gps_trace[mmrq.gps_trace.Length - 1].Lat - mmrq.gps_trace[mmrq.gps_trace.Length - 3].Lat) /
                                                            (mmrq.gps_trace[mmrq.gps_trace.Length - 1].Long - mmrq.gps_trace[mmrq.gps_trace.Length - 3].Long));
                            if (mmrq.gps_trace[mmrq.gps_trace.Length - 1].Long < mmrq.gps_trace[mmrq.gps_trace.Length - 3].Long)
                                gps_tan += 3.14;

                            double angle_diff = Math.Abs(link_tan - gps_tan);
                            if (angle_diff < 3.14 / 2 && (temp_link_dist + angle_diff * 5) < destination_dist)
                            {
                                destination_dist = temp_link_dist;
                                destination_link = link_list[l];
                            }
                        }
                        if (temp_link_dist <= min_link_dist)
                            min_link_dist = temp_link_dist;
                        if (temp_usn_dist <= min_usn_dist)
                            min_usn_dist = temp_usn_dist;
                        if (temp_dsn_dist <= min_dsn_dist)
                            min_dsn_dist = temp_dsn_dist;
                    }
                }
                LinkCost_Penalty[link_list[l]] = (min_usn_dist + min_dsn_dist + min_link_dist) / 3;
            }

            //METHOD TWO: gps point density based link cost
            //double temp_dist = 0;
            //for (int l = 0; l < link_list.Count; l++)
            //{
            //    for (int g = 0; g < mmrq.gps_trace.Length; g++)
            //    {
            //        temp_dist = PointToLinkDist(mmrq.gps_trace[g], link_list[l]);
            //        if (temp_dist > 0)
            //        {
            //            if (g == 0 && temp_dist < origin_dist)
            //            {
            //                origin_dist = temp_dist;
            //                origin_link = link_list[l];
            //            }
            //            if (g == mmrq.gps_trace.Length - 1 && temp_dist < destination_dist)
            //            {
            //                destination_dist = temp_dist;
            //                destination_link = link_list[l];
            //            }
            //            if (temp_dist <= m_GPSError)
            //                LinkCost_Penalty[link_list[l]] = LinkCost_Penalty[link_list[l]] * (temp_dist / m_GPSError);
            //        }
            //    }
            //}
            //find OD nodes
            if (origin_link == destination_link)
            {
                if (origin_link == -1)
                    return null;
                else
                {
                    Bitmap bm = Draw(0, 5000, mmrq.gps_trace, new int[] { origin_link, destination_link });
                    bm.Save(@"D:\DATA\Map-Matching\img_error.bmp");
                    int[] LinkSeq = { origin_link };
                    mmrp = new CMapMatchingResponse(LinkSeq);
                    return mmrp;
                }
            }
            int[,] OD_pairs = { { LinkList[origin_link, 1], LinkList[destination_link, 1] }, 
                                { LinkList[origin_link, 0], LinkList[destination_link, 1] },
                                { LinkList[origin_link, 1], LinkList[destination_link, 0] },
                                { LinkList[origin_link, 0], LinkList[destination_link, 0] } };
            TimeCalculate[2] = DateTime.Now;
            time = TimeCalculate[2].TimeOfDay.TotalSeconds - TimeCalculate[1].TimeOfDay.TotalSeconds;
            Console.WriteLine("add penalty time used: " + time.ToString() + "seconds \n");

            //using shortest path function and get route
            int[] PredAry;
            CRoute[] routes = new CRoute[4];
            for (int i = 0; i < 4; i++)
            {
                // check the outgoing/incoming link availability for O/D nodes
                if (OutgoingLinkSize[OD_pairs[i, 0]] > 0 && InboundLinkSize[OD_pairs[i, 1]] > 0)
                {
                    //ShortestPath_Destination(m_NodeIndextoID[OD_pairs[i, 1]], out PredAry);
                    //GetRoute(true, OD_pairs[i, 0], OD_pairs[i, 1], PredAry, 0, false, 0, out routes[i]);
                    double route_length = Math.Sqrt(GPSPointToPointDistPower(mmrq.gps_trace[0], mmrq.gps_trace[mmrq.gps_trace.Length - 1]));
                    ShortestPath_Origin(OD_pairs[i, 0], INFINITE * route_length * 5, out PredAry);
                    GetRoute(false, OD_pairs[i, 0], OD_pairs[i, 1], PredAry, 0, false, 0, out routes[i]);
                }
                if (routes[i] != null)
                {
                    int link_size = routes[i].LinkSeq.Length;
                    if (routes[i].LinkSeq[0] == origin_link && routes[i].LinkSeq[link_size - 1] == destination_link) // means the route includes both origin link and destination link
                    {
                        mmrp = new CMapMatchingResponse(routes[i].LinkSeq);
                        TimeCalculate[3] = DateTime.Now;
                        time = TimeCalculate[3].TimeOfDay.TotalSeconds - TimeCalculate[2].TimeOfDay.TotalSeconds;
                        //time = (double)(int)(time * 10) / 10;
                        Console.WriteLine("shortest path calculation time used: " + time.ToString() + "seconds \n");
                        for (int c = 0; c < routes[i].LinkSeq.Length; c++)
                            Console.WriteLine(routes[i].LinkSeq[c] + "  ID: " + aryCLink[routes[i].LinkSeq[c]].ID.ID);
                        //draw the map and gps points
                        Bitmap bm = Draw(0, 1000, mmrq.gps_trace, routes[i].LinkSeq);
                        bm.Save(@"D:\DATA\Map-Matching\img2.bmp");
                        return mmrp;
                    }
                }
            }
            int x = 3;
            if (routes[x] == null)
            {
                Bitmap bm = Draw(0, 5000, mmrq.gps_trace, new int[] { origin_link, destination_link });
                bm.Save(@"D:\DATA\Map-Matching\img_error.bmp");
                return null;
            }
            mmrp = new CMapMatchingResponse(routes[x].LinkSeq);
            TimeCalculate[3] = DateTime.Now;
            time = TimeCalculate[3].TimeOfDay.TotalSeconds - TimeCalculate[2].TimeOfDay.TotalSeconds;
            //time = (double)(int)(time * 10) / 10;
            Console.WriteLine("shortest path calculation time used: " + time.ToString() + "seconds \n");
            for (int c = 0; c < routes[x].LinkSeq.Length; c++)
                Console.WriteLine(routes[x].LinkSeq[c] + "  ID: " + aryCLink[routes[x].LinkSeq[c]].ID.ID);
            //draw the map and gps points
            Bitmap bm0 = Draw(0, 5000, mmrq.gps_trace, routes[x].LinkSeq);
            bm0.Save(@"D:\DATA\Map-Matching\img.bmp");
            return mmrp;
        }

        /// <summary>
        /// calculate the distance (in mile) between a gps point and a link
        /// </summary>
        /// <param name="gps_point">a gps point</param>
        /// <param name="link_index">the index of link</param>
        /// <returns>return the distance in mile; return -1 if invalid result or the gps point is out of the link range</returns>
        public double PointToLinkDist(CgpsTrace gps_point, int link_index)
        {
            double Dist_GpsToFromNode, Dist_GpsToToNode;
            Dist_GpsToFromNode = Math.Sqrt(PointToNodeDistPower(gps_point, m_NodeIDtoIndex[aryCLink[link_index].FromID]));
            Dist_GpsToToNode = Math.Sqrt(PointToNodeDistPower(gps_point, m_NodeIDtoIndex[aryCLink[link_index].ToID]));

            if (Dist_GpsToFromNode < 0 || Dist_GpsToToNode < 0)
                return -1;
            double link_length = aryCLink[link_index].Link_Length;
            //using Heron's formula
            double Dist_PointToLink = Math.Sqrt(2 * (Dist_GpsToFromNode + Dist_GpsToToNode + link_length) * (Dist_GpsToFromNode + Dist_GpsToToNode)
                                        * (Dist_GpsToToNode + link_length) * (Dist_GpsToFromNode + link_length)) / link_length;
            if (Math.Pow(Dist_GpsToFromNode, 2) + Math.Pow(Dist_GpsToToNode, 2) - 2 * Math.Pow(Dist_PointToLink, 2) > Math.Pow(link_length, 2))
                return -1;
            else
                return Dist_PointToLink;
        }

        /// <summary>
        /// calculate the distance (in mile) between a gps point and a link, with additional output
        /// </summary>
        /// <param name="gps_point">a gps point</param>
        /// <param name="link_index">the index of link</param>
        /// <param name="Dist_GpsToFromNode">additional output: the distance between gps point and FromNode</param>
        /// <param name="Dist_GpsToToNode">additional output: the distance between gps point and ToNode</param>
        /// <returns>return the distance in mile; return -1 if invalid result or the gps point is out of the link range</returns>
        public double PointToLinkDist(CgpsTrace gps_point, int link_index, out double Dist_GpsToFromNode, out double Dist_GpsToToNode)
        {
            Dist_GpsToFromNode = Math.Sqrt(PointToNodeDistPower(gps_point, m_NodeIDtoIndex[aryCLink[link_index].FromID]));
            Dist_GpsToToNode = Math.Sqrt(PointToNodeDistPower(gps_point, m_NodeIDtoIndex[aryCLink[link_index].ToID]));

            if (Dist_GpsToFromNode < 0 || Dist_GpsToToNode < 0)
                return -1;
            double link_length = aryCLink[link_index].Link_Length;
            //using Heron's formula
            double Dist_PointToLink = Math.Sqrt(2 * (Dist_GpsToFromNode + Dist_GpsToToNode + link_length) * (Dist_GpsToFromNode + Dist_GpsToToNode)
                                        * (Dist_GpsToToNode + link_length) * (Dist_GpsToFromNode + link_length)) / link_length;
            if (Math.Pow(Dist_GpsToFromNode, 2) + Math.Pow(Dist_GpsToToNode, 2) - 2 * Math.Pow(Dist_PointToLink, 2) > Math.Pow(link_length, 2))
                return -1;
            else
                return Dist_PointToLink;
        }

        /// <summary>
        /// calculate the power of distance (in mile) between a GPS point and a node
        /// </summary>
        /// <param name="gps_point">a GPS point</param>
        /// <param name="node_index">the index of node</param>
        /// <returns>return the power of distance (in mile) between a GPS point and a node, return -1 if they are not in the same UTM zone</returns>
        public double PointToNodeDistPower(CgpsTrace gps_point, int node_index)
        {
            if (gps_point.utm_zone != aryCNode[node_index].Node_UTM_Zone)
                return -1;
            double dist_power = Math.Pow(gps_point.east - aryCNode[node_index].Node_UTM_Easting, 2)
                                    + Math.Pow(gps_point.north - aryCNode[node_index].Node_UTM_Northing, 2);
            // dist is in meter ====== transfer to mile
            dist_power = dist_power * 0.38613796 / 1000000;
            return dist_power;
        }

        /// <summary>
        /// calculate the power of distance (in mile) between two GPS points 
        /// </summary>
        /// <param name="gps_point_a">a GPS point</param>
        /// <param name="gps_point_b">the other GPS point</param>
        /// <returns>return the power of distance (in mile) between two GPS points, return -1 if they are not in the same UTM zone</returns>
        public double GPSPointToPointDistPower(CgpsTrace gps_point_a, CgpsTrace gps_point_b)
        {
            if (gps_point_a.utm_zone != gps_point_b.utm_zone)
                return -1;
            double dist_power = Math.Pow(gps_point_a.east - gps_point_b.east, 2)
                                    + Math.Pow(gps_point_a.north - gps_point_b.north, 2);
            // dist is in meter ====== transfer to mile
            dist_power = dist_power * 0.38613796 / 1000000;
            return dist_power;
        }

        public CNetwork CreateSubNetwork(CMapMatchingRequest mmrq)
        {
            CNetwork subNetwork = new CNetwork();

            subNetwork.Analysis_Network("sub");
            return subNetwork;
        }


        public bool ReliablePath(int origin_index, int destination_index)
        {
            int origin = m_NodeIndextoID[origin_index], destination = m_NodeIndextoID[destination_index];
            TextWriter log = new StreamWriter(city + "_log.txt");
            //log.WriteLine("primal \t dual \t mu \t var \t y \t path \t stepsize");
            log.WriteLine("TT\tprimal\tp_mu\tdual\td_mu\tgap\teva_p\tp_mu\teva_d\td_mu\teva_gap\tprimal_quality\tO\tD");

            // Load historical data
            double[] day_MeanVar;
            LoadHistData_CSV("9am", out day_MeanVar);

            #region
            // small sample network
            /*
            double[] variance = new double[3] { 0, 49, 4 }; 
            Random rdm = new Random(123);
            for (int l = 0; l < aryCLink.Length; l++ )
            {
                // aryCLink[l].Link_Variance = variance[l]; // small sample network
                // generate reliability data: SD per mile = 0.8402ln(x) + 0.1387, x is the travel min per mile 
                //aryCLink[l].Link_Variance = Math.Pow((0.8402 * Math.Log(aryCLink[l].Link_FFTT / aryCLink[l].Link_Length) + 0.1387) * aryCLink[l].Link_Length, 2);
                aryCLink[l].Link_Variance = Math.Pow(rdm.NextDouble() * aryCLink[l].Link_FFTT * 10, 2);
            }

            double[][] sample = new double[4][];
            sample[0] = new double[4] { 2, 1, 2, 2 };
            sample[1] = new double[4] { 1, 2, 1, 2 };
            sample[2] = new double[4] { 2, 2, 1, 1 };
            sample[3] = new double[4] { 2, 2, 1, 1 };
             * */
            #endregion
            DateTime start_time, end_time;
            int count = 0;
            int[] PredAry;
            CRoute route = new CRoute();
            double beta = 1.27, lambda = 0.5, UB = 0;
            double mu = 0.01;
            double stepsize = 0;
            double e = 0.00001;
            double y_max = 0, y = 0;
            string str_route = "";
            double primal = 0, dual = 0;
            int iteration = 0, max_iteration = 20;
            double opt_dual = 0, opt_primal = 10000, opt_mu_primal = 0, opt_mu_dual = 0;
            int[] ary_origin = new int[246], ary_dest = new int[246];
            //read OD pairs/////////////////////////////////////////
            FileStream nwfsInput = new FileStream(@"netdata/OD.csv", FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine = "", subStr = "";
            int index = 0, line = 0;
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                count = 0;
                szSrcLine = szSrcLine.Trim();
                while (szSrcLine.IndexOf(",") != -1)
                {
                    index = szSrcLine.IndexOf(",");
                    subStr = szSrcLine.Substring(0, index);
                    if (count == 0)
                        ary_origin[line] = int.Parse(subStr);
                    else if (count == 1)
                        ary_dest[line] = int.Parse(subStr);
                    count++;
                    szSrcLine = szSrcLine.Substring(index + 1);
                }
                line++;
            }
            nwsrInput.Close();
            nwfsInput.Close();
            ////////////////////////////////////////////////////////

            start_time = DateTime.Now;
            for (int k = 0; k < 246; k++)
            {
                iteration = 0; y_max = 0; UB = 0; mu = 0.001; lambda = 0.5;
                opt_dual = 0; opt_primal = 10000;
                //origin_index = (origin_index + 100) % m_NodeSize;
                //destination_index = (destination_index + 100) % m_NodeSize;
                //origin = m_NodeIndextoID[origin_index]; destination = m_NodeIndextoID[destination_index];
                origin = ary_origin[k]; destination = ary_dest[k];
                origin_index = m_NodeIDtoIndex[origin]; destination_index = m_NodeIDtoIndex[destination];
                // find y_max and UB
                LinkCost.CopyTo(LinkCost_Penalty, 0); // restore link cost array
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);

                //if (route != null && route.PathTime >= 45)
                //////////////////////////////////////////////
                {
                    // find UB and ymax
                    for (int l = 0; l < route.LinkSeq.Length; l++)
                    {
                        UB += LinkCost[route.LinkSeq[l]];
                        y_max += aryCLink[route.LinkSeq[l]].TTVariance;
                    }
                    UB += beta * Math.Sqrt(y_max);
                    // y_max = y_max * 0.9;
                    log.Write(Math.Round(route.PathTime, 2) + "\t");

                    ////////////////////////////////////////////////////////
                    // find primal and dual
                    do
                    {
                        primal = 0; dual = 0; str_route = "";
                        // assign link cost
                        for (int l = 0; l < m_LinkSize; l++)
                        {
                            LinkCost_Penalty[l] = LinkCost[l] + mu * aryCLink[l].TTVariance;
                        }
                        // do shortest path search, find path
                        if (ShortestPath_Destination(destination_index, out PredAry))
                            GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                        else
                            break;
                        // find y
                        if (beta * Math.Sqrt(y_max) - mu * y_max > 0)
                            y = 0;
                        else
                            y = y_max;
                        // calculate primal and dual function value
                        double total_var = 0;
                        for (int l = 0; l < route.LinkSeq.Length; l++)
                        {
                            primal += LinkCost[route.LinkSeq[l]];
                            total_var += aryCLink[route.LinkSeq[l]].TTVariance;
                            dual += LinkCost_Penalty[route.LinkSeq[l]];
                            str_route += aryCLink[route.LinkSeq[l]].ID.ID.ToString() + ",";
                        }
                        primal += beta * Math.Sqrt(total_var);
                        dual += (beta * Math.Sqrt(y) - mu * y);

                        if (dual > UB)
                            UB = dual;

                        // find optimal
                        if (dual >= opt_dual)
                        {
                            opt_dual = dual;
                            opt_mu_dual = mu;
                        }
                        if (primal <= opt_primal)
                        {
                            opt_primal = primal;
                            opt_mu_primal = mu;
                        }

                        // output
                        //log.WriteLine(Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(mu, 3) + "\t" + Math.Round(total_var, 3) + "\t" + Math.Round(y, 3)
                        //    + "\t" + route.PathTime + "\t" + stepsize);
                        //Console.WriteLine(Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(mu, 3)
                        //    + "\t" + str_route + "\t" + Math.Round(stepsize, 3));

                        // calculate mu(k+1)
                        double temp = 0;
                        temp = Math.Pow(total_var - y, 2);

                        if (temp == 0)
                            temp = 0.0000001;
                        lambda = 1 / (1 / lambda + 1); // lambda = 1 / ((double)iteration + 1);
                        stepsize = lambda * (UB - dual) * (total_var - y) / temp;
                        if (stepsize == 0)
                        {
                            lambda = 0.5;
                            stepsize = lambda;
                        }
                        mu += stepsize;
                        // mu += 0.1;
                        if (mu < 0)
                            mu = 0;

                        iteration++;
                    }
                    while (iteration < max_iteration);
                    log.Write(Math.Round(opt_primal, 3) + "\t" + Math.Round(opt_mu_primal, 3) + "\t" + Math.Round(opt_dual, 3) + "\t" + Math.Round(opt_mu_dual, 3)
                        + "\t" + Math.Round(1 - opt_dual / opt_primal, 4) + "\n");

                    //log.WriteLine("\n");
                    //log.WriteLine("UB: " + UB + "\t y max: " + y_max + "\t mu bound: " + 1 / Math.Sqrt(y_max) + "\t Opt Dual: " + Math.Round(opt_dual, 3)
                    //    + "\t Opt Dual Mu: " + Math.Round(opt_mu_dual, 3) + "\t Opt Primal: " + Math.Round(opt_primal, 3) + "\t Opt Primal Mu: " + Math.Round(opt_mu_primal, 3) + "\n");
                    // generate reliability data: SD per mile = 0.8402ln(x) + 0.1387, x is the travel min per mile 

                    /*///////////////////////////////////////////////////////
                    // evaluation: use grid search to find minimum of primal
                    int eva_max_iteration = 100;
                    double eva_opt_dual = 0, eva_opt_primal = 10000, eva_opt_mu_primal = 0, eva_opt_mu_dual = 0;
                    iteration = 0; mu = 0;
                    do
                    {
                        primal = 0; dual = 0; str_route = "";
                        // assign link cost
                        for (int l = 0; l < m_LinkSize; l++)
                        {
                            LinkCost_Penalty[l] = LinkCost[l] + mu * aryCLink[l].TTVariance;
                        }
                        // do shortest path search, find path
                        if (ShortestPath_Destination(destination, out PredAry))
                            GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                        else
                            break;
                        // find y
                        if (beta * Math.Sqrt(y_max) - mu * y_max > 0)
                            y = 0;
                        else
                            y = y_max;
                        // calculate primal and dual function value
                        double total_var = 0;
                        for (int l = 0; l < route.LinkSeq.Length; l++)
                        {
                            primal += LinkCost[route.LinkSeq[l]];
                            total_var += aryCLink[route.LinkSeq[l]].TTVariance;
                            dual += LinkCost_Penalty[route.LinkSeq[l]];
                            str_route += aryCLink[route.LinkSeq[l]].ID.ID.ToString() + ",";
                        }
                        primal += beta * Math.Sqrt(total_var);
                        dual += (beta * Math.Sqrt(y) - mu * y);

                        if (dual > UB)
                            UB = dual;

                        // find optimal
                        if (dual >= eva_opt_dual)
                        {
                            eva_opt_dual = dual;
                            eva_opt_mu_dual = mu;
                        }
                        if (primal <= eva_opt_primal)
                        {
                            eva_opt_primal = primal;
                            eva_opt_mu_primal = mu;
                        }

                        // output
                        //log.WriteLine(Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(mu, 3) + "\t" + Math.Round(total_var, 3) + "\t" + Math.Round(y, 3)
                        //    + "\t" + route.PathTime + "\t" + stepsize);
                        //Console.WriteLine(Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(mu, 3)
                        //    + "\t" + str_route + "\t" + Math.Round(stepsize, 3));

                        mu += 0.01;

                        iteration++;
                    }
                    while (iteration < eva_max_iteration);
                    log.Write(Math.Round(eva_opt_primal, 3) + "\t" + Math.Round(eva_opt_mu_primal, 3) + "\t" + Math.Round(eva_opt_dual, 3) + "\t" + Math.Round(eva_opt_mu_dual, 3)
                        + "\t" + Math.Round(1 - eva_opt_dual / eva_opt_primal, 3) + "\t" + Math.Round(eva_opt_primal / opt_primal, 3) + "\t" + origin + "\t" + destination + "\n");
                    ///////////////////////////////////////////////////////////////*/
                }
            }
            end_time = DateTime.Now;
            log.Close();
            return true;
        }

        public bool draw()
        {
            //// test/////////////////////////////////////////
            //int[] Origin = new int[10];// { 49553, 151094, 144842, 136054, 66486, 81425, 140124, 92225, 1629, 198842 };
            //int[] Dest = new int[10];// { 65616, 15843, 12310, 96413, 21513, 167667, 151766, 143867, 77792, 149992 };
            //double[] o_Lat = new double[] { 37.27716, 37.81234, 37.70825, 38.14645, 37.71567, 37.51311, 37.82154, 37.90178, 37.35696, 37.37854 };
            //double[] o_Log = new double[] { -122.00718, -122.30308, -122.40526, -122.21658, -122.39911, -122.33108, -122.29766, -122.30563, -121.84681, -122.06846 };
            //double[] d_Lat = new double[] { 37.75044, 37.36404, 37.29196, 37.74277, 37.36209, 37.83235, 37.4447, 37.48416, 37.70501, 37.83723 };
            //double[] d_Log = new double[] { -122.4028, -121.90178, -122.01545, -122.17389, -121.8548, -121.98233, -122.16904, -122.22885, -122.46958, -122.26215 };
            //for (int l = 0; l < 10; l++)
            //{
            //    Origin[l] = FindClosestNode(o_Lat[l], o_Log[l]);
            //    Dest[l] = FindClosestNode(d_Lat[l], d_Log[l]);
            //    //o_Lat[l] = aryCNode[m_NodeIDtoIndex[Origin[l]]].Node_Lat;
            //    //o_Log[l] = aryCNode[m_NodeIDtoIndex[Origin[l]]].Node_Long;
            //    //d_Lat[l] = aryCNode[m_NodeIDtoIndex[Dest[l]]].Node_Lat;
            //    //d_Log[l] = aryCNode[m_NodeIDtoIndex[Dest[l]]].Node_Long;
            //}
            ////////////////////////////////////////////////

            int[] BestSensor = new int[] { 1, 2, 10, 30 };
            double[] day_MeanVar;
            LoadHistData_CSV("9am", out day_MeanVar);
            //Bitmap bmp = DrawSensor(2000, BestSensor, BestSensor);
            Bitmap bmp = demo_1(2000);
            DateTime time = DateTime.Now;
            string filename = time.Minute.ToString() + "_img.bmp";
            bmp.Save(filename);
            bmp.Dispose();

            return true;
        }

        public bool ReliablePath_Sampling(int origin_index, int destination_index)
        {
            int origin = m_NodeIndextoID[origin_index], destination = m_NodeIndextoID[destination_index];
            TextWriter log = new StreamWriter(city + "_Sampling_log.txt");
            //log.WriteLine("primal \t dual \t mu \t var \t y \t path \t stepsize");
            log.WriteLine("TT\tprimal\tdual\tgap\teva_p\teva_d\teva_gap\tprimal_quality\tO\tD");

            // Load historical data            
            double[] day_MeanVar;
            LoadHistData_CSV("9am", out day_MeanVar);
            //LoadHistData_CSV("9am_Demo");

            DateTime start_time, end_time;
            int day_size = TMCHistSpd.GetLength(1);
            int tmc_index = 0, tmc_size = TMCHistSpd.GetLength(0);
            double tt = 0, var = 0, length = 0, spd = 0, MeanTTvar = 0;
            int count = 0;
            int[] PredAry;
            CRoute route = new CRoute();
            double UB = 0, beta = 1.27; // 4; // 1.27;
            double[] mu = new double[day_size], stepsize_mu = new double[day_size], lambda_mu = new double[day_size];
            double nu = 0.01, stepsize_nu = 0, lambda_nu = 0.5;
            double y_max = 0, y = 0;
            double[] w = new double[day_size];
            double[] day_cost = new double[day_size];
            double average_cost = 0;

            string str_route = "", opt_str_route = "";
            double primal = 0, dual = 0, gap = 0;
            int iteration = 0, max_iteration = 10;
            double opt_dual = 0, opt_primal = 10000, opt_gap = 10000;
            double initial = 0.0001;
            double coverage = 0;
            Random rdm = new Random(123);
            double[] ary_dual = new double[max_iteration];
            //read OD pairs/////////////////////////////////////////
            int[] ary_origin = new int[246], ary_dest = new int[246];
            FileStream nwfsInput = new FileStream(@"netdata/OD.csv", FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine = "", subStr = "";
            int index = 0, line = 0;
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                count = 0;
                szSrcLine = szSrcLine.Trim();
                while (szSrcLine.IndexOf(",") != -1)
                {
                    index = szSrcLine.IndexOf(",");
                    subStr = szSrcLine.Substring(0, index);
                    if (count == 0)
                        ary_origin[line] = int.Parse(subStr);
                    else if (count == 1)
                        ary_dest[line] = int.Parse(subStr);
                    count++;
                    szSrcLine = szSrcLine.Substring(index + 1);
                }
                line++;
            }
            nwsrInput.Close();
            nwfsInput.Close();
            ////////////////////////////////////////////////////////
            /*for (int k = 0; k < 1000; k++)
            {
                iteration = 0; lambda_nu = 0.01; nu = initial;
                coverage = 0;
                for (int d = 0; d < day_size; d++)
                {
                    mu[d] = initial / day_size;
                    lambda_mu[d] = 0.01;
                }
                opt_dual = 0; opt_primal = 10000; opt_gap = 10000; opt_str_route = "";
                origin_index = (origin_index + 100) % m_NodeSize;
                destination_index = (destination_index + 100) % m_NodeSize;
                //origin_index = (int)(rdm.NextDouble() * (m_NodeSize - 1));
                //destination_index = (int)(rdm.NextDouble() * (m_NodeSize - 1));
                //origin = m_NodeIndextoID[origin_index]; destination = m_NodeIndextoID[destination_index];
                // find y_max and UB
                LinkCost.CopyTo(LinkCost_Penalty, 0);
                if (ShortestPath_Destination(destination, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);

                if (route != null && route.PathTime >= 45)
                {
                    double c = 0;
                    for (int l = 0; l < route.LinkSeq.Length; l++)
                        if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                            c += aryCLink[route.LinkSeq[l]].Link_Length;
                    coverage = c / route.PathDist;
                }

                if (coverage > 0.3)
            */
            start_time = DateTime.Now;
            for (int k = 24; k < 50; k++) //246
            {
                //log.Close();
                //log = new StreamWriter(city + "_Sampling_log.txt"); // new log

                iteration = 0; lambda_nu = 0.01; nu = 0.1;
                coverage = 0;
                for (int d = 0; d < day_size; d++)
                {
                    mu[d] = 1.0 / day_size;
                    lambda_mu[d] = 0.01;
                }
                opt_dual = 0; opt_primal = 10000; opt_gap = 10000; opt_str_route = "";

                origin = ary_origin[k]; destination = ary_dest[k];
                origin_index = m_NodeIDtoIndex[origin]; destination_index = m_NodeIDtoIndex[destination];
                // find y_max and UB
                LinkCost.CopyTo(LinkCost_Penalty, 0);
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);

                ////////////////////////////////////////////////
                {
                    // find UB and ymax
                    day_cost = new double[day_size]; y_max = 0; UB = 0;
                    for (int l = 0; l < route.LinkSeq.Length; l++)
                    {
                        UB += LinkCost[route.LinkSeq[l]];
                        if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                        {
                            tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                            for (int d = 0; d < day_size; d++)
                            {
                                day_cost[d] += aryCLink[route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                            }
                        }
                        else
                        {
                            for (int d = 0; d < day_size; d++)
                            {
                                day_cost[d] += aryCLink[route.LinkSeq[l]].TravelTime;
                            }
                        }
                    }

                    for (int d = 0; d < day_size; d++)
                    {
                        y_max += Math.Pow(day_cost[d] - UB, 2);
                    }
                    y_max = y_max / (day_size - 1);
                    UB += beta * Math.Sqrt(y_max);
                    // y_max = y_max * 0.9;
                    log.Write(Math.Round(route.PathTime, 2) + "\t");

                    ////////////////////////////////////////////////////////
                    // find primal and dual
                    do
                    {
                        primal = 0; dual = 0; str_route = ""; gap = 0;
                        day_cost = new double[day_size];
                        average_cost = 0;
                        double total_var = 0, total_w = 0;
                        // assign link cost
                        double temp = 0;
                        bool assign = true;
                        Gaussian g;
                        double mean = 0, sd = 0, g_value = 0;
                        while (assign)
                        {
                            assign = false;
                            for (int l = 0; l < m_LinkSize; l++)
                            {
                                if (aryCLink[l].TMC != null && TMCwithRealData.ContainsKey(aryCLink[l].TMC))
                                {
                                    temp = 0;
                                    tmc_index = TMCwithRealData[aryCLink[l].TMC];
                                    for (int d = 0; d < day_size; d++)
                                    {
                                        temp += mu[d] * (aryCLink[l].Link_Length / TMCHistSpd[tmc_index, d] * 60 - LinkCost[l]);
                                    }
                                    LinkCost_Penalty[l] = LinkCost[l] + temp;
                                    if (LinkCost_Penalty[l] <= 0)  // reduce values of mu in scale
                                    {
                                        //double mu_sum = 0;
                                        for (int d = 0; d < day_size; d++)
                                        {
                                            //mu[d] = mu[d] * 0.9;
                                            mu[d] = mu[d] - stepsize_mu[d] + stepsize_mu[d] * 0.9;
                                        }
                                        //Console.WriteLine(mu_sum);
                                        assign = true;
                                        break;
                                    }
                                }
                                else
                                {
                                    g = new Gaussian(l);
                                    mean = LinkCost[l];
                                    sd = 0;
                                    g_value = 0;
                                    temp = 0;
                                    length = aryCLink[l].Link_Length;
                                    spd = aryCLink[l].SpeedLimit;
                                    for (int d = 0; d < day_size; d++)
                                    {
                                        sd = Math.Sqrt(day_MeanVar[d]) * (length / spd * 60);
                                        g_value = g.NextGaussian3(mean, sd);
                                        temp += mu[d] * (g_value - mean);
                                    }
                                    LinkCost_Penalty[l] = LinkCost[l] + temp;
                                    if (LinkCost_Penalty[l] <= 0)  // reduce values of mu in scale
                                    {
                                        for (int d = 0; d < day_size; d++)
                                        {
                                            //mu[d] = mu[d] * 0.9;
                                            mu[d] = mu[d] - stepsize_mu[d] + stepsize_mu[d] * 0.9;
                                        }
                                        assign = true;
                                        break;
                                    }
                                }
                            }
                        }
                        //Console.WriteLine(iteration + "==================");
                        // do shortest path search, find path, solve Lx
                        if (ShortestPath_Destination(destination_index, out PredAry))
                            GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                        else
                            break;
                        // solve Lw
                        for (int d = 0; d < day_size; d++)
                        {
                            w[d] = mu[d] * (day_size - 1) / (2 * nu);
                        }

                        // find y, solve Ly
                        if (beta * Math.Sqrt(y_max) - nu * y_max > 0)
                            y = 0;
                        else
                            y = y_max;
                        // calculate primal and dual function value
                        for (int l = 0; l < route.LinkSeq.Length; l++)
                        {
                            average_cost += LinkCost[route.LinkSeq[l]];
                            // calculate travel time for each sample
                            if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                            {
                                tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                                for (int d = 0; d < day_size; d++)
                                {
                                    day_cost[d] += aryCLink[route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                                }
                            }
                            else
                            {
                                for (int d = 0; d < day_size; d++)
                                {
                                    day_cost[d] += LinkCost[route.LinkSeq[l]];
                                }
                            }
                            //else
                            //{
                            //    g = new Gaussian(route.LinkSeq[l]);
                            //    mean = LinkCost[route.LinkSeq[l]];
                            //    sd = 0; g_value = 0;
                            //    length = aryCLink[route.LinkSeq[l]].Link_Length;
                            //    spd = aryCLink[route.LinkSeq[l]].SpeedLimit;
                            //    double[] g_ary = new double[day_size];
                            //    for (int d = 0; d < day_size; d++)
                            //    {
                            //        sd = Math.Sqrt(day_MeanVar[d]) * (length / spd * 60);
                            //        g_value = g.NextGaussian3(mean, sd);
                            //        day_cost[d] += g_value;
                            //        g_ary[d] = g_value;
                            //    }
                            //}
                            dual += LinkCost_Penalty[route.LinkSeq[l]];
                            str_route += aryCLink[route.LinkSeq[l]].ID.ID.ToString() + ",";
                        }
                        for (int d = 0; d < day_size; d++)
                        {
                            total_var += Math.Pow(day_cost[d] - average_cost, 2);
                            total_w += (nu / (day_size - 1) * w[d] - mu[d]) * w[d];
                        }
                        primal = average_cost + beta * Math.Sqrt(total_var / (day_size - 1));
                        dual += total_w + beta * Math.Sqrt(y) - nu * y;
                        ary_dual[iteration] = dual;

                        if (dual > UB)
                            UB = dual;
                        if (gap < 0)
                            gap = 0;

                        // find optimal
                        if (dual >= opt_dual)
                        {
                            opt_dual = dual;
                        }
                        if (primal <= opt_primal)
                        {
                            opt_primal = primal;
                            UB = primal;
                            opt_str_route = str_route;
                        }
                        gap = opt_primal - opt_dual;
                        if (gap <= opt_gap)
                        {
                            opt_gap = gap;
                        }

                        // output
                        //log.WriteLine(Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(mu, 3) + "\t" + Math.Round(total_var, 3) + "\t" + Math.Round(y, 3)
                        //    + "\t" + route.PathTime + "\t" + stepsize);
                        //Console.WriteLine(Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(mu, 3)
                        //    + "\t" + str_route + "\t" + Math.Round(stepsize, 3));

                        // calculate mu(k+1) and nu(k+1) with subgradient
                        temp = 0; total_w = 0;
                        for (int d = 0; d < day_size; d++)
                        {
                            temp = (day_cost[d] - average_cost - w[d]);
                            temp = Math.Abs(temp);
                            if (temp == 0)
                                temp = 0.0001;
                            stepsize_mu[d] = lambda_mu[d] * (UB - dual) / temp;
                            lambda_mu[d] = 1 / (1 / lambda_mu[d] + 1);
                            if (stepsize_mu[d] == 0)
                            {
                                lambda_mu[d] = 0.01;
                                stepsize_mu[d] = lambda_mu[d];
                            }
                            total_w += Math.Pow(w[d], 2);
                        }
                        temp = total_w / (day_size - 1) - y;
                        if (temp == 0)
                            temp = 0.0001;
                        stepsize_nu = lambda_nu * (UB - dual) / temp;
                        lambda_nu = 1 / (1 / lambda_nu + 1);
                        if (stepsize_nu == 0)
                        {
                            lambda_nu = 0.01;
                            stepsize_nu = lambda_nu;
                        }
                        //double mu_sum = 0;
                        for (int d = 0; d < day_size; d++)
                        {
                            mu[d] += stepsize_mu[d];
                            if (mu[d] < 0)
                                mu[d] = 0;
                            //mu_sum += mu[d];
                        }
                        //while (mu_sum >= 4)
                        //{
                        //    mu_sum = 0;
                        //    for (int d = 0; d < day_size; d++)
                        //    {
                        //        mu[d] = mu[d] * 0.9; // / day_size;
                        //        mu_sum += mu[d];
                        //    }
                        //}

                        nu += stepsize_nu;
                        if (nu < 0)
                            nu = 0.0001;

                        iteration++;
                        //log.Write(Math.Round(mu[0], 3) + "\t" + Math.Round(mu[1], 3) + "\t" + Math.Round(mu[2], 3) + "\t" +
                        //    Math.Round(mu[3], 3) + "\t" + Math.Round(nu, 3) + "\t" + Math.Round(primal, 3) + "\t" + Math.Round(dual, 3)
                        //     + "\t" + Math.Round(opt_primal, 3) + "\t" + Math.Round(opt_dual, 3) + "\n"); 
                    }
                    while (iteration < max_iteration);
                    /////////////////////////////////////////////////////
                    log.Write(Math.Round(opt_primal, 3) + "\t" + Math.Round(opt_dual, 3) + "\t" + Math.Round(1 - opt_dual / opt_primal, 4)
                        + "\t" + origin + "\t" + destination + "\t" + coverage + "\t" + "\n");
                    //log.Close();

                    //log.WriteLine("\n");
                    //log.WriteLine("UB: " + UB + "\t y max: " + y_max + "\t mu bound: " + 1 / Math.Sqrt(y_max) + "\t Opt Dual: " + Math.Round(opt_dual, 3)
                    //    + "\t Opt Dual Mu: " + Math.Round(opt_mu_dual, 3) + "\t Opt Primal: " + Math.Round(opt_primal, 3) + "\t Opt Primal Mu: " + Math.Round(opt_mu_primal, 3) + "\n");
                    // generate reliability data: SD per mile = 0.8402ln(x) + 0.1387, x is the travel min per mile 


                }
                ///////////////////////////////////////////////////

                // evaluation with Random Draw path enumeration method 
                {
                    Gaussian g;
                    double mean = 0;
                    double sd = 0;
                    double g_value = 0;
                    double total_var = 0;

                    /*/ individual day reliable path ////////////////////////////////
                    primal = 0;
                    opt_primal = 1000000;
                    for (int day = 0; day < day_size; day++)
                    {
                        // individual day shortest path
                        for (int l = 0; l < m_LinkSize; l++)
                        {
                            if (aryCLink[l].TMC != null && TMCwithRealData.ContainsKey(aryCLink[l].TMC))
                            {
                                tmc_index = TMCwithRealData[aryCLink[l].TMC];
                                LinkCost_Penalty[l] = aryCLink[l].Link_Length / TMCHistSpd[tmc_index, day] * 60;
                            }
                        }
                        if (ShortestPath_Destination(destination_index, out PredAry))
                            GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                        average_cost = 0; total_var = 0;
                        day_cost = new double[day_size];
                        int route_length = route.LinkSeq.Length;
                        for (int l = 0; l < route_length; l++)
                        {
                            average_cost += LinkCost[route.LinkSeq[l]];
                            // calculate travel time for each sample
                            if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                            {
                                tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                                for (int d = 0; d < day_size; d++)
                                {
                                    day_cost[d] += aryCLink[route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                                }
                            }
                            else
                            {
                                for (int d = 0; d < day_size; d++)
                                {
                                    day_cost[d] += LinkCost[route.LinkSeq[l]];
                                }
                            }
                        }
                        for (int d = 0; d < day_size; d++)
                        {
                            total_var += Math.Pow(day_cost[d] - average_cost, 2);
                        }
                        primal = average_cost + beta * Math.Sqrt(total_var / (day_size - 1));
                        // find optimal
                        if (primal <= opt_primal)
                        {
                            opt_primal = primal;
                        }
                        // log.Write("Individual day" + Math.Round(primal, 3) + "\t" + Math.Round(opt_primal, 3) + "\n");
                    }
                    log.Write("Individual day " + Math.Round(opt_primal, 3) + "\t");
                    //////////////////////////////////////////////*/

                    primal = 0;
                    opt_primal = 1000000;
                    /*/ Random Draw ////////////////////////////////////                    
                    for (int i = 0; i < 20; i++)
                    {
                        g = new Gaussian(i);
                        average_cost = 0; total_var = 0;
                        day_cost = new double[day_size];
                        if (i >= 0)
                            for (int l = 0; l < m_LinkSize; l++)
                            {                                
                                mean = LinkCost[l];
                                sd = Math.Sqrt(mean);
                                g_value = g.NextGaussian3(mean, sd);
                                LinkCost_Penalty[l] = Math.Abs(g_value);
                            }
                        if (ShortestPath_Destination(destination_index, out PredAry))
                            GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                        // calculate primal and dual function value
                        for (int l = 0; l < route.LinkSeq.Length; l++)
                        {
                            average_cost += LinkCost[route.LinkSeq[l]];
                            // calculate travel time for each sample
                            if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                            {
                                tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                                for (int d = 0; d < day_size; d++)
                                {
                                    day_cost[d] += aryCLink[route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                                }
                            }
                            else
                            {
                                for (int d = 0; d < day_size; d++)
                                {
                                    day_cost[d] += LinkCost[route.LinkSeq[l]];
                                }
                            }
                        }
                        for (int d = 0; d < day_size; d++)
                        {
                            total_var += Math.Pow(day_cost[d] - average_cost, 2);
                        }
                        primal = average_cost + beta * Math.Sqrt(total_var / (day_size - 1));
                        // find optimal
                        if (primal <= opt_primal)
                        {
                            opt_primal = primal;
                        }
                        // log.Write("Random Draw " + Math.Round(primal, 3) + "\t" + Math.Round(opt_primal, 3) + "\n");
                    }
                    log.Write("Random Draw " + Math.Round(opt_primal, 3) + "\n");
                    //////////////////////////////////////////////////*/
                }
                //log.Close();
                //////////////////////////////////////////////////////
            }
            end_time = DateTime.Now;
            log.Close();
            return true;
        }

        public bool LinkPile(double ori_lat, double ori_long, double dest_lat, double dest_long)
        {
            int origin = FindClosestNode(ori_lat, ori_long);
            int destination = FindClosestNode(dest_lat, dest_long);
            int[] PredAry;
            CRoute route = new CRoute();

            //origin = 109797; destination = 133124;

            int origin_index = m_NodeIDtoIndex[origin], destination_index = m_NodeIDtoIndex[destination];
            if (ShortestPath_Destination(destination_index, out PredAry))
                GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);

            ReliablePath_Sampling_Single(origin_index, destination_index, 20);

            int day_size = TMCHistSpd.GetLength(1);
            double coverage_mile = 0;
            double[] dayTT = new double[day_size];
            double[,] linkTT = new double[day_size, route.LinkSeq.Length];
            for (int l = 0; l < route.LinkSeq.Length; l++)
            {
                if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                {
                    int tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                    for (int d = 0; d < day_size; d++)
                    {
                        linkTT[d, l] = aryCLink[route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                        dayTT[d] += linkTT[d, l];
                    }
                    coverage_mile += aryCLink[route.LinkSeq[l]].Link_Length;
                }
                else
                {
                    for (int d = 0; d < day_size; d++)
                    {
                        //linkTT[d, l] = aryCLink[route.LinkSeq[l]].TravelTime;
                        dayTT[d] += aryCLink[route.LinkSeq[l]].TravelTime;
                    }
                }
            }
            TextWriter log = new StreamWriter(city + "_link_pile_log.txt");
            for (int d = 0; d < day_size; d++)
            {
                for (int l = 0; l < route.LinkSeq.Length; l++)
                {
                    log.Write(Math.Round(linkTT[d, l], 4) + "\t");
                }
                log.Write("\n");
            }
            log.Close();

            Bitmap bmp = DrawRoute(2000, route);
            DateTime time = DateTime.Now;
            string filename = time.Minute.ToString() + "_img.bmp";
            bmp.Save(filename);
            bmp.Dispose();

            return true;
        }

        public void ReliablePathEvaluation()
        {
            // read in path, find best UB value
            int[] Origin_ID = new int[] { 52292, 151094, 136822, 136054, 143655, 81422, 140124, 109800, 139476 };
            int[] Dest_ID = new int[] { 154600, 15843, 47948, 148424, 52057, 201951, 240663, 136327, 135960 };
            /////////////////////////////////////////////////////////
            // find best primal value from path enumeration results
            double[] day_MeanVar;
            LoadHistData_CSV("9am", out day_MeanVar);
            int day_size = TMCHistSpd.GetLength(1);
            int tmc_index = 0;
            double beta = 1.27;
            FileStream nwfsInput;
            StreamReader nwsrInput;
            string szSrcLine = "";
            int index = 0, route_length = 0, count = 0;
            CRoute E_route = new CRoute();
            int[] note_seq, link_seq;
            string[] raw_data;
            double[] best_primal = new double[9];
            for (int i = 0; i < 9; i++)
            {
                nwfsInput = new FileStream(@"C:\Research\Reliability\More experiments\path_set_" + i + ".csv", FileMode.Open, FileAccess.Read);
                nwsrInput = new StreamReader(nwfsInput);
                best_primal[i] = 999999;
                while ((szSrcLine = nwsrInput.ReadLine()) != null)
                {
                    index = szSrcLine.IndexOf(",");
                    szSrcLine = szSrcLine.Substring(index + 1);
                    index = szSrcLine.IndexOf(",");
                    route_length = int.Parse(szSrcLine.Substring(0, index));
                    szSrcLine = szSrcLine.Substring(index + 1);
                    raw_data = szSrcLine.Split(',');
                    note_seq = new int[route_length];
                    link_seq = new int[route_length - 1];
                    E_route = new CRoute(note_seq, link_seq, link_seq, 0, 0, 0, 0);
                    count++;
                    for (int n = 0; n < route_length; n++)
                    {
                        E_route.PathAry[n] = m_NodeIDtoIndex[int.Parse(raw_data[n])];
                    }
                    //get LinkSeq
                    int TempNodeID = 0;
                    int link_size = 0;
                    double temp_link_cost = 0;
                    for (int k = 0; k < route_length - 1; k++)
                    {
                        temp_link_cost = 99999999;
                        for (int l = 0; l < InboundLinkSize[E_route.PathAry[k + 1]]; l++)
                        {
                            TempNodeID = aryCLink[InboundLinkAry[E_route.PathAry[k + 1], l]].FromID;
                            if (m_NodeIDtoIndex[TempNodeID] == E_route.PathAry[k])
                            {
                                link_size++;
                                if (LinkCost_Penalty[InboundLinkAry[E_route.PathAry[k + 1], l]] < temp_link_cost)
                                {
                                    E_route.LinkSeq[k] = InboundLinkAry[E_route.PathAry[k + 1], l];
                                    temp_link_cost = LinkCost_Penalty[InboundLinkAry[E_route.PathAry[k + 1], l]];
                                }

                            }
                        }
                    }

                    // calculate primal
                    double primal = 0;
                    double[] day_cost = new double[day_size];
                    double average_cost = 0;
                    double total_var = 0;
                    for (int l = 0; l < E_route.LinkSeq.Length; l++)
                    {
                        average_cost += LinkCost[E_route.LinkSeq[l]];
                        // calculate travel time for each sample
                        if (aryCLink[E_route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[E_route.LinkSeq[l]].TMC))
                        {
                            tmc_index = TMCwithRealData[aryCLink[E_route.LinkSeq[l]].TMC];
                            for (int d = 0; d < day_size; d++)
                            {
                                day_cost[d] += aryCLink[E_route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                            }
                        }
                        else
                        {
                            for (int d = 0; d < day_size; d++)
                            {
                                day_cost[d] += aryCLink[E_route.LinkSeq[l]].TravelTime;
                            }
                        }
                    }
                    for (int d = 0; d < day_size; d++)
                    {
                        total_var += Math.Pow(day_cost[d] - average_cost, 2);
                    }
                    primal = average_cost + beta * Math.Sqrt(total_var / (day_size - 1));
                    if (primal <= best_primal[i])
                        best_primal[i] = primal;
                }
                nwsrInput.Close();
                nwfsInput.Close();
            }
            ////////////////////////////////////////////////////////

            // use ReliablePath_Sampling_Single to find most reliable path
            double[] LR_best_primal = new double[9];
            for (int i = 0; i < 9; i++)
            {
                LR_best_primal[i] = ReliablePath_Sampling_Single(m_NodeIDtoIndex[Origin_ID[i]], m_NodeIDtoIndex[Dest_ID[i]], 10);
            }
            // calculate stats

            return;

        }

        public double ReliablePath_Sampling_Single(int origin_index, int destination_index, int max_iteration)
        {
            TextWriter log = new StreamWriter(city + "_Sampling_Single_log.txt");
            log.WriteLine("iteration\tprimal\tdual\tgap");

            // Load historical data            
            double[] day_MeanVar;
            LoadHistData_CSV("9am", out day_MeanVar);
            //LoadHistData_CSV("9am_newDEMO", out day_MeanVar);

            int day_size = TMCHistSpd.GetLength(1);
            int tmc_index = 0, tmc_size = TMCHistSpd.GetLength(0);
            double length = 0, spd = 0;
            int[] PredAry;
            CRoute route = new CRoute();
            double beta = 1; //beta = 1.27;
            double UB = 0;
            double[] mu = new double[day_size], stepsize_mu = new double[day_size], lambda_mu = new double[day_size];
            double nu = 0.01, stepsize_nu = 0, lambda_nu = 0.5;
            double y_max = 0, y = 0;
            double[] w = new double[day_size];
            double[] day_cost = new double[day_size];
            double average_cost = 0;

            string str_route = "", opt_str_route = "";
            double primal = 0, dual = 0, gap = 0;
            int iteration = 0;
            double opt_dual = 0, opt_primal = 10000, opt_gap = 10000;
            Random rdm = new Random(123);
            double[] ary_dual = new double[max_iteration];

            // find y_max and UB
            LinkCost.CopyTo(LinkCost_Penalty, 0);
            if (ShortestPath_Destination(destination_index, out PredAry))
                GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
            else
                return -1;


            // find UB and ymax
            day_cost = new double[day_size]; y_max = 0; UB = 0;
            for (int l = 0; l < route.LinkSeq.Length; l++)
            {
                UB += LinkCost[route.LinkSeq[l]];
                if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                {
                    tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                    for (int d = 0; d < day_size; d++)
                    {
                        day_cost[d] += aryCLink[route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                    }
                }
                else
                {
                    for (int d = 0; d < day_size; d++)
                    {
                        day_cost[d] += aryCLink[route.LinkSeq[l]].TravelTime;
                    }
                }
            }

            for (int d = 0; d < day_size; d++)
            {
                y_max += Math.Pow(day_cost[d] - UB, 2);
            }
            y_max = y_max / (day_size - 1);
            UB += beta * Math.Sqrt(y_max);
            log.Write(Math.Round(route.PathTime, 2) + "\t");



            ////////////////////////////////////////////////////////
            // find primal and dual
            do
            {
                primal = 0; dual = 0; str_route = ""; gap = 0;
                day_cost = new double[day_size];
                average_cost = 0;
                double total_var = 0, total_w = 0;
                // assign link cost
                double temp = 0;
                bool assign = true;
                while (assign)
                {
                    assign = false;
                    for (int l = 0; l < m_LinkSize; l++)
                    {
                        if (aryCLink[l].TMC != null && TMCwithRealData.ContainsKey(aryCLink[l].TMC))
                        {
                            temp = 0;
                            tmc_index = TMCwithRealData[aryCLink[l].TMC];
                            for (int d = 0; d < day_size; d++)
                            {
                                temp += mu[d] * (aryCLink[l].Link_Length / TMCHistSpd[tmc_index, d] * 60 - LinkCost[l]);
                            }
                            LinkCost_Penalty[l] = LinkCost[l] + temp;
                            if (LinkCost_Penalty[l] <= 0)  // reduce values of mu in scale
                            {
                                //double mu_sum = 0;
                                for (int d = 0; d < day_size; d++)
                                {
                                    //mu[d] = mu[d] * 0.9;
                                    mu[d] = mu[d] - stepsize_mu[d] + stepsize_mu[d] * 0.9;
                                }
                                //Console.WriteLine(mu_sum);
                                assign = true;
                                break;
                            }
                        }
                        else
                        {
                            Gaussian g = new Gaussian(l);
                            double mean = LinkCost[l];
                            double sd = 0;
                            double g_value = 0;
                            temp = 0;
                            length = aryCLink[l].Link_Length;
                            spd = aryCLink[l].SpeedLimit;
                            for (int d = 0; d < day_size; d++)
                            {
                                sd = Math.Sqrt(day_MeanVar[d]) * (length / spd * 60);
                                g_value = g.NextGaussian3(mean, sd);
                                temp += mu[d] * (g_value - mean);
                            }
                            LinkCost_Penalty[l] = LinkCost[l] + temp;
                            if (LinkCost_Penalty[l] <= 0)  // reduce values of mu in scale
                            {
                                for (int d = 0; d < day_size; d++)
                                {
                                    //mu[d] = mu[d] * 0.9;
                                    mu[d] = mu[d] - stepsize_mu[d] + stepsize_mu[d] * 0.9;
                                }
                                assign = true;
                                break;
                            }
                        }
                    }
                }
                //Console.WriteLine(iteration + "==================");
                // do shortest path search, find path, solve Lx
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                else
                    break;
                // solve Lw
                for (int d = 0; d < day_size; d++)
                {
                    w[d] = mu[d] * (day_size - 1) / (2 * nu);
                }

                // find y, solve Ly
                if (beta * Math.Sqrt(y_max) - nu * y_max > 0)
                    y = 0;
                else
                    y = y_max;
                // calculate primal and dual function value
                for (int l = 0; l < route.LinkSeq.Length; l++)
                {
                    average_cost += LinkCost[route.LinkSeq[l]];
                    // calculate travel time for each sample
                    if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                    {
                        tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                        for (int d = 0; d < day_size; d++)
                        {
                            day_cost[d] += aryCLink[route.LinkSeq[l]].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                        }
                    }
                    else
                    {
                        for (int d = 0; d < day_size; d++)
                        {
                            day_cost[d] += aryCLink[route.LinkSeq[l]].TravelTime;
                        }
                    }
                    dual += LinkCost_Penalty[route.LinkSeq[l]];
                    str_route += aryCLink[route.LinkSeq[l]].ID.ID.ToString() + ",";
                }
                for (int d = 0; d < day_size; d++)
                {
                    total_var += Math.Pow(day_cost[d] - average_cost, 2);
                    total_w += (nu / (day_size - 1) * w[d] - mu[d]) * w[d];
                }
                primal = average_cost + beta * Math.Sqrt(total_var / (day_size - 1));
                dual += total_w + beta * Math.Sqrt(y) - nu * y;
                ary_dual[iteration] = dual;

                if (dual > UB)
                    UB = dual;
                if (gap < 0)
                    gap = 0;

                // find optimal
                if (dual >= opt_dual)
                {
                    opt_dual = dual;
                }
                if (primal <= opt_primal)
                {
                    opt_primal = primal;
                    UB = primal;
                }
                gap = opt_primal - opt_dual;
                if (gap <= opt_gap)
                {
                    opt_gap = gap;
                    opt_str_route = str_route;
                }

                // calculate mu(k+1) and nu(k+1) with subgradient
                temp = 0; total_w = 0;
                for (int d = 0; d < day_size; d++)
                {
                    temp = (day_cost[d] - average_cost - w[d]);
                    temp = Math.Abs(temp);
                    if (temp == 0)
                        temp = 0.0001;
                    stepsize_mu[d] = lambda_mu[d] * (UB - dual) / temp;
                    lambda_mu[d] = 1 / (1 / lambda_mu[d] + 1);
                    if (stepsize_mu[d] == 0)
                    {
                        lambda_mu[d] = 0.01;
                        stepsize_mu[d] = lambda_mu[d];
                    }
                    total_w += Math.Pow(w[d], 2);
                }
                temp = total_w / (day_size - 1) - y;
                if (temp == 0)
                    temp = 0.0000001;
                stepsize_nu = lambda_nu * (UB - dual) / temp;
                lambda_nu = 1 / (1 / lambda_nu + 1);
                if (stepsize_nu == 0)
                {
                    lambda_nu = 0.01;
                    stepsize_nu = lambda_nu;
                }
                for (int d = 0; d < day_size; d++)
                {
                    mu[d] += stepsize_mu[d];
                    if (mu[d] < 0)
                        mu[d] = 0;
                }

                nu += stepsize_nu;
                if (nu < 0)
                    nu = 0.0001;

                iteration++;
                log.Write(iteration + "\t" + Math.Round(primal, 4) + "\t" + Math.Round(dual, 4) + "\t" + Math.Round(1 - opt_dual / opt_primal, 4)
                    + "\t" + Math.Round(route.PathTime, 4) + "\n");
            }
            while (iteration < max_iteration);

            log.Close();
            return opt_primal;
        }

        public double[] day_MeanVar;
        public double m_max_ratio; // max ratio of day-dependent link travel time
        public bool Percentile_ReliablePath(int input_iteration, string algorithm)
        {
            int OD_size = 246;
            //read OD pairs/////////////////////////////////////////
            int[] ary_origin = new int[OD_size], ary_dest = new int[OD_size];
            FileStream nwfsInput = new FileStream(@"netdata/OD.csv", FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine = "";
            string[] raw = new string[2];
            int line = 0;
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                raw = szSrcLine.Split(',');
                ary_origin[line] = m_NodeIDtoIndex[Convert.ToInt32(raw[0])];
                ary_dest[line] = m_NodeIDtoIndex[Convert.ToInt32(raw[1])];
                line++;
            }
            nwsrInput.Close();
            nwfsInput.Close();

            LoadHistData_CSV("9am", out day_MeanVar);
            double single_primal = 0;
            //double single_gap = Percentile_ReliablePath_Single(1000, 2000, 95, 30, out single_primal);
            //single_gap = Percentile_ReliablePath_Single_old(1000, 2000, 100, 30, out single_primal);
            ///////////////////////////////////////////////////////////////////////////////////////////////////
            //int[] iteration = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 30, 40 };
            double[][] gap = new double[input_iteration][], gap_p = new double[input_iteration][];
            double[][] primal = new double[input_iteration][], primal_p = new double[input_iteration][];
            double[][] dual = new double[input_iteration][], dual_p = new double[input_iteration][];
            double[] average_gap = new double[input_iteration], average_gap_p = new double[input_iteration];
            double[] average_primal = new double[input_iteration], average_primal_p = new double[input_iteration];
            double[] average_dual = new double[input_iteration], average_dual_p = new double[input_iteration];
            for (int i = 0; i < input_iteration; i++)
            {
                gap[i] = new double[OD_size];
                primal[i] = new double[OD_size];
                dual[i] = new double[OD_size];
                gap_p[i] = new double[OD_size];
                primal_p[i] = new double[OD_size];
                dual_p[i] = new double[OD_size];
            }
            TextWriter log = new StreamWriter(city + "_Percentile_100_log.txt");
            log.WriteLine("ave_p\tave_d\tave_gap");
            TextWriter log_p = new StreamWriter(city + "_Percentile_95_log.txt");
            log_p.WriteLine("ave_p\tave_d\tave_gap");
            TextWriter log_time = new StreamWriter(city + "_Percentile_time_log.txt");
            log_time.WriteLine("OD\tOrigin\tDestination\tIteration\tAlgorithm\tARSP_SPLinkCount\tARSP_ComputingTime\tPRSP_SPLinkCount\tPRSP_ComputingTime\tSimilarity\tARSProute\tPRSProute");
            double[] temp_gap, temp_primal, temp_dual;
            int[] SPLinkCount = new int[OD_size], SPLinkCount_p = new int[OD_size];
            TimeSpan time = new TimeSpan(), time_p = new TimeSpan();
            CRoute bestRoute = new CRoute();
            CRoute bestRoute_p = new CRoute();

            DateTime start = DateTime.Now;
            for (int p = 0; p < OD_size; p++)
            {
                temp_gap = Percentile_ReliablePath_Single(ary_origin[p], ary_dest[p], 100, input_iteration, algorithm, out temp_primal, out temp_dual, out SPLinkCount[p], out time, out bestRoute);
                for (int i = 0; i < input_iteration; i++)
                {
                    gap[i][p] = temp_gap[i];
                    primal[i][p] = temp_primal[i];
                    dual[i][p] = temp_dual[i];
                    average_gap[i] += gap[i][p];
                    average_primal[i] += primal[i][p];
                    average_dual[i] += dual[i][p];
                    if (primal[i][p] >= 10000)
                        primal[i][p] = -1;
                }
                temp_gap = Percentile_ReliablePath_Single(ary_origin[p], ary_dest[p], 95, input_iteration, algorithm, out temp_primal, out temp_dual, out SPLinkCount_p[p], out time_p, out bestRoute_p);
                for (int i = 0; i < input_iteration; i++)
                {
                    gap_p[i][p] = temp_gap[i];
                    primal_p[i][p] = temp_primal[i];
                    dual_p[i][p] = temp_dual[i];
                    average_gap_p[i] += gap_p[i][p];
                    average_primal_p[i] += primal_p[i][p];
                    average_dual_p[i] += dual_p[i][p];
                    if (primal_p[i][p] >= 10000)
                        primal_p[i][p] = -1;
                }
                // compare two routes
                int count = 0;
                for (int i = 0; i < bestRoute.LinkSeq.Length; i++)
                {
                    for (int j = 0; j < bestRoute_p.LinkSeq.Length; j++)
                    {
                        if (bestRoute.LinkSeq[i] == bestRoute_p.LinkSeq[j])
                            count++;
                    }
                }                

                log_time.WriteLine(p + "\t" + ary_origin[p] + "\t" + ary_dest[p] + "\t" + input_iteration + "\t" + algorithm + "\t" + 
                    SPLinkCount[p] + "\t " + time.ToString() + "\t" + SPLinkCount_p[p] + "\t " + time_p.ToString() + 
                    "\tSimilarity:\t" + count.ToString() + "/" + bestRoute.LinkSeq.Length.ToString() + 
                    "\tARSP route:\t" + bestRoute.LinkSeq.ToString() + "\tPRSP route:\t" + bestRoute_p.LinkSeq.ToString());

            }
            TimeSpan totalTime = DateTime.Now - start;
            log_time.WriteLine("Total time: " + totalTime.ToString());

            for (int i = 0; i < input_iteration; i++)
            {
                average_gap[i] = average_gap[i] / (double)OD_size;
                average_primal[i] = average_primal[i] / (double)OD_size;
                average_dual[i] = average_dual[i] / (double)OD_size;
                log.WriteLine(Math.Round(average_primal[i], 2) + "\t" + Math.Round(average_dual[i], 2) + "\t" + Math.Round(average_gap[i], 4));
                average_gap_p[i] = average_gap_p[i] / (double)OD_size;
                average_primal_p[i] = average_primal_p[i] / (double)OD_size;
                average_dual_p[i] = average_dual_p[i] / (double)OD_size;
                log_p.WriteLine(Math.Round(average_primal_p[i], 2) + "\t" + Math.Round(average_dual_p[i], 2) + "\t" + Math.Round(average_gap_p[i], 4));
            }

            string write = "";
            log.WriteLine("primal");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(primal[i][p], 2) + ",";
                }
                log.WriteLine(write);
            }
            log.WriteLine("dual");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(dual[i][p], 2) + ",";
                }
                log.WriteLine(write);
            }
            log.WriteLine("gap");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(gap[i][p], 4) + ",";
                }
                log.WriteLine(write);
            }

            log_p.WriteLine("primal");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(primal_p[i][p], 2) + ",";
                }
                log_p.WriteLine(write);
            }
            log_p.WriteLine("dual");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(dual_p[i][p], 2) + ",";
                }
                log_p.WriteLine(write);
            }
            log_p.WriteLine("gap");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(gap_p[i][p], 4) + ",";
                }
                log_p.WriteLine(write);
            }

            log.Close();
            log_p.Close();
            log_time.Close();
            return true;
        }

        public double[] Percentile_ReliablePath_Single(int origin_index, int destination_index, int percentile, int max_iteration, string algorithm,
            out double[] out_opt_primal, out double[] out_opt_dual, out int SPLinkCount, out TimeSpan time, out CRoute bestRoute)
        {
            TextWriter log = new StreamWriter(city + "_Percentile_Single_1_log.txt");
            log.WriteLine("k\tprimal\tdual\topt_p\topt_d\tgap\tpathTT");

            // Load historical data            
            //double[] day_MeanVar;
            //LoadHistData_CSV("9am", out day_MeanVar);
            //LoadHistData_CSV("9am_newDEMO", out day_MeanVar);

            int day_size = TMCHistSpd.GetLength(1);
            int sample_day_size = day_size;
            int tmc_size = TMCHistSpd.GetLength(0);
            int[] PredAry;
            CRoute route = new CRoute();
            double[] mu = new double[sample_day_size], stepsize_mu = new double[sample_day_size];
            double nu = 0, stepsize_nu = 0, lambda_nu = 0.01;
            double M = 0, sum_mu = 0, lambda_mu = 0.1, sum_w = 0;
            double y = 0, y_LB = 0, y_UB = 0;
            double[] w = new double[sample_day_size];
            double[] day_cost = new double[sample_day_size];

            string str_route = "", opt_str_route = "";
            double primal = 0, dual = 0, gap = 0, dual_b = 0;
            double[] opt_relative_gap = new double[max_iteration];
            int iteration = 0;
            double opt_dual = 0, opt_primal = 10000, opt_gap = 10000;
            double[] ary_dual = new double[max_iteration];
            out_opt_primal = new double[max_iteration];
            out_opt_dual = new double[max_iteration];
            SPLinkCount = 0;
            time = new TimeSpan();
            bestRoute = new CRoute();

            DateTime startTime = DateTime.Now;
            // Step 1: Initialization ////////////////////////////////////////////////////////////////////////////////////////////////////
            // find UB and LB for y
            y_LB = 100000; y_UB = 0;
            double y_temp = 0;
            double[] y_samples = new double[sample_day_size];
            int[] y_sorted_index = new int[sample_day_size];
            if (percentile >= 100)
            {
                LinkCost.CopyTo(LinkCost_Penalty, 0); 
                //DateTime s = DateTime.Now;
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);                    
                else
                    return null;
                //TimeSpan time = DateTime.Now - s;
                for (int d = 0; d < sample_day_size; d++)
                {
                    y_temp = 0;
                    for (int l = 0; l < route.LinkSeq.Length; l++)
                    {
                        y_temp += LinkCost_DayD[d][route.LinkSeq[l]];
                    }
                    if (y_temp > y_UB)
                        y_UB = y_temp;
                    if (y_temp < y_LB)
                        y_LB = y_temp;
                    // initial LR parameters
                    mu[d] = 1 / (double)sample_day_size;
                }
            }
            else
            {
                LinkCost_min.CopyTo(LinkCost_Penalty, 0);
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                else
                    return null;
                y_LB = 0;
                for (int l = 0; l < route.LinkSeq.Length; l++)
                {
                    y_LB += LinkCost_min[route.LinkSeq[l]];
                }
                for (int d = 0; d < sample_day_size; d++)
                {
                    y_temp = 0;
                    for (int l = 0; l < route.LinkSeq.Length; l++)
                    {
                        y_temp += LinkCost_DayD[d][route.LinkSeq[l]];
                    }
                    y_samples[d] = y_temp;
                    if (y_temp > y_UB)
                        y_UB = y_temp;
                    // initial LR parameters
                    mu[d] = 1 / (double)sample_day_size;
                }
                M = y_UB - y_LB;
                int[] list = SortingFunction(y_samples, false);
                y_UB = y_samples[list[percentile * sample_day_size / 100]];
            }
            SPLinkCount = route.LinkSeq.Length;
            //Console.WriteLine(origin_index.ToString() + "," + destination_index.ToString() + "," + y_UB.ToString());
            nu = 1;
            //log.Write(Math.Round(route.PathTime, 2) + "\n");

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            // find primal and dual
            List<int> branch = new List<int>();
            do
            {
                day_cost = new double[sample_day_size];
                // Step 2: solve dual function //////////////////////////////////////////////////////////////////////////////////////////
                // assign link cost for Lx
                double temp = 0;
                for (int l = 0; l < m_LinkSize; l++)
                {
                    temp = 0;
                    for (int d = 0; d < sample_day_size; d++)
                    {
                        temp += mu[d] * LinkCost_DayD[d][l];
                    }
                    LinkCost_Penalty[l] = temp;
                }

                //Console.WriteLine(iteration + "==================");
                // do shortest path search, find path, solve Lx
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                else
                    break;

                // find y, solve Ly
                sum_mu = 0;
                for (int d = 0; d < sample_day_size; d++)
                {
                    sum_mu += mu[d];
                }
                if (1 - sum_mu >= 0)
                    y = y_LB;
                else
                    y = y_UB;

                // solve Lw
                if (percentile < 100)
                {
                    sum_w = 0;
                    for (int d = 0; d < sample_day_size; d++)
                    {
                        if (nu - mu[d] * M >= 0)
                            w[d] = 0;
                        else
                            w[d] = 1;
                        sum_w += w[d];
                    }
                }

                // calculate primal and dual function value
                // dual value L

                dual = 0; str_route = "";
                for (int j = 0; j < route.LinkSeq.Length; j++)
                {
                    dual += LinkCost_Penalty[route.LinkSeq[j]];
                    str_route += aryCLink[route.LinkSeq[j]].ID.ID.ToString() + ",";
                }
                dual += (1 - sum_mu) * y;
                if (percentile < 100)
                {
                    for (int d = 0; d < sample_day_size; d++)
                    {
                        dual += (nu - mu[d] * M) * w[d];
                    }
                    dual = dual - nu * (1 - (double)percentile / 100.0) * (double)sample_day_size;
                }

                // primal value
                y_samples = new double[sample_day_size];
                primal = 0; dual_b = y;
                for (int d = 0; d < sample_day_size; d++)
                {
                    y_temp = 0;
                    for (int l = 0; l < route.LinkSeq.Length; l++)
                    {
                        y_temp += LinkCost_DayD[d][route.LinkSeq[l]];
                    }
                    y_samples[d] = y_temp;
                    if (y_temp > primal)
                        primal = y_temp;
                    dual_b += mu[d] * (y_temp - y - w[d] * M);
                }
                if (percentile < 100)
                {
                    int[] list = SortingFunction(y_samples, false);
                    //M = primal - y_samples[list[percentile * sample_day_size / 100]];
                    M = primal - dual;
                    primal = y_samples[list[percentile * sample_day_size / 100]];
                    dual_b += nu * (sum_w - (1 - (double)percentile / 100.0) * (double)sample_day_size);
                }

                ///////////////////////////////////////
                // day_size sensitivity tests
                if (true)
                {
                    double[] y_samples_temp = new double[day_size];
                    primal = 0; dual_b = y;
                    for (int d = 0; d < day_size; d++)
                    {
                        y_temp = 0;
                        for (int l = 0; l < route.LinkSeq.Length; l++)
                        {
                            y_temp += LinkCost_DayD[d][route.LinkSeq[l]];
                        }
                        y_samples_temp[d] = y_temp;
                        if (y_temp > primal)
                            primal = y_temp;
                    }
                    if (percentile < 100)
                    {
                        int[] list = SortingFunction(y_samples_temp, false);
                        //M = primal - y_samples[list[percentile * sample_day_size / 100]];
                        M = primal - dual;
                        primal = y_samples_temp[list[percentile * day_size / 100]];
                    }
                }

                ///////////////////////////////////////

                if (algorithm == "branch")
                {
                    y_samples = sortDouble(y_samples, true, out y_sorted_index);
                    if (percentile >= 100)
                    {
                        for (int d = 0; d < sample_day_size; d++)
                        {
                            if (!branch.Contains(y_sorted_index[d]))
                            {
                                branch.Add(y_sorted_index[d]);
                                break;
                            }
                        }
                    }
                    else
                    {
                        branch = new List<int>();
                        //int nu_w = (int)(M / nu + (1 - (1 - (double)percentile / 100.0) * (double)sample_day_size));
                        int nu_w = (int)(M / nu + (1 - (double)percentile / 100.0) * (double)sample_day_size);
                        if (nu_w > sample_day_size)
                            nu_w = sample_day_size;
                        for (int d = 0; d < nu_w; d++)
                        {
                            branch.Add(y_sorted_index[d]);
                        }
                    }
                }

                gap = primal - dual;
                if (gap < 0)
                    gap = 0;

                // find optimal
                if (dual >= opt_dual)
                {
                    opt_dual = dual;
                }
                if (dual > y_LB)
                {
                    y_LB = dual;
                }
                if (primal < opt_primal)
                {
                    opt_primal = primal;
                    y_UB = primal;
                }
                gap = opt_primal - opt_dual;
                if (gap <= opt_gap)
                {
                    opt_gap = gap;
                    opt_str_route = str_route;
                }
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                if (algorithm == "subgradient")
                {
                    // calculate mu(k+1) and nu(k+1) with subgradient
                    for (int d = 0; d < sample_day_size; d++)
                    {
                        stepsize_mu[d] = lambda_mu * (y_UB - y_LB) * (y_samples[d] - y - w[d] * M);
                        mu[d] += stepsize_mu[d];
                        if (mu[d] < 0)
                            mu[d] = 0.000001; //////////////
                    }
                    if (percentile < 100)
                    {
                        stepsize_nu = lambda_nu * (y_UB - y_LB) * (sum_w - (1 - (double)percentile / 100.0) * (double)sample_day_size);
                        nu += stepsize_nu;
                        if (nu < 0)
                            nu = 0.001;
                    }
                    lambda_mu = 0.001 / (iteration + 1);
                    //lambda_mu = 1 / (1 / lambda_mu + 1);
                    lambda_nu = 0.001;// / (iteration + 1);
                    //lambda_nu = 1 / (1 / lambda_nu + 1);
                }
                if (algorithm == "branch")
                {
                    //if (percentile < 100)
                    //{
                    //    double sum_mu_w = 0;
                    //    sum_w = 0;
                    //    for (int d = 0; d < sample_day_size; d++)
                    //    {
                    //        sum_mu_w += mu[d] * w[d];
                    //        sum_w += w[d];
                    //    }
                    //    nu = M * sum_mu_w / (sum_w - ((1 - (double)percentile / 100.0) * (double)sample_day_size));
                    //    if (nu <= 0)
                    //        nu = 0.001;
                    //}
                    if (percentile < 100)
                    {
                        lambda_nu = 0.001;
                        stepsize_nu = lambda_nu * (y_UB - y_LB) * (sum_w - (1 - (double)percentile / 100.0) * (double)sample_day_size);
                        nu += stepsize_nu;
                        if (nu <= 0)
                            nu = 0.001;
                    }
                    int branchSize = branch.Count;
                    for (int d = 0; d < sample_day_size; d++)
                    {
                        if (branch.Contains(d))
                        {
                            mu[d] = 1.0 / (double)branchSize;
                        }
                        else
                        {
                            mu[d] = 0.0;
                        }
                    }
                    //if (percentile < 100)
                    //{
                    //    nu = M * (1.0 / (double)branchSize) * 0.9;
                    //    if (nu <= 0)
                    //        nu = 0.001;
                    //}
                }                

                opt_relative_gap[iteration] = opt_gap / opt_primal;
                out_opt_primal[iteration] = opt_primal;
                out_opt_dual[iteration] = opt_dual;
                iteration++;
                log.Write(iteration + "\t" + Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(opt_primal, 3) +
                    "\t" + Math.Round(opt_dual, 3) + "\t" + Math.Round(1 - opt_dual / opt_primal, 3) + "\t" + Math.Round(route.PathTime, 3) + "\n");
            }
            while (!(iteration >= max_iteration || opt_gap <= 0));
            time = DateTime.Now - startTime;
            bestRoute = route;

            log.Close();
            return opt_relative_gap;
        }

        public double Percentile_ReliablePath_Single_old(int origin_index, int destination_index, int percentile, int max_iteration, out double out_opt_primal)
        {
            TextWriter log = new StreamWriter(city + "_Percentile_Single_0_log.txt");
            log.WriteLine("k\tprimal\tdual\topt_p\topt_d\tgap\tpathTT");

            // Load historical data            
            double[] day_MeanVar;
            LoadHistData_CSV("9am", out day_MeanVar);
            //LoadHistData_CSV("9am_newDEMO", out day_MeanVar);

            int day_size = TMCHistSpd.GetLength(1);
            int tmc_index = 0, tmc_size = TMCHistSpd.GetLength(0);
            double length = 0, spd = 0;
            int[] PredAry;
            CRoute route = new CRoute();
            double[] mu = new double[day_size], stepsize_mu = new double[day_size];
            double nu = 0, stepsize_nu = 0, lambda_nu = 0.5;
            double M = 0, sum_mu = 0, lambda_mu = 0.1, sum_w = 0;
            double y = 0, y_LB = 0, y_UB = 0;
            double[] w = new double[day_size];
            double[] day_cost = new double[day_size];

            string str_route = "", opt_str_route = "";
            double primal = 0, dual = 0, gap = 0, dual_b = 0;
            int iteration = 0;
            double opt_dual = 0, opt_primal = 10000, opt_gap = 10000;
            Random rdm = new Random(123);
            double[] ary_dual = new double[max_iteration];
            out_opt_primal = 10000;

            // initial multi-day link travel time ////////////////////////////////////////////////////////////////////////////////
            // fill no-sensor link TT with random values
            double[][] link_cost = new double[day_size][]; // sample link costs in min
            for (int d = 0; d < day_size; d++)
            {
                link_cost[d] = new double[m_LinkSize];
            }
            Gaussian g = new Gaussian(0);
            double mean = 0, sd = 0, g_value = 0;
            for (int l = 0; l < m_LinkSize; l++)
            {
                if (aryCLink[l].TMC != null && TMCwithRealData.ContainsKey(aryCLink[l].TMC))
                {
                    tmc_index = TMCwithRealData[aryCLink[l].TMC];
                    for (int d = 0; d < day_size; d++)
                    {
                        link_cost[d][l] = aryCLink[l].Link_Length / TMCHistSpd[tmc_index, d] * 60;
                    }
                }
                else
                {
                    g = new Gaussian(l);
                    mean = LinkCost[l];
                    length = aryCLink[l].Link_Length;
                    spd = aryCLink[l].SpeedLimit;
                    for (int d = 0; d < day_size; d++)
                    {
                        sd = Math.Sqrt(day_MeanVar[d]) * (length / spd * 60);
                        g_value = g.NextGaussian3(mean, sd);
                        link_cost[d][l] = g_value;
                    }
                }
            }

            // Step 1: Initialization ////////////////////////////////////////////////////////////////////////////////////////////////////
            // find UB and LB for y
            if (percentile >= 100)
            {
                LinkCost.CopyTo(LinkCost_Penalty, 0);
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                else
                    return -1;
            }
            else
            {
                LinkCost_min.CopyTo(LinkCost_Penalty, 0);
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                else
                    return -1;
            }

            y_LB = 100000; y_UB = 0;
            nu = 0.1;
            double y_temp = 0;
            for (int d = 0; d < day_size; d++)
            {
                y_temp = 0;
                for (int l = 0; l < route.LinkSeq.Length; l++)
                {
                    length = aryCLink[l].Link_Length;
                    if (aryCLink[route.LinkSeq[l]].TMC != null && TMCwithRealData.ContainsKey(aryCLink[route.LinkSeq[l]].TMC))
                    {
                        tmc_index = TMCwithRealData[aryCLink[route.LinkSeq[l]].TMC];
                        y_temp += length / TMCHistSpd[tmc_index, d] * 60;
                    }
                    else
                    {
                        y_temp += aryCLink[route.LinkSeq[l]].TravelTime;
                    }
                    // y_temp += LinkCost_DayD[d][route.LinkSeq[l]];
                }
                if (y_temp > y_UB)
                    y_UB = y_temp;
                if (y_temp < y_LB)
                    y_LB = y_temp;
                // initial LR parameters
                mu[d] = 1 / (double)day_size;
            }
            M = y_UB - y_LB;

            //log.Write(Math.Round(route.PathTime, 2) + "\n");

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            // find primal and dual
            do
            {
                day_cost = new double[day_size];
                // Step 2: solve dual function //////////////////////////////////////////////////////////////////////////////////////////
                // assign link cost for Lx
                double temp = 0;
                for (int l = 0; l < m_LinkSize; l++)
                {
                    temp = 0;
                    for (int d = 0; d < day_size; d++)
                    {
                        temp += mu[d] * link_cost[d][l];
                    }
                    LinkCost_Penalty[l] = temp;
                }

                //Console.WriteLine(iteration + "==================");
                // do shortest path search, find path, solve Lx
                if (ShortestPath_Destination(destination_index, out PredAry))
                    GetRoute(true, origin_index, destination_index, PredAry, 0, false, 0, out route);
                else
                    break;

                // find y, solve Ly
                sum_mu = 0;
                for (int d = 0; d < day_size; d++)
                {
                    sum_mu += mu[d];
                }
                if (1 - sum_mu >= 0)
                    y = y_LB;
                else
                    y = y_UB;

                // solve Lw
                if (percentile < 100)
                {
                    sum_w = 0;
                    for (int d = 0; d < day_size; d++)
                    {
                        if (nu - mu[d] * M >= 0)
                            w[d] = 0;
                        else
                            w[d] = 1;
                        sum_w += w[d];
                    }
                }

                // calculate primal and dual function value
                // dual value L
                dual = 0; str_route = "";
                for (int j = 0; j < route.LinkSeq.Length; j++)
                {
                    dual += LinkCost_Penalty[route.LinkSeq[j]];
                    str_route += aryCLink[route.LinkSeq[j]].ID.ID.ToString() + ",";
                }
                dual += (1 - sum_mu) * y;
                if (percentile < 100)
                {
                    for (int d = 0; d < day_size; d++)
                    {
                        dual += (nu - mu[d] * M) * w[d];
                    }
                    dual = dual - nu * (1 - (double)percentile / 100.0) * (double)day_size;
                }

                // primal value
                double[] y_samples = new double[day_size];
                primal = 0; dual_b = y;
                for (int d = 0; d < day_size; d++)
                {
                    y_temp = 0;
                    for (int l = 0; l < route.LinkSeq.Length; l++)
                    {
                        y_temp += link_cost[d][route.LinkSeq[l]];
                    }
                    y_samples[d] = y_temp;
                    if (y_temp > primal)
                        primal = y_temp;
                    if (percentile >= 100)
                        dual_b += mu[d] * (y_temp - y);
                    else
                        dual_b += mu[d] * (y_temp - y - w[d] * M);
                }
                if (percentile < 100)
                {
                    int[] list = SortingFunction(y_samples, false);
                    M = primal - y_samples[list[percentile * day_size / 100]];
                    primal = y_samples[list[percentile * day_size / 100]];
                    dual_b += nu * (sum_w - (1 - (double)percentile / 100.0) * (double)day_size);
                }

                gap = primal - dual;
                if (gap < 0)
                    gap = 0;

                // find optimal
                if (dual >= opt_dual)
                {
                    opt_dual = dual;
                }
                if (dual > y_LB)
                {
                    y_LB = dual;
                }
                if (primal < opt_primal)
                {
                    opt_primal = primal;
                    y_UB = primal;
                }
                gap = opt_primal - opt_dual;
                if (gap <= opt_gap)
                {
                    opt_gap = gap;
                    opt_str_route = str_route;
                }
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // calculate mu(k+1) and nu(k+1) with subgradient
                sum_w = 0;
                for (int d = 0; d < day_size; d++)
                {
                    stepsize_mu[d] = lambda_mu * (y_UB - y_LB) * (y_samples[d] - y - w[d] * M);
                    mu[d] += stepsize_mu[d];
                    if (mu[d] < 0)
                        mu[d] = 0.001; //////////////
                    sum_w += w[d];
                }
                if (percentile < 100)
                {
                    stepsize_nu = lambda_nu * (y_UB - y_LB) * (sum_w - (double)percentile * (double)day_size);
                    nu += stepsize_nu;
                    if (nu < 0)
                        nu = 0.01;
                }
                lambda_mu = 0.1 / (iteration + 1);
                //lambda_mu = 1 / (1 / lambda_mu + 1);
                lambda_nu = 0.1;// / (iteration + 1);
                //lambda_nu = 1 / (1 / lambda_nu + 1);

                iteration++;
                log.Write(iteration + "\t" + Math.Round(primal, 3) + "\t" + Math.Round(dual, 3) + "\t" + Math.Round(opt_primal, 3) +
                    "\t" + Math.Round(opt_dual, 3) + "\t" + Math.Round(1 - opt_dual / opt_primal, 3) + "\t" + Math.Round(route.PathTime, 3) + "\n");
            }
            while (iteration < max_iteration);

            log.Close();
            out_opt_primal = opt_primal;
            return opt_gap;
        }

        public struct SearchTreeElement
        {
            public int CurrentNode;
            public int PredecessorNode;
            public int SearchLevel;
            public double TravelTime;
        };

        /// <summary>
        /// Find out the longest and shortest link length
        /// </summary>
        /// <param name="longest">return longest link length</param>
        /// <param name="shortest">return shortest link length</param>
        /// <returns>return ratio of longest / shortest</returns>
        public double LinkLengthRange(out double longest, out double shortest)
        {
            longest = 0; 
            shortest = 9999999;
            double length = 0;
            for (int l = 0; l < m_LinkSize; l++)
            {
                length = aryCLink[l].Link_Length;
                if (length > longest)
                    longest = length;
                if (length < shortest)
                    shortest = length;
            }
            if (shortest > 0)
                return longest / shortest;
            else
                return -1;
        }

        public void RouteEnumerator()
        {
            int OD_size = 246;
            //read OD pairs/////////////////////////////////////////
            int[] ary_origin = new int[OD_size], ary_dest = new int[OD_size];
            double[] TTBound = new double[OD_size];
            FileStream nwfsInput = new FileStream(@"netdata/OD_TTBound.csv", FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine = "";
            string[] raw = new string[3];
            int line = 0;
            szSrcLine = nwsrInput.ReadLine(); // read first line (column names)
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                raw = szSrcLine.Split(',');
                ary_origin[line] = m_NodeIDtoIndex[Convert.ToInt32(raw[0])];
                ary_dest[line] = m_NodeIDtoIndex[Convert.ToInt32(raw[1])];
                TTBound[line] = Convert.ToDouble(raw[2]);
                line++;
            }
            nwsrInput.Close();
            nwfsInput.Close();
            LoadHistData_CSV("9am", out day_MeanVar);
            int day_size = TMCHistSpd.GetLength(1);

            int snode = FindClosestNode((float)37.391777, -122.023437);
            int dnode = FindClosestNode((float)36.7003565, (float)-121.6488647);
            int[] PredAry;
            CRoute route = new CRoute();
            LinkCost.CopyTo(LinkCost_Penalty, 0);
            if (ShortestPath_Destination(m_NodeIDtoIndex[dnode], out PredAry))
                GetRoute(true, m_NodeIDtoIndex[snode], m_NodeIDtoIndex[dnode], PredAry, 0, false, 0, out route);
            int origin_index = route.PathAry[0];

            int PathNo = 0;
            bool result = false;
            int[] path_count = new int[route.PathAry.Length - 1];
            double[] time_sec = new double[route.PathAry.Length - 1];
            double[] CostList;
            for (int p = 1; p < 125; p++) // for each node on the test route: route.PathAry.Length
            {
                // calculate initial upper bound for each destination/node on the test route
                double upper_bound = 0, temp = 0;
                for (int d = 0; d < day_size; d++)
                {
                    temp = 0;
                    for (int l = 0; l < p; l++)
                    {
                        temp += LinkCost_DayD[d][route.LinkSeq[l]];
                    }
                    //y_samples[d] = temp;
                    if (temp > upper_bound)
                        upper_bound = temp;
                }
                DateTime s = DateTime.Now;
                ShortestPath_Destination(route.PathAry[p], out PredAry);
                GenerateCostTree_Destination(route.PathAry[p], PredAry, out CostList);
                result = GenerateSearchTree(origin_index, route.PathAry[p], p * 2, upper_bound, CostList, out PathNo);
                TimeSpan time = DateTime.Now - s;
                time_sec[p - 1] = time.TotalSeconds;
                path_count[p - 1] = PathNo;
                //result = GenerateSearchTree(m_NodeIDtoIndex[144842], m_NodeIDtoIndex[12310], m_NodeSize, 51.22, out PathNo);
                //result = GenerateSearchTree(ary_origin[p], ary_dest[p], m_NodeSize, TTBound[p], out PathNo);
            }

            //// test with Lagrangient algorithm
            //Percentile_test_single_route(10, route);

        }
                
        public void GenerateCostTree_Destination(int Dest_index, int[] PredAry, out double[] CostList)
        {
            CostList = new double[m_NodeSize];
            double[] TempList = new double[m_NodeSize];
            for (int i = 0; i < m_NodeSize; i++)
            {
                CostList[i] = -1;
                TempList[i] = 0;
            }
            CostList[Dest_index] = 0;
            double link_cost = 0;            

            for (int i = 0; i < m_NodeSize; i++)
            {
                int NextNode = PredAry[i];
                int CurrentNode = i;
                if (NextNode >= 0)
                {
                    while (CostList[NextNode] < 0)
                    {
                        for (int l = 0; l < InboundLinkSize[NextNode]; l++)
                        {
                            int TempNodeID = aryCLink[InboundLinkAry[NextNode, l]].FromID;
                            if (m_NodeIDtoIndex[TempNodeID] == CurrentNode)
                            {
                                link_cost = LinkCost[InboundLinkAry[NextNode, l]];
                                break;
                            }
                        }
                        TempList[i] += link_cost;
                        CurrentNode = NextNode;
                        NextNode = PredAry[NextNode];
                    }
                    TempList[i] += CostList[NextNode];
                    CostList[i] = TempList[i];
                }
            }
        }

        public void PercentileSingleRouteImpl(int inputIteration)
        {
            LoadHistData_CSV("9am", out day_MeanVar);
            int snode = FindClosestNode((float)37.391777, -122.023437);
            int dnode = FindClosestNode((float)36.7003565, (float)-121.6488647);
            int[] PredAry;
            CRoute route = new CRoute();
            LinkCost.CopyTo(LinkCost_Penalty, 0);
            if (ShortestPath_Destination(m_NodeIDtoIndex[dnode], out PredAry))
                GetRoute(true, m_NodeIDtoIndex[snode], m_NodeIDtoIndex[dnode], PredAry, 0, false, 0, out route);

            Percentile_test_single_route(inputIteration, route);
            return;
        }

        public void Percentile_test_single_route(int input_iteration, CRoute route)
        {
            double[][] gap = new double[input_iteration][], gap_p = new double[input_iteration][];
            double[][] primal = new double[input_iteration][], primal_p = new double[input_iteration][];
            double[][] dual = new double[input_iteration][], dual_p = new double[input_iteration][];
            double[] average_gap = new double[input_iteration], average_gap_p = new double[input_iteration];
            double[] average_primal = new double[input_iteration], average_primal_p = new double[input_iteration];
            double[] average_dual = new double[input_iteration], average_dual_p = new double[input_iteration];
            int OD_size = route.PathAry.Length - 1;
            for (int i = 0; i < input_iteration; i++)
            {
                gap[i] = new double[OD_size];
                primal[i] = new double[OD_size];
                dual[i] = new double[OD_size];
            }
            TextWriter log = new StreamWriter(city + "_Percentile_100_test_log.txt");
            log.WriteLine("ave_p\tave_d\tave_gap");

            TextWriter log_time = new StreamWriter(city + "_Percentile_single_time_log.txt");
            log_time.WriteLine("OD\tOrigin\tDestination\tIteration\tAlgorithm\tARSP_SPLinkCount\tARSP_ComputingTime");

            double[] temp_gap, temp_primal, temp_dual;
            int SPLinkCount = 0;
            TimeSpan time = new TimeSpan();
            CRoute bestRoute = new CRoute();

            for (int p = 0; p < 124; p++) // p < OD_size;
            {
                temp_gap = Percentile_ReliablePath_Single(route.PathAry[0], route.PathAry[p + 1], 100, input_iteration, "branch", out temp_primal, out temp_dual, out SPLinkCount, out time, out bestRoute);
                for (int i = 0; i < input_iteration; i++)
                {
                    gap[i][p] = temp_gap[i];
                    primal[i][p] = temp_primal[i];
                    dual[i][p] = temp_dual[i];
                    average_gap[i] += gap[i][p];
                    average_primal[i] += primal[i][p];
                    average_dual[i] += dual[i][p];
                    if (primal[i][p] >= 10000)
                        primal[i][p] = -1;
                }
                log_time.WriteLine(p + "\t" + route.PathAry[0] + "\t" + route.PathAry[p + 1] + "\t" + input_iteration + "\t" + "branch" + "\t" + SPLinkCount + "\t " + time.ToString());

            }

            for (int i = 0; i < input_iteration; i++)
            {
                average_gap[i] = average_gap[i] / (double)OD_size;
                average_primal[i] = average_primal[i] / (double)OD_size;
                average_dual[i] = average_dual[i] / (double)OD_size;
                log.WriteLine(Math.Round(average_primal[i], 2) + "\t" + Math.Round(average_dual[i], 2) + "\t" + Math.Round(average_gap[i], 4));
            }

            string write = "";
            log.WriteLine("primal");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(primal[i][p], 2) + ",";
                }
                log.WriteLine(write);
            }
            log.WriteLine("dual");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(dual[i][p], 2) + ",";
                }
                log.WriteLine(write);
            }
            log.WriteLine("gap");
            for (int i = 0; i < input_iteration; i++)
            {
                write = "";
                for (int p = 0; p < OD_size; p++)
                {
                    write += Math.Round(gap[i][p], 4) + ",";
                }
                log.WriteLine(write);
            }
            log.Close();
            log_time.Close();
        }

        public bool GenerateSearchTree(int origin_index, int destination_index, int node_size, double Init_TravelTimeBound, double[] CostList, out int PathNo)   
            // Pointer to previous node (node)
        {
        // breadth-first search (BFS) is a graph search algorithm that begins at the root node and explores all the neighboring nodes
        // Then for each of those nearest nodes, it explores their unexplored neighbor nodes, and so on, until it finds the goal.
        // compared to BFS, we continue search even a node has been marked before
        // we allow a loop for simplicity
        // we can add a label cost constraint
            int i;
            double TravelTimeBound = Init_TravelTimeBound;
            int day_size = TMCHistSpd.GetLength(1);
            //int m_TreeListSize = 0; // 100000000;
            int MAX_TreeListSize = 100000000;
            int MAX_List = 60000000;
            List<SearchTreeElement> m_SearchTreeList = new List<SearchTreeElement>();
            //m_SearchTreeList.Capacity = 80000000;

            //for (i = 0; i < m_TreeListSize; i++)
            //{
            //    m_SearchTreeList[i].CurrentNode = 0;
            //    m_SearchTreeList[i].SearchLevel = 0;
            //    m_SearchTreeList[i].TravelTime = 0;
            //    m_SearchTreeList[i].PredecessorNode = -1;
            //}

            SearchTreeElement STE_initial = new SearchTreeElement();
            STE_initial.CurrentNode = 0;
            STE_initial.SearchLevel = 0;
            STE_initial.TravelTime = 0;
            STE_initial.PredecessorNode = -1;

            m_SearchTreeList.Add(STE_initial);

            SearchTreeElement STE = m_SearchTreeList[0];
            STE.CurrentNode = origin_index;
            STE.SearchLevel = 0;
            m_SearchTreeList[0] = STE;

            int m_TreeListFront = 0;
            int m_TreeListTail = 1;
            int From_index, Link_index, To_index;
            PathNo = 0;

            while (m_TreeListTail < MAX_TreeListSize - 1 && m_TreeListFront < m_TreeListTail)
            // not exceed search tree size, or not search to the end of queue/list
            {
                From_index = m_SearchTreeList[m_TreeListFront].CurrentNode;
                if (CostList[From_index] < 0 
                    || From_index == destination_index 
                    || m_SearchTreeList[m_TreeListFront].TravelTime > TravelTimeBound 
                    || m_SearchTreeList[m_TreeListFront].TravelTime + CostList[From_index] > TravelTimeBound
                    || m_SearchTreeList[m_TreeListFront].SearchLevel >= node_size)
                {
                    if (From_index == destination_index)
                    {
                        PathNo++;
                        // calculate ARSP cost for the new path and update TravelTimeBound
                        double temp = 0, ARSP_cost = 0;
                        // generate LinkList for current path
                        int link_size = m_SearchTreeList[m_TreeListFront].SearchLevel;
                        int[] link_list = new int[link_size];
                        int to_node = -1, from_node = -1, count = 0;
                        int Pred = m_TreeListFront;
                        while (Pred != 0)
                        {
                            to_node = m_SearchTreeList[Pred].CurrentNode;
                            Pred = m_SearchTreeList[Pred].PredecessorNode;
                            from_node = m_SearchTreeList[Pred].CurrentNode;
                            for (int l = 0; l < InboundLinkSize[to_node]; l++)
                            {
                                int TempNodeID = aryCLink[InboundLinkAry[to_node, l]].FromID;
                                if (m_NodeIDtoIndex[TempNodeID] == from_node)
                                {
                                    link_list[count] = InboundLinkAry[to_node, l];
                                    count++;
                                    break;
                                }
                            }
                        }
                        // find ARSP cost
                        for (int d = 0; d < day_size; d++)
                        {
                            temp = 0;
                            for (int l = 0; l < link_size; l++)
                            {
                                temp += LinkCost_DayD[d][link_list[l]];
                            }
                            if (temp > ARSP_cost)
                                ARSP_cost = temp;
                        }
                        // update TravelTimeBound
                        if (ARSP_cost > 0 && ARSP_cost < TravelTimeBound)
                            TravelTimeBound = ARSP_cost;
                    }
                    m_TreeListFront++; // move to the next front node for breadth first search
                    continue;
                    // when we finish all search, we should backtrace from a node at position i == destination)
                }

                for (i = 0; i < OutgoingLinkSize[From_index]; i++)  // for each arc (i,j) belong A(j)
                {
                    Link_index = OutgoingLinkAry[From_index, i];
                    To_index = m_NodeIDtoIndex[aryCLink[Link_index].ToID];

                    if (To_index == origin_index)
                        continue;

                    // search if To_index in the path
                    bool bToID_inSubPathFlag = false;
                    {
                        int Pred = m_SearchTreeList[m_TreeListFront].PredecessorNode;
                        while (Pred > 0)
                        {
                            if (m_SearchTreeList[Pred].CurrentNode == To_index)  // in the subpath
                            {
                                bToID_inSubPathFlag = true;
                                break;
                            }
                            Pred = m_SearchTreeList[Pred].PredecessorNode;
                        }
                    }
                    if (bToID_inSubPathFlag)
                        continue;

                    double travel_time = LinkCost[Link_index];

                    m_SearchTreeList.Add(STE_initial);
                    STE = m_SearchTreeList[m_TreeListTail];
                    STE.CurrentNode = To_index;
                    STE.PredecessorNode = m_TreeListFront;
                    STE.SearchLevel = m_SearchTreeList[m_TreeListFront].SearchLevel + 1;
                    STE.TravelTime = m_SearchTreeList[m_TreeListFront].TravelTime + travel_time;
                    m_SearchTreeList[m_TreeListTail] = STE;

                    m_TreeListTail++;

                    if (m_TreeListTail >= MAX_TreeListSize - 1)
                        break;  // the size of list is exceeded   
                }// end of for each link

                m_TreeListFront++; // move to the next front node for breadth first search
                //if (m_TreeListTail > MAX_List && (m_TreeListTail - MAX_List) < m_TreeListFront)
                //{
                //    for (int s = 0; s < MAX_List; s++)
                //    {
                //        STE = m_SearchTreeList[s + (m_TreeListTail - MAX_List)];
                //        STE.PredecessorNode = STE.PredecessorNode - (m_TreeListTail - MAX_List);
                //        if (STE.PredecessorNode < -1)
                //            STE.PredecessorNode = -1;
                //        m_SearchTreeList[s] = STE;
                //    }
                //    m_SearchTreeList.RemoveRange(MAX_List, (m_TreeListTail - MAX_List));
                //    m_TreeListFront = m_TreeListFront - (m_TreeListTail - MAX_List);
                //    m_TreeListTail = MAX_List;
                //}

            } // end of while        

            //for (i = 0; i < m_TreeListTail; i++)
            //{
            //    if (m_SearchTreeList[i].CurrentNode == destination_index)
            //    {
            //        int Pred = m_SearchTreeList[i].PredecessorNode;

            //        while (Pred != 0)
            //        {
            //            Pred = m_SearchTreeList[Pred].PredecessorNode;
            //        }
            //        PathNo++;
            //    }
            //}

            m_SearchTreeList.Clear();
            if (m_TreeListFront == m_TreeListTail && m_TreeListTail < MAX_TreeListSize - 1)
                return true;
            else
                return false;  // has not be enumerated.
        }


        /// <summary>
        /// sorting function
        /// </summary>
        /// <param name="list">original double list</param>
        /// <param name="order">sorting order: 1 - decrease; 0 - increase</param>
        /// <param name="sortedIndex">output, sorted index of the original list</param>
        /// <returns>sorted list</returns>        
        private double[] sortDouble(double[] list, bool order, out int[] sortedIndex)
        {
            if (list == null || list.Length <= 0)
            {
                sortedIndex = null;
                return null;
            }
            // initial
            double MIN_DOUBLE = double.MinValue;
            double MAX_DOUBLE = double.MaxValue;

            int listSize = list.Length;
            sortedIndex = new int[listSize];
            double[] newList = new double[listSize];
            if (order)
            {
                for (int k = 0; k < listSize; k++)
                {
                    newList[k] = MIN_DOUBLE;
                }
            }
            else
            {
                for (int k = 0; k < listSize; k++)
                {
                    newList[k] = MAX_DOUBLE;
                }
            }
            int newListSize = 0;

            // initial first element
            newList[0] = list[0];
            sortedIndex[0] = 0;
            newListSize++;

            for (int d = 1; d < listSize; d++)
            {
                if (order)
                {
                    for (int k = 0; k < listSize; k++)
                    {
                        if (list[d] >= newList[k])
                        {
                            for (int kk = newListSize; kk > k; kk--)
                            {
                                newList[kk] = newList[kk - 1];
                                sortedIndex[kk] = sortedIndex[kk - 1];
                            }
                            newList[k] = list[d];
                            sortedIndex[k] = d;
                            newListSize++;
                            break;
                        }
                    }
                }
                else
                {
                    for (int k = 0; k < listSize; k++)
                    {
                        if (list[d] <= newList[k])
                        {
                            for (int kk = newListSize; kk > k; kk--)
                            {
                                newList[kk] = newList[kk - 1];
                                sortedIndex[kk] = sortedIndex[kk - 1];
                            }
                            newList[k] = list[d];
                            sortedIndex[k] = d;
                            newListSize++;
                            break;
                        }
                    }
                }
                if (newListSize > newList.Length)
                {
                    return new double[listSize];
                }
            }
            return newList;
        }


        public bool SensorLocator(bool NonRecurring, int beamWidth, out TimeSpan timeCost, out double bestLogDet)
        {

            int HWLinkSize = m_LinkSize;// 80; // 626 * 2;
            int[] HWList = new int[HWLinkSize];
            int LoopCandidateSize = m_LinkSize;//  91 * 2;
            int[] LoopCandidateList = new int[LoopCandidateSize];
            int count = 0, count_c = 0;
            for (int l = 0; l < m_LinkSize; l++)
            {
                //if (aryCLink[l].Link_Type <= 2)
                {
                    HWList[count] = l;
                    count++;
                    //if (aryCLink[l].Link_Type <= 2)
                    {
                        LoopCandidateList[count_c] = count;
                        count_c++;
                    }
                }
            }


            int ZoneSize = 16;// 61;
            double[,] ZoneDemand = new double[ZoneSize, ZoneSize];
            int count_o = ZoneSize, count_d = ZoneSize;
            //// Readin Demand in Dat file /////////////////////////////
            //FileStream nwfsInput = new FileStream(@"C:\DATA\Irvine_gis\demand.dat", FileMode.Open, FileAccess.Read);
            //StreamReader nwsrInput = new StreamReader(nwfsInput);
            //string szSrcLine = "", subStr = "";
            //int index = 0, line = 0, time = 0;
            //while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //{
            //    if (line == time * (ZoneSize * 11 + 1) + 3)
            //    {
            //        time++;
            //        count_o = 0;
            //        count_d = 0;
            //    }
            //    if (count_o < ZoneSize && count_d < ZoneSize)
            //    {
            //        szSrcLine = szSrcLine.Trim();
            //        while (szSrcLine.IndexOf(".") != -1)
            //        {
            //            index = szSrcLine.IndexOf(".");
            //            subStr = szSrcLine.Substring(0, index + 5);
            //            ZoneDemand[count_o, count_d] += double.Parse(subStr);
            //            count_d++;
            //            if (count_d >= ZoneSize)
            //            {
            //                count_o++;
            //                count_d = 0;
            //            }
            //            szSrcLine = szSrcLine.Substring(index + 5);
            //        }
            //    }
            //    line++;
            //}
            //nwsrInput.Close();
            //nwfsInput.Close();
            //int ODSize = 23; // 93;

            //// Readin Demand in txt file /////////////////////////////
            //FileStream nwfsInput = new FileStream(@"C:\works\NEXTA2.0\DataSets\Irvine\demand.txt", FileMode.Open, FileAccess.Read);
            //StreamReader nwsrInput = new StreamReader(nwfsInput);
            //string szSrcLine = "", subStr = "";
            //int index = 0, line = 0, time = 0;
            //while ((szSrcLine = nwsrInput.ReadLine()) != null)
            //{
            //    if (line >= 11)
            //    {
            //        szSrcLine = szSrcLine.Trim();
            //        while (szSrcLine.IndexOf(",") != -1)
            //        {
            //            index = szSrcLine.IndexOf(",");
            //            subStr = szSrcLine.Substring(0, index);
            //            count_o = int.Parse(subStr);
            //            szSrcLine = szSrcLine.Substring(index + 1);
            //            index = szSrcLine.IndexOf(",");
            //            subStr = szSrcLine.Substring(0, index);
            //            count_d = int.Parse(subStr);
            //            szSrcLine = szSrcLine.Substring(index + 1);
            //            szSrcLine = szSrcLine.Trim();
            //            ZoneDemand[count_o - 1, count_d - 1] = double.Parse(szSrcLine);
            //        }
            //    }
            //    line++;
            //}
            //nwsrInput.Close();
            //nwfsInput.Close();
            int ODSize = 10;// 69; // 23 // 93;


            // find OD to node list
            int[] ZonetoNodeList = new int[ZoneSize];
            //for (int zone = 0; zone < ZoneSize; zone++)
            //{
            //    for (int i = 0; i < m_NodeSize; i++)
            //    {
            //        if (aryCNode[i].Node_AreaID == zone)
            //        {
            //            ZonetoNodeList[zone] = i;
            //            break;
            //        }
            //    }
            //}
            // find ODs in node, read in OD flows            
            double[] OD_flow = new double[ODSize];
            int[] ary_origin = new int[ODSize], ary_dest = new int[ODSize];
            //count_o = 0; count_d = 0;
            //for (int o = 0; o < ZoneSize; o++)
            //{
            //    for (int d = 0; d < ZoneSize; d++)
            //    {
            //        if (ZoneDemand[o, d] > 20 && o != d)
            //        {
            //            ary_origin[count_o] = ZonetoNodeList[o];
            //            ary_dest[count_d] = ZonetoNodeList[d];
            //            OD_flow[count_o] = ZoneDemand[o, d];
            //            count_o++; count_d++;
            //        }
            //    }
            //}
            ary_origin = new int[] { 11, 10, 29, 0, 10, 21, 29, 10, 0, 0 };
            ary_dest = new int[] { 10, 0, 0, 10, 29, 0, 10, 11, 21, 29 };
            OD_flow = new double[] { 4000, 6820, 1152, 2480, 832, 880, 680, 4800, 604, 444 };
            ODSize = 10;
            // find shortest path for ODs
            int[][] OD_LinkList = new int[ODSize][];
            int[] PredAry;
            CRoute route = new CRoute();
            double[,] LinkFlowMatrix = new double[m_LinkSize, m_LinkSize]; // calculate link-based flow count
            int total_flow = 0;
            for (int i = 0; i < ODSize; i++)
            {
                if (ShortestPath_Destination(ary_dest[i], out PredAry))
                    GetRoute(true, ary_origin[i], ary_dest[i], PredAry, 0, false, 0, out route);
                if (route != null)
                    OD_LinkList[i] = route.LinkSeq;
                int link_count = route.LinkSeq.Length;
                for (int l = 0; l < link_count; l++)
                {
                    LinkFlowMatrix[route.LinkSeq[l], route.LinkSeq[l]] += OD_flow[i];
                    for (int ll = l + 1; ll < link_count; ll++)
                    {
                        LinkFlowMatrix[route.LinkSeq[l], route.LinkSeq[ll]] += OD_flow[i];
                        LinkFlowMatrix[route.LinkSeq[ll], route.LinkSeq[l]] += OD_flow[i];
                    }
                }
                total_flow += link_count * link_count * (int)OD_flow[i];
            }
            string StrLinkFlowMatrix = "";
            for (int l = 0; l < m_LinkSize; l++)
            {
                for (int ll = 0; ll < m_LinkSize; ll++)
                {
                    StrLinkFlowMatrix += LinkFlowMatrix[l, ll].ToString() + ",";
                }
                StrLinkFlowMatrix += ";";
            }
            int te = 0;

            // load incident rate data
            FileStream nwfsInput = new FileStream(@"C:\Research\sensor location\Irvine Incident Rate.csv", FileMode.Open, FileAccess.Read);
            StreamReader nwsrInput = new StreamReader(nwfsInput);
            string szSrcLine = "";
            string[] row_str = new string[3];
            int o_id = 0, d_id = 0, incident_rate = 0;
            szSrcLine = nwsrInput.ReadLine(); // jump first line
            int count_safety = 0;
            while ((szSrcLine = nwsrInput.ReadLine()) != null)
            {
                row_str = szSrcLine.Split('\t');
                o_id = int.Parse(row_str[0]);
                d_id = int.Parse(row_str[1]);
                incident_rate = int.Parse(row_str[2]);
                for (int l = 0; l < m_LinkSize; l++)
                {
                    if (aryCLink[l].FromID == o_id && aryCLink[l].ToID == d_id)
                    {
                        aryCLink[l].Safety = aryCLink[l].Link_Length * incident_rate / 365 / 24; // hourly incident probability
                        count_safety++;
                        break;
                    }
                }
            }

            DateTime start = DateTime.Now;

            Dictionary<int, int[]> ANL = new Dictionary<int, int[]>(); // active node list            
            Dictionary<int, double> ANL_value = new Dictionary<int, double>(); // objective function values for ANL
            Dictionary<int, int> ANL_node = new Dictionary<int, int>(); // a temp container for ANL node
            int theta = beamWidth, father_count = 0, ANL_NodeSize = 0;
            int Max_ANLSize = 1000000, Max_Loop = 16, Max_AVI = 6;
            int level = 0;
            bool ScanFlag = true;
            double temp_value = 0;
            double[] temp_sort;
            int[] sort_index;
            int[] BestLoopSensor = null, BestAVISensor = null;
            double[] OD_value = new double[ODSize];

            // Define matrix P_minus and Sigma_minus
            DenseMatrix P_minus = new DenseMatrix(HWLinkSize, HWLinkSize);
            for (int row = 0; row < HWLinkSize; row++)
            {
                P_minus[row, row] = aryCLink[HWList[row]].TravelTime * aryCLink[HWList[row]].TravelTime;
                if (P_minus[row, row] == 0)
                {
                    if (aryCLink[row].Link_Type <= 2)
                        P_minus[row, row] = 4;
                    else
                        P_minus[row, row] = 1;
                }
            }
            DenseMatrix Sigma_minus = new DenseMatrix(HWLinkSize, HWLinkSize);
            DenseMatrix Sigma_plus = new DenseMatrix(HWLinkSize, HWLinkSize);
            for (int row = 0; row < HWLinkSize; row++)
            {
                Sigma_minus[row, row] = aryCLink[HWList[row]].TravelTime * aryCLink[HWList[row]].TravelTime;
                if (Sigma_minus[row, row] == 0)
                {
                    if (aryCLink[row].Link_Type <= 2)
                        Sigma_minus[row, row] = 4;
                    else
                        Sigma_minus[row, row] = 1;
                }
            }
            // estimation error matrix before locate sensors
            for (int p = 0; p < ODSize; p++)
            {
                temp_value = 0;
                for (int row = 0; row < OD_LinkList[p].Length; row++)
                {
                    for (int col = 0; col < OD_LinkList[p].Length; col++)
                        temp_value += P_minus[OD_LinkList[p][row], OD_LinkList[p][col]];
                }
                OD_value[p] = temp_value;
            }

            // for GPS and pre-installed sensor network, calculate historical P_minus first
            // links with loop sensor are set to be lane_size == 9
            int[] Current = new int[16];
            DenseMatrix P_plus = new DenseMatrix(HWLinkSize, HWLinkSize);
            count = 0;
            if (false) // for calculation with pre-installed point sensor
            {
                DenseMatrix H = new DenseMatrix(16, HWLinkSize);
                DenseMatrix R = new DenseMatrix(16, 16);
                for (int k = 0; k < m_LinkSize; k++)
                {
                    if (aryCLink[k].LaneSize == 9)
                    {
                        H[count, k] = 1; // loop detector
                        R[count, count] = 1;
                        Current[count] = k;
                        count++;
                    }
                }
                DenseMatrix P_minus_inv = (DenseMatrix)P_minus.Inverse();
                DenseMatrix product = (DenseMatrix)H.TransposeThisAndMultiply(H);
                P_plus = (DenseMatrix)(P_minus_inv + product).Inverse();
                if (NonRecurring)
                {
                    DenseMatrix Q = new DenseMatrix(HWLinkSize, HWLinkSize);
                    DenseMatrix Q_NR = new DenseMatrix(HWLinkSize, HWLinkSize);
                    DenseMatrix L = new DenseMatrix(HWLinkSize, HWLinkSize);
                    for (int k = 0; k < HWLinkSize; k++)
                    {
                        L[k, k] = 2;
                        Q[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
                        Q_NR[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
                    }
                    DenseMatrix Sigma_minus_inv = (DenseMatrix)Sigma_minus.Inverse();
                    DenseMatrix Sigma_product = (DenseMatrix)H.TransposeThisAndMultiply(H);
                    Sigma_plus = (DenseMatrix)(Sigma_minus_inv + Sigma_product).Inverse();
                    DenseMatrix Sigma_plus_product = (DenseMatrix)(L * Sigma_plus).TransposeAndMultiply(L);
                    for (int k = 0; k < HWLinkSize; k++)
                    {
                        P_plus[k, k] = P_plus[k, k] + Q[k, k] + (Q_NR[k, k] + Sigma_plus_product[k, k]) * aryCLink[k].Safety;
                    }
                }
                for (int p = 0; p < ODSize; p++)
                {
                    temp_value = 0;
                    for (int row = 0; row < OD_LinkList[p].Length; row++)
                    {
                        for (int col = 0; col < OD_LinkList[p].Length; col++)
                            temp_value += P_plus[OD_LinkList[p][row], OD_LinkList[p][col]];
                    }
                    OD_value[p] = temp_value;
                }
            }

            //P_minus = P_plus;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //ANL.Add(0, Current); P_minus = P_plus;
            // loop detector
            while (ANL.Count <= Max_ANLSize && ScanFlag == true)
            {
                // generate child node: add one link from CandidateLink for each child
                if (ANL.Count == 0)
                {
                    count = 0;
                    ScanFlag = false;
                    // create temp container
                    int[] temp = new int[1];
                    ANL_node.Clear();
                    // create child nodes
                    for (int l = 0; l < LoopCandidateSize; l++)
                    {
                        if (!ANL_node.ContainsKey(l))
                        {
                            temp = new int[1];
                            temp[ANL_NodeSize] = l;
                            ANL.Add(count, temp);
                            count++;
                            ScanFlag = true;
                        }
                    }
                }
                else
                {
                    father_count = ANL.Count;
                    count = father_count;
                    ScanFlag = false;
                    for (int i = 0; i < father_count; i++)
                    {
                        ANL_NodeSize = ANL[i].Length;
                        if (ANL_NodeSize < Max_Loop)
                        {
                            // create temp container
                            int[] temp = new int[ANL_NodeSize + 1];
                            ANL[i].CopyTo(temp, 0);
                            ANL_node.Clear();
                            // copy node to a dictionary
                            for (int k = 0; k < ANL[i].Length; k++)
                            {
                                ANL_node.Add(ANL[i][k], 0);
                            }
                            // create child nodes
                            for (int l = 0; l < LoopCandidateSize; l++)
                            {
                                if (!ANL_node.ContainsKey(l))
                                {
                                    temp = new int[ANL_NodeSize + 1];
                                    ANL[i].CopyTo(temp, 0);
                                    temp[ANL_NodeSize] = l;
                                    ANL.Add(count, temp);
                                    count++;
                                    ScanFlag = true;
                                }
                            }
                        }
                    }
                }
                level++;

                // calculate objective function values for ANL
                for (int i = 0; i < ANL.Count; i++)
                {
                    ANL_NodeSize = ANL[i].Length;
                    if (!ANL_value.ContainsKey(i))
                    {
                        DenseMatrix H = new DenseMatrix(ANL_NodeSize, HWLinkSize);
                        DenseMatrix R = new DenseMatrix(ANL_NodeSize, ANL_NodeSize);
                        for (int k = 0; k < ANL_NodeSize; k++)
                        {
                            H[k, ANL[i][k]] = 1; // loop detector
                            R[k, k] = 1;
                        }
                        DenseMatrix P_minus_inv = (DenseMatrix)P_minus.Inverse();
                        DenseMatrix product = (DenseMatrix)H.TransposeThisAndMultiply(H);
                        P_plus = (DenseMatrix)(P_minus_inv + product).Inverse();
                        if (NonRecurring)
                        {
                            DenseMatrix Q = new DenseMatrix(HWLinkSize, HWLinkSize);
                            DenseMatrix Q_NR = new DenseMatrix(HWLinkSize, HWLinkSize);
                            DenseMatrix L = new DenseMatrix(HWLinkSize, HWLinkSize);
                            for (int k = 0; k < HWLinkSize; k++)
                            {
                                L[k, k] = 2;
                                Q[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
                                Q_NR[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
                            }
                            DenseMatrix Sigma_minus_inv = (DenseMatrix)Sigma_minus.Inverse();
                            DenseMatrix Sigma_product = (DenseMatrix)H.TransposeThisAndMultiply(H);
                            Sigma_plus = (DenseMatrix)(Sigma_minus_inv + Sigma_product).Inverse();
                            DenseMatrix Sigma_plus_product = (DenseMatrix)(L * Sigma_plus).TransposeAndMultiply(L);
                            for (int k = 0; k < HWLinkSize; k++)
                            {
                                P_plus[k, k] = P_plus[k, k] + Q[k, k] + (Q_NR[k, k] + Sigma_plus_product[k, k]) * aryCLink[k].Safety;
                            }
                        }
                        ANL_value.Add(i, 0);
                        //// for flow based heuristic
                        //for (int p = 0; p < ODSize; p++)
                        //{
                        //    temp_value = 0;
                        //    for (int row = 0; row < OD_LinkList[p].Length; row++)
                        //    {
                        //        for (int col = 0; col < OD_LinkList[p].Length; col++)
                        //            temp_value += P_plus[OD_LinkList[p][row], OD_LinkList[p][col]];
                        //    }
                        //    ANL_value[i] += temp_value * OD_flow[p];
                        //}

                        //// comparison ONLY, for heuristic without flow weight
                        //for (int row = 0; row < m_LinkSize; row++)
                        //{
                        //    for (int col = 0; col < m_LinkSize; col++)
                        //        ANL_value[i] += P_plus[row, col];
                        //}

                        // comparison ONLY, for heuristic without flow weight, using logdet
                        ANL_value[i] = Math.Log(P_plus.Determinant());

                    }
                }

                // node filtering: sort and select theta best nodes
                temp_sort = new double[ANL_value.Count];
                for (int i = 0; i < ANL_value.Count; i++)
                {
                    temp_sort[i] = ANL_value[i];
                }
                sort_index = SortingFunction(temp_sort, false);
                Dictionary<int, int[]> ANL_temp = new Dictionary<int, int[]>();
                Dictionary<int, double> ANL_value_temp = new Dictionary<int, double>();
                for (int i = 0; i < theta; i++)
                {
                    ANL_temp.Add(i, ANL[sort_index[i]]);
                    ANL_value_temp.Add(i, ANL_value[sort_index[i]]);
                }
                ANL = ANL_temp;
                ANL_value = ANL_value_temp;
            }

            // find best sensor network
            temp_sort = new double[ANL_value.Count];
            for (int i = 0; i < ANL_value.Count; i++)
            {
                temp_sort[i] = ANL_value[i];
            }
            sort_index = SortingFunction(temp_sort, false);
            BestLoopSensor = ANL[sort_index[0]];
            bestLogDet = ANL_value[0];
            int[,] LinkList = new int[BestLoopSensor.Length, 2];
            for (int k = 0; k < BestLoopSensor.Length; k++)
            {
                LinkList[k, 0] = aryCLink[BestLoopSensor[k]].FromID;
                LinkList[k, 1] = aryCLink[BestLoopSensor[k]].ToID;
            }

            // analysis the best result
            OD_value = new double[ODSize];
            count = 0;
            {
                DenseMatrix H = new DenseMatrix(BestLoopSensor.Length, HWLinkSize);
                DenseMatrix R = new DenseMatrix(BestLoopSensor.Length, BestLoopSensor.Length);
                for (int k = 0; k < BestLoopSensor.Length; k++)
                {
                    H[k, BestLoopSensor[k]] = 1; // loop detector
                    R[k, k] = 1;
                }
                DenseMatrix P_minus_inv = (DenseMatrix)P_minus.Inverse();
                DenseMatrix product = (DenseMatrix)H.TransposeThisAndMultiply(H);
                P_plus = (DenseMatrix)(P_minus_inv + product).Inverse();
                if (NonRecurring)
                {
                    DenseMatrix Q = new DenseMatrix(HWLinkSize, HWLinkSize);
                    DenseMatrix Q_NR = new DenseMatrix(HWLinkSize, HWLinkSize);
                    DenseMatrix L = new DenseMatrix(HWLinkSize, HWLinkSize);
                    for (int k = 0; k < HWLinkSize; k++)
                    {
                        L[k, k] = 2;
                        Q[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
                        Q_NR[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
                    }
                    DenseMatrix Sigma_minus_inv = (DenseMatrix)Sigma_minus.Inverse();
                    DenseMatrix Sigma_product = (DenseMatrix)H.TransposeThisAndMultiply(H);
                    Sigma_plus = (DenseMatrix)(Sigma_minus_inv + Sigma_product).Inverse();
                    DenseMatrix Sigma_plus_product = (DenseMatrix)(L * Sigma_plus).TransposeAndMultiply(L);
                    for (int k = 0; k < HWLinkSize; k++)
                    {
                        P_plus[k, k] = P_plus[k, k] + Q[k, k] + (Q_NR[k, k] + Sigma_plus_product[k, k]) * aryCLink[k].Safety;
                    }
                }
                for (int p = 0; p < ODSize; p++)
                {
                    temp_value = 0;
                    for (int row = 0; row < OD_LinkList[p].Length; row++)
                    {
                        for (int col = 0; col < OD_LinkList[p].Length; col++)
                            temp_value += P_plus[OD_LinkList[p][row], OD_LinkList[p][col]];
                    }
                    OD_value[p] = temp_value;
                }
            }
            
            DateTime end = DateTime.Now;
            TimeSpan period = end - start;
            timeCost = period;

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //// AVI sensors
            //int AVICandidateSize = m_NodeSize;
            //int[] AVICandidateList = new int[AVICandidateSize];
            //for (int n = 0; n < m_NodeSize; n++)
            //{
            //    AVICandidateList[n] = n;
            //}
            //ANL.Clear(); ANL_value.Clear(); ANL_node.Clear();
            //ScanFlag = true;
            //while (ANL.Count <= Max_ANLSize && ScanFlag == true)
            //{
            //    // generate child node: add one link from CandidateLink for each child
            //    if (ANL.Count == 0)
            //    {
            //        count = 0;
            //        ScanFlag = false;
            //        // create temp container
            //        int[] temp = new int[2];
            //        ANL_node.Clear();
            //        // create child nodes
            //        for (int n = 0; n < AVICandidateSize; n++)
            //        {
            //            for (int n2 = 0; n2 < AVICandidateSize; n2++)
            //            {
            //                if (AVICandidateList[n] != AVICandidateList[n2])
            //                {
            //                    temp = new int[2];
            //                    temp[0] = AVICandidateList[n]; temp[1] = AVICandidateList[n2];
            //                    ANL.Add(count, temp);
            //                    count++;
            //                    ScanFlag = true;
            //                }
            //            }
            //        }
            //    }
            //    else
            //    {
            //        father_count = ANL.Count;
            //        count = father_count;
            //        ScanFlag = false;
            //        for (int i = 0; i < father_count; i++)
            //        {
            //            ANL_NodeSize = ANL[i].Length;
            //            if (ANL_NodeSize < Max_AVI)
            //            {
            //                // create temp container
            //                int[] temp = new int[ANL_NodeSize + 1];
            //                ANL[i].CopyTo(temp, 0);
            //                ANL_node.Clear();
            //                // copy node to a dictionary
            //                for (int k = 0; k < ANL[i].Length; k++)
            //                {
            //                    ANL_node.Add(ANL[i][k], 0);
            //                }
            //                // create child nodes
            //                for (int n = 0; n < AVICandidateSize; n++)
            //                {
            //                    if (!ANL_node.ContainsKey(n))
            //                    {
            //                        temp = new int[ANL_NodeSize + 1];
            //                        ANL[i].CopyTo(temp, 0);
            //                        temp[ANL_NodeSize] = AVICandidateList[n];
            //                        ANL.Add(count, temp);
            //                        count++;
            //                        ScanFlag = true;
            //                    }
            //                }
            //            }
            //        }
            //    }
            //    level++;

            //    // calculate objective function values for ANL                
            //    for (int i = 0; i < ANL.Count; i++)
            //    {
            //        ANL_NodeSize = ANL[i].Length;
            //        if (!ANL_value.ContainsKey(i))
            //        {
            //            DenseMatrix H = new DenseMatrix(AVICandidateSize * (AVICandidateSize - 1) + 16, HWLinkSize);
            //            DenseMatrix R = new DenseMatrix(ANL_NodeSize, ANL_NodeSize);
            //            count = 0;
            //            for (int k = 0; k < m_LinkSize; k++)
            //            {
            //                if (aryCLink[k].LaneSize == 9)
            //                {
            //                    H[count, k] = 1; // loop detector
            //                    //R[count, count] = 1;
            //                    Current[count] = k;
            //                    count++;
            //                }
            //            }
            //            count = 0;
            //            for (int k = 0; k < ANL_NodeSize; k++)
            //            {
            //                for (int k2 = 0; k2 < ANL_NodeSize; k2++)
            //                {
            //                    if (ShortestPath_Destination(ANL[i][k2], out PredAry))
            //                        GetRoute(true, ANL[i][k], ANL[i][k2], PredAry, 0, false, 0, out route);
            //                    if (route != null)
            //                        for (int l = 0; l < route.LinkSeq.Length; l++)
            //                            H[16 + count, route.LinkSeq[l]] = 1;
            //                    count++;
            //                }
            //                R[k, k] = 1;
            //            }
            //            DenseMatrix P_minus_inv = NMathFunctions.Inverse(P_minus);
            //            DenseMatrix product = NMathFunctions.Product(H, H, ProductTransposeOption.TransposeFirst);
            //            P_plus = NMathFunctions.Inverse(P_minus_inv + product);
            //            if (NonRecurring)
            //            {
            //                DenseMatrix Q = new DenseMatrix(HWLinkSize, HWLinkSize);
            //                DenseMatrix Q_NR = new DenseMatrix(HWLinkSize, HWLinkSize);
            //                DenseMatrix L = new DenseMatrix(HWLinkSize, HWLinkSize);
            //                for (int k = 0; k < HWLinkSize; k++)
            //                {
            //                    L[k, k] = 2;
            //                    Q[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
            //                    Q_NR[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
            //                }
            //                DenseMatrix Sigma_minus_inv = NMathFunctions.Inverse(Sigma_minus);
            //                DenseMatrix Sigma_product = NMathFunctions.Product(H, H, ProductTransposeOption.TransposeFirst);
            //                Sigma_plus = NMathFunctions.Inverse(Sigma_minus_inv + Sigma_product);
            //                DenseMatrix Sigma_plus_product = NMathFunctions.Product(NMathFunctions.Product(L, Sigma_plus), L, ProductTransposeOption.TransposeSecond);
            //                for (int k = 0; k < HWLinkSize; k++)
            //                {
            //                    P_plus[k, k] = P_plus[k, k] + Q[k, k] + (Q_NR[k, k] + Sigma_plus_product[k, k]) * aryCLink[k].Safety;
            //                }
            //            }
            //            ANL_value.Add(i, 0);
            //            for (int p = 0; p < ODSize; p++)
            //            {
            //                temp_value = 0;
            //                for (int row = 0; row < OD_LinkList[p].Length; row++)
            //                {
            //                    for (int col = 0; col < OD_LinkList[p].Length; col++)
            //                        temp_value += P_plus[OD_LinkList[p][row], OD_LinkList[p][col]];
            //                }
            //                ANL_value[i] += temp_value * OD_flow[p];
            //            }
            //        }
            //    }

            //    // node filtering: sort and select theta best nodes
            //    temp_sort = new double[ANL_value.Count];
            //    for (int i = 0; i < ANL_value.Count; i++)
            //    {
            //        temp_sort[i] = ANL_value[i];
            //    }
            //    sort_index = SortingFunction(temp_sort, false);
            //    Dictionary<int, int[]> ANL_temp = new Dictionary<int, int[]>();
            //    Dictionary<int, double> ANL_value_temp = new Dictionary<int, double>();
            //    for (int i = 0; i < theta; i++)
            //    {
            //        ANL_temp.Add(i, ANL[sort_index[i]]);
            //        ANL_value_temp.Add(i, ANL_value[sort_index[i]]);
            //    }
            //    ANL = ANL_temp;
            //    ANL_value = ANL_value_temp;
            //}

            //// find best sensor network
            //temp_sort = new double[ANL_value.Count];
            //for (int i = 0; i < ANL_value.Count; i++)
            //{
            //    temp_sort[i] = ANL_value[i];
            //}
            //sort_index = SortingFunction(temp_sort, false);
            //BestAVISensor = ANL[sort_index[0]];

            //// analysis the best result
            //OD_value = new double[ODSize];
            //count = 0;
            //{
            //    DenseMatrix H = new DenseMatrix(16 + BestAVISensor.Length, HWLinkSize);
            //    DenseMatrix R = new DenseMatrix(16 + BestAVISensor.Length, 16 + BestAVISensor.Length);
            //    count = 0;
            //    for (int k = 0; k < m_LinkSize; k++)
            //    {
            //        if (aryCLink[k].LaneSize == 9)
            //        {
            //            H[count, k] = 1; // loop detector
            //            //R[count, count] = 1;
            //            Current[count] = k;
            //            count++;
            //        }
            //    }
            //    for (int k = 0; k < BestAVISensor.Length; k++)
            //    {
            //        H[16 + k, BestAVISensor[k]] = 1; // loop detector
            //        //R[k, k] = 1;
            //    }
            //    DenseMatrix P_minus_inv = NMathFunctions.Inverse(P_minus);
            //    DenseMatrix product = NMathFunctions.Product(H, H, ProductTransposeOption.TransposeFirst);
            //    P_plus = NMathFunctions.Inverse(P_minus_inv + product);
            //    if (NonRecurring)
            //    {
            //        DenseMatrix Q = new DenseMatrix(HWLinkSize, HWLinkSize);
            //        DenseMatrix Q_NR = new DenseMatrix(HWLinkSize, HWLinkSize);
            //        DenseMatrix L = new DenseMatrix(HWLinkSize, HWLinkSize);
            //        for (int k = 0; k < HWLinkSize; k++)
            //        {
            //            L[k, k] = 2;
            //            Q[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
            //            Q_NR[k, k] = aryCLink[k].TravelTime * 0.2 * aryCLink[k].TravelTime * 0.2;
            //        }
            //        DenseMatrix Sigma_minus_inv = NMathFunctions.Inverse(Sigma_minus);
            //        DenseMatrix Sigma_product = NMathFunctions.Product(H, H, ProductTransposeOption.TransposeFirst);
            //        Sigma_plus = NMathFunctions.Inverse(Sigma_minus_inv + Sigma_product);
            //        DenseMatrix Sigma_plus_product = NMathFunctions.Product(NMathFunctions.Product(L, Sigma_plus), L, ProductTransposeOption.TransposeSecond);
            //        for (int k = 0; k < HWLinkSize; k++)
            //        {
            //            P_plus[k, k] = P_plus[k, k] + Q[k, k] + (Q_NR[k, k] + Sigma_plus_product[k, k]) * aryCLink[k].Safety;
            //        }
            //    }
            //    for (int p = 0; p < ODSize; p++)
            //    {
            //        temp_value = 0;
            //        for (int row = 0; row < OD_LinkList[p].Length; row++)
            //        {
            //            for (int col = 0; col < OD_LinkList[p].Length; col++)
            //                temp_value += P_plus[OD_LinkList[p][row], OD_LinkList[p][col]];
            //        }
            //        OD_value[p] = temp_value;
            //    }
            //}
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            // draw pix
            Bitmap bmp = DrawSensor(2000, BestLoopSensor, BestAVISensor);
            DateTime timetag = DateTime.Now;
            string filename = "new_" + timetag.Minute.ToString() + "_img.bmp";
            bmp.Save(filename);
            bmp.Dispose();

            //*/

            return true;
        }

        public void PathEnumeration(double ori_lat, double ori_long, double dest_lat, double dest_long)
        {
            int originID = FindClosestNode(ori_lat, ori_long);
            int destinationID = FindClosestNode(dest_lat, dest_long);
            int[] PredAry;
            CRoute[] K_routes;
            int origin_index = m_NodeIDtoIndex[originID], destination_index = m_NodeIDtoIndex[destinationID];

            K_ShortestPath_Unsorted(originID, destinationID, 0, 9, out K_routes);

            // draw pix
            Bitmap bmp = DrawRoute(2000, K_routes);
            DateTime timetag = DateTime.Now;
            string filename = timetag.Minute.ToString() + "_img.bmp";
            bmp.Save(filename);
            bmp.Dispose();

        }

        public int FindClosestNode(double lat, double lon)
        {
            double dist = 0, min_dist = Math.Pow((aryCNode[0].Node_Lat - lat), 2) + Math.Pow((aryCNode[0].Node_Long - lon), 2);
            int curr_nodeID = m_NodeIndextoID[0];
            for (int i = 0; i < m_NodeSize; i++)
            {
                dist = Math.Pow((aryCNode[i].Node_Lat - lat), 2) + Math.Pow((aryCNode[i].Node_Long - lon), 2);
                if (dist < min_dist)
                {
                    curr_nodeID = m_NodeIndextoID[i];
                    min_dist = dist;
                }
            }

            return curr_nodeID;
        }

    }


}
