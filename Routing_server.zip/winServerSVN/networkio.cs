﻿//  Copyright 2008-2010 Sankhadip Sengupta, Tao Xing, Xuesong Zhou @ University of Utah
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace NetworkManager
{
    public class NetManager
    {
        Socket m_serverSocket;
        Socket m_clientSocket;
        IPAddress m_serverIP;
        IPAddress m_clientIP;
        short m_shServerPort;
        short m_shClientPort;
        NetworkStream m_clientNw;
        NetworkStream m_serverNw;
        string m_szClientIP;
        string m_szServerIP;

        /// <summary>
        /// Getter for the client's IP address
        /// </summary>
        public string SZClientIP
        {
            get { return m_szClientIP; }
        }

        /// <summary>
        /// Converts a string into a byte array
        /// </summary>
        /// <param name="szStrData">String to parse</param>
        /// <returns>A byte array of string szStrData</returns>
        public byte[] ToByteArray(string szStrData)
        {
            byte[] b = new byte[szStrData.Length];
            for (int i = 0; i < szStrData.Length; i++)
            {
                if (szStrData[i] != '.')
                {
                    b[i] = byte.Parse(szStrData[i].ToString());
                }
            }
            return b;
        }


        /// <summary>
        /// Creates a server on the given port with the given address
        /// </summary>
        /// <param name="sPort">Port to listen on</param>
        /// <param name="szIPAddress">IP address for the server</param>
        /// <param name="imaxConn">Maximum number of connections at one time</param>
        public void createServer(short sPort, string szIPAddress, int imaxConn)
        {
            m_serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPHostEntry ip = Dns.GetHostByName(szIPAddress);
            m_serverIP = ip.AddressList[0];
            IPEndPoint myEnd = new IPEndPoint(m_serverIP, sPort);
            m_shServerPort = sPort;
            m_serverSocket.Bind(myEnd);
            m_serverSocket.Listen(imaxConn);
        }

        /// <summary>
        /// Accepts a new connection
        /// </summary>
        public void serverAccept()
        {
            Socket sc = m_serverSocket.Accept();
            m_szClientIP = sc.RemoteEndPoint.ToString();
            m_serverNw = new NetworkStream(sc);
        }

        /// <summary>
        /// Creates a new connection to the given client on the given port.
        /// </summary>
        /// <param name="sPort">Port on which to connect</param>
        /// <param name="szIPAddress">IP address of the client</param>
        public void createClient(short sPort, string szIPAddress)
        {
            m_clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            m_clientIP = IPAddress.Parse(szIPAddress);
            IPEndPoint myEnd = new IPEndPoint(m_clientIP, sPort);
            m_shClientPort = sPort;
            m_szServerIP = szIPAddress;
            m_clientSocket.Connect(myEnd);
            m_clientNw = new NetworkStream(m_clientSocket, FileAccess.ReadWrite, true);
        }

        
        /// <summary>
        /// Sends data to the client via the server network stream
        /// </summary>
        /// <param name="chBuffer">Character array of data to send</param>
        /// <param name="iLength">Amount of data to write</param>
        public void sendClientData(char[] chBuffer, int iLength)
        {
            byte[] b = new byte[iLength];
            for (int i = 0; i < iLength; i++)
            {
                b[i] = (byte)chBuffer[i];
            }
            if (m_serverNw != null)
            {
                m_serverNw.Write(b, 0, iLength);
                Console.WriteLine("Routing response sent. \n");
            }
        }


        /// <summary>
        /// Read data from the client via the server network stream.
        /// </summary>
        /// <param name="chBuffer">Location to store the data</param>
        /// <param name="iLength">Amount of data to read</param>
        public void readClientData(char[] chBuffer, int iLength)
        {
            byte[] b = new byte[chBuffer.Length];
            if (m_serverNw != null)
            {
                m_serverNw.Read(b, 0, iLength);
                string s = b.ToString();
                for (int i = 0; i < chBuffer.Length; i++)
                {
                    chBuffer[i] = (char)b[i];
                }
            }
        }


        /// <summary>
        /// Closes the server network stream
        /// </summary>
        public void closeServer()
        {
            if (m_serverNw != null)
            {
                m_serverNw.Close();
            }
        }

        #region Obsolete Code
        /// <summary>
        /// Writes to the client network stream (which sends data to the server)
        /// if the stream is not null
        /// </summary>
        /// <param name="chBuffer">Character buffer to write</param>
        /// <param name="iLength">Length of the buffer</param>
        /// <returns></returns>
        public void sendServerData(char[] chBuffer, int iLength)
        {
            byte[] b = new byte[chBuffer.Length];
            for (int i = 0; i < chBuffer.Length; i++)
            {
                b[i] = (byte)chBuffer[i];
            }
            if (m_clientNw != null)
            {
                m_clientNw.Write(b, 0, b.Length);
            }
        }

        /// <summary>
        /// Reads ilength bytes of data from the client network stream (the server)
        /// and stores it into chBuffer
        /// </summary>
        /// <param name="chBuffer">Storage destination</param>
        /// <param name="iLength">Number of bytes</param>
        public void readServerData(char[] chBuffer, int iLength)
        {
            byte[] b = new byte[iLength];
            if (m_clientNw != null)
            {
                m_clientNw.Read(b, 0, iLength);
                string s = b.ToString();
                for (int i = 0; i < b.Length; i++)
                {
                    chBuffer[i] = (char)b[i];
                }
            }
        }

        /// <summary>
        /// Reads data from the server (via the client network stream)
        /// and returns it as a string
        /// </summary>
        /// <returns></returns>
        public string readServerData()
        {
            int length = 4096;
            byte[] b = new byte[length];
            char[] chBuffer = new char[length];
            if (m_clientNw != null)
            {
                m_clientNw.Read(b, 0, length);
                //string s = b.ToString();
                for (int i = 0; i < b.Length; i++)
                {
                    chBuffer[i] = (char)b[i];
                }

            }
            string str = new string(chBuffer);
            return str;
        }

        /// <summary>
        /// Closes the client network stream
        /// </summary>
        public void closeClient()
        {
            if (m_clientNw != null)
            {
                m_clientNw.Close();
            }
        }
        #endregion


    }
}