﻿//  Copyright 2008-2010 Tao Xing, Xuesong Zhou @ University of Utah
//  tao.xing@utah.edu
//  This file is part of Shortest path engine (SP_Engine)

//  SP_Engine is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.

//  SP_Engine is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.

//  You should have received a copy of the GNU Lesser General Public License
//  along with SP_Engine.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Data;
using System.Configuration;
using System.Text;

using System.Drawing;
using System.Drawing.Imaging;

using System.IO;
using System.IO.Compression;
using System.Collections;
using System.Collections.Generic;

using System.Xml;
using System.Net;

using UTMconv;

namespace Routing_Engine
{
    public class CMapMatchingRequest
    {
        CgpsTrace[] m_gps_trace;
        int m_trip_id;
        double m_error_level; //in mile, initial 100 meter = 0.06214 mile

        public CgpsTrace[] gps_trace
        {
            get { return m_gps_trace; }
        }

        public double error_level
        {
            get { return m_error_level; }
        }

        public int trip_id
        {
            get { return m_trip_id; }
        }

        public CMapMatchingRequest()
        {
            m_trip_id = 0;
            m_error_level = 0.06214;
        }

        /// <summary>
        /// create a CMapMatchingRequest container
        /// </summary>
        /// <param name="_gps_trace">the data of gps trace</param>
        /// <param name="_error_level">the value indicates the error level in miles</param>
        public CMapMatchingRequest(int _trip_id, CgpsTrace[] _gps_trace, double _error_level)
        {
            this.m_trip_id = _trip_id;
            this.m_gps_trace = _gps_trace;
            this.m_error_level = _error_level;
        }

    }

    public class CMapMatchingResponse
    {
        int[] m_RespLinkSequence;

        public int[] RespLinkSequence
        {
            get { return m_RespLinkSequence; }
        }

        public CMapMatchingResponse()
        {

        }
        /// <summary>
        /// create a CMapMatchingResponse container
        /// </summary>
        /// <param name="_RespLinkSequence">the map matched link sequence</param>
        public CMapMatchingResponse(int[] _RespLinkSequence)
        {
            m_RespLinkSequence = _RespLinkSequence;
        }

    }

}